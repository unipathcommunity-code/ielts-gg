"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Rec { id: string; type: string; date: string; band: number; criteria?: Record<string, any>; }

const DAY = 86400000;
const dayKey = (d: Date) => d.toISOString().slice(0, 10);

export default function StatsPage() {
  const [history, setHistory] = useState<Rec[]>([]);
  const [vocabLearned, setVocabLearned] = useState(0);

  useEffect(() => {
    try { setHistory(JSON.parse(localStorage.getItem("ielts_test_history") || "[]")); } catch {}
    try {
      const srs = JSON.parse(localStorage.getItem("ielts_vocab_srs") || "{}");
      setVocabLearned(Object.values(srs).filter((s: any) => s.interval >= 1).length);
    } catch {}
  }, []);

  // Days with activity
  const activeDays = new Set(history.map((h) => dayKey(new Date(h.date))));

  // Streak: consecutive days up to today/yesterday
  let streak = 0;
  for (let i = 0; i < 400; i++) {
    const d = new Date(Date.now() - i * DAY);
    if (activeDays.has(dayKey(d))) streak++;
    else if (i === 0) continue; // today not done yet — keep counting from yesterday
    else break;
  }

  // Section averages
  const sections = ["reading", "listening", "writing", "speaking"] as const;
  const sectionStat = (t: string) => {
    const xs = history.filter((h) => h.type === t);
    if (!xs.length) return { avg: 0, count: 0 };
    return { avg: xs.reduce((a, b) => a + b.band, 0) / xs.length, count: xs.length };
  };
  const stats = sections.map((s) => ({ name: s, ...sectionStat(s) }));
  const active = stats.filter((s) => s.count > 0);
  const overall = active.length ? active.reduce((a, b) => a + b.avg, 0) / active.length : 0;

  // Heatmap: last 12 weeks (84 days)
  const today = new Date();
  const startOffset = (today.getDay() + 6) % 7; // make Monday=0
  const weeks: { date: Date; count: number }[][] = [];
  const totalDays = 12 * 7;
  const startDate = new Date(Date.now() - (totalDays - 1 + startOffset) * DAY);
  const counts: Record<string, number> = {};
  history.forEach((h) => { const k = dayKey(new Date(h.date)); counts[k] = (counts[k] || 0) + 1; });
  for (let w = 0; w < 13; w++) {
    const col: { date: Date; count: number }[] = [];
    for (let d = 0; d < 7; d++) {
      const date = new Date(startDate.getTime() + (w * 7 + d) * DAY);
      col.push({ date, count: counts[dayKey(date)] || 0 });
    }
    weeks.push(col);
  }
  const heatColor = (c: number) => c === 0 ? "bg-zinc-900" : c === 1 ? "bg-amber-500/40" : c === 2 ? "bg-amber-500/70" : "bg-amber-500";

  const skillIcon: Record<string, string> = { reading: "📖", listening: "🎧", writing: "✍️", speaking: "🗣️" };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] font-sans">
      <header className="sticky top-0 z-30 bg-zinc-950/80 backdrop-blur border-b border-zinc-900">
        <div className="mx-auto max-w-4xl flex h-16 items-center justify-between px-6">
          <Link href="/dashboard" className="text-zinc-500 hover:text-white text-sm font-semibold">← Dashboard</Link>
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500">📊 Statistika</span>
          <span className="w-16" />
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-6 py-8 space-y-6">
        {/* Top cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-gradient-to-br from-amber-950/30 to-zinc-950 border border-amber-500/20 rounded-2xl p-5">
            <div className="text-3xl font-black text-amber-500">{streak}🔥</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 mt-1">Kun ketma-ket</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
            <div className="text-3xl font-black">{history.length}</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 mt-1">Test topshirildi</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
            <div className="text-3xl font-black text-white">{overall ? overall.toFixed(1) : "—"}</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 mt-1">O'rtacha band</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
            <div className="text-3xl font-black text-emerald-400">{vocabLearned}</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 mt-1">So'z o'rganildi</div>
          </div>
        </div>

        {/* Heatmap */}
        <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-6">
          <h2 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-4">Faollik (so'nggi 12 hafta)</h2>
          <div className="flex gap-1 overflow-x-auto pb-2">
            {weeks.map((col, w) => (
              <div key={w} className="flex flex-col gap-1">
                {col.map((cell, d) => (
                  <div key={d} title={`${dayKey(cell.date)}: ${cell.count} test`} className={`w-3.5 h-3.5 rounded-sm ${cell.date > today ? "bg-transparent" : heatColor(cell.count)}`} />
                ))}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 mt-3 text-[10px] text-zinc-500">
            Kam <span className="w-3 h-3 rounded-sm bg-zinc-900" /><span className="w-3 h-3 rounded-sm bg-amber-500/40" /><span className="w-3 h-3 rounded-sm bg-amber-500/70" /><span className="w-3 h-3 rounded-sm bg-amber-500" /> Ko'p
          </div>
        </div>

        {/* Per-skill */}
        <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-6">
          <h2 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-4">Bo'limlar bo'yicha</h2>
          <div className="space-y-4">
            {stats.map((s) => (
              <div key={s.name} className="flex items-center gap-4">
                <span className="text-xl w-7">{skillIcon[s.name]}</span>
                <span className="w-24 capitalize text-sm font-semibold">{s.name}</span>
                <div className="flex-1 h-2 rounded-full bg-zinc-900 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-amber-500 to-yellow-500" style={{ width: `${(s.avg / 9) * 100}%` }} />
                </div>
                <span className="w-16 text-right font-mono font-bold text-amber-500">{s.count ? s.avg.toFixed(1) : "—"}</span>
                <span className="w-20 text-right text-[10px] text-zinc-600">{s.count} test</span>
              </div>
            ))}
          </div>
        </div>

        {history.length === 0 && (
          <p className="text-center text-zinc-600 text-sm">Hali test topshirmadingiz. Boshlash uchun bo'lim tanlang — statistika shu yerda to'ladi.</p>
        )}
      </main>
    </div>
  );
}
