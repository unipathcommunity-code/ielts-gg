import Link from "next/link";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-background font-sans text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full transition-colors duration-200 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-6 md:grid md:grid-cols-[1fr_auto_1fr]">
          <Link href="/" className="text-xl font-bold tracking-tight md:justify-self-start flex items-center gap-2">
            <span className="bg-amber-500 text-white w-8 h-8 flex items-center justify-center rounded-lg font-black text-sm">9.0</span>
            kmw<span className="text-amber-500">.bb</span>
          </Link>
          <nav className="hidden items-center gap-8 md:flex md:justify-self-center text-sm font-semibold text-muted-foreground">
            <Link href="#platform" className="hover:text-foreground transition-colors">Platforma</Link>
            <Link href="#features" className="hover:text-foreground transition-colors">Imkoniyatlar</Link>
            <Link href="#pricing" className="hover:text-foreground transition-colors">Narxlar</Link>
          </nav>
          <div className="ms-auto flex items-center gap-4 md:ms-0 md:justify-self-end">
            <Link href="/login" className="text-sm font-semibold hover:text-amber-500 transition-colors hidden sm:block">
              Kirish
            </Link>
            <Link href="/start" className="bg-foreground text-background text-sm font-bold px-5 py-2.5 rounded-full hover:opacity-90 transition-opacity shadow-sm">
              Bepul boshlash
            </Link>
          </div>
        </div>
      </header>

      {/* Main Hero */}
      <main className="flex-1">
        <section className="relative flex flex-col items-center justify-center pt-32 pb-24 px-6 text-center overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[100px] -z-10"></div>
          
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-widest mb-8 border border-amber-500/20">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            IELTS Computer Based Test Simulator
          </div>
          
          <h1 className="max-w-4xl text-5xl md:text-7xl font-extrabold tracking-tight mb-8 leading-[1.1]">
            Get the band score you want — <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-500 to-yellow-600">on your first try.</span>
          </h1>
          
          <p className="max-w-2xl text-xl text-muted-foreground mb-12 leading-relaxed">
            Academic IELTS uchun AI tayyorgarlik. <span className="text-foreground font-semibold">Jonli AI imtihonchi bilan inson ovozida suhbat</span>, Writing &amp; Speaking'ni real ekzaminator kabi baholash, lug'at, talaffuz va shaxsiy reja — barchasi bitta joyda.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
            <Link href="/start" className="bg-foreground text-background px-8 py-4 rounded-full font-bold text-lg hover:opacity-90 transition-opacity shadow-xl hover:shadow-2xl hover:-translate-y-1 transform duration-200">
              Tayyorgarlikni boshlash →
            </Link>
            <Link href="#features" className="border border-border bg-background px-8 py-4 rounded-full font-bold text-lg hover:bg-muted transition-colors">
              Imkoniyatlarni ko'rish
            </Link>
          </div>

          {/* Hero Dashboard Preview */}
          <div className="mt-24 w-full max-w-6xl mx-auto rounded-xl border border-border shadow-2xl overflow-hidden bg-muted/30 relative">
            <div className="absolute top-0 left-0 right-0 h-12 bg-background border-b border-border flex items-center px-4 gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
            <div className="pt-12 p-8 grid grid-cols-1 md:grid-cols-4 gap-6 text-left">
               <div className="bg-background p-6 rounded-xl border border-border shadow-sm">
                 <div className="text-3xl mb-4">📖</div>
                 <div className="font-bold mb-1">Reading</div>
                 <div className="text-sm text-muted-foreground">3 Sections • 40 Questions</div>
               </div>
               <div className="bg-background p-6 rounded-xl border border-border shadow-sm">
                 <div className="text-3xl mb-4">🎧</div>
                 <div className="font-bold mb-1">Listening</div>
                 <div className="text-sm text-muted-foreground">4 Parts • 40 Questions</div>
               </div>
               <div className="bg-background p-6 rounded-xl border border-border shadow-sm ring-2 ring-amber-500 ring-offset-2 ring-offset-muted">
                 <div className="text-3xl mb-4">✍️</div>
                 <div className="font-bold mb-1 text-amber-500">Writing</div>
                 <div className="text-sm text-muted-foreground">AI Graded Tasks 1 & 2</div>
               </div>
               <div className="bg-background p-6 rounded-xl border border-border shadow-sm">
                 <div className="text-3xl mb-4">🎙️</div>
                 <div className="font-bold mb-1">Speaking</div>
                 <div className="text-sm text-muted-foreground">Real-time AI Examiner</div>
               </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-24 px-6 bg-background border-t border-border">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-6">Nega aynan kmw.bb?</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">IELTS'ni egallash uchun kerak bo'lgan hamma narsa — bitta chiroyli platformada.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-10">
              {[
                { icon: "🗣️", title: "Jonli AI Speaking suhbati", desc: "Skript emas — AI javobingizni eshitib, real ekzaminator kabi tabiiy follow-up beradi. Part 1 va Part 3 to'liq jonli." },
                { icon: "🎙️", title: "Inson ovozi (ElevenLabs)", desc: "AI ustoz robot emas, haqiqiy inson ovozida gapiradi. 5 xil shaxsiyat: mehribon, qattiqqo'l va boshqalar." },
                { icon: "🤖", title: "Tezkor AI baholash", desc: "Writing va Speaking'ni Cambridge mezonlari (TR/CC/LR/GRA) bo'yicha bir zumda baholaydi, batafsil tuzatishlar bilan." },
                { icon: "📚", title: "Lug'at + Spaced Repetition", desc: "Akademik so'zlar, IPA, ovozli talaffuz va aqlli takrorlash — unutmaslik uchun." },
                { icon: "📊", title: "Shaxsiy AI murabbiy", desc: "Kuchsiz tomoningizni aniqlaydi, kunlik reja tuzadi va streak/statistika bilan progressni kuzatadi." },
                { icon: "🌐", title: "Universal AI ustoz", desc: "Imtihondan tashqari — istalgan mavzuda, o'zbek yoki ingliz tilida erkin suhbat qilib mashq qiling." },
              ].map((f) => (
                <div key={f.title} className="flex flex-col gap-3">
                  <div className="w-14 h-14 bg-amber-500/10 text-amber-500 rounded-2xl flex items-center justify-center text-2xl">{f.icon}</div>
                  <h3 className="text-xl font-bold">{f.title}</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-24 px-6 bg-foreground text-background text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-8">Imtihonni zabt etishga tayyormisiz?</h2>
          <p className="text-xl opacity-80 mb-10 max-w-xl mx-auto">Maqsadli band ballariga erishgan minglab o'quvchilarga qo'shiling.</p>
          <Link href="/start" className="inline-block bg-background text-foreground px-10 py-4 rounded-full font-bold text-xl hover:scale-105 transition-transform duration-200">
            Mashqni boshlash
          </Link>
        </section>
      </main>
      
      {/* Footer */}
      <footer className="py-12 px-6 border-t border-border bg-background">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-2">
            <Link href="/" className="text-xl font-bold tracking-tight mb-4 inline-block">
              kmw<span className="text-amber-500">.bb</span>
            </Link>
            <p className="text-muted-foreground text-sm max-w-sm">
              The ultimate computer-based IELTS preparation platform powered by advanced AI.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Platform</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="#" className="hover:text-amber-500">Mock Tests</Link></li>
              <li><Link href="#" className="hover:text-amber-500">AI Writing Grading</Link></li>
              <li><Link href="#" className="hover:text-amber-500">Speaking Examiner</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="#" className="hover:text-amber-500">Terms of Service</Link></li>
              <li><Link href="#" className="hover:text-amber-500">Privacy Policy</Link></li>
              <li><Link href="#" className="hover:text-amber-500">Contact Us</Link></li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} KMW BB Alternative. All rights reserved. IELTS is a registered trademark of University of Cambridge, the British Council, and IDP Education Australia. This site and its owners are not affiliated, approved or endorsed by the University of Cambridge ESOL, the British Council, and IDP Education Australia.</p>
        </div>
      </footer>
    </div>
  );
}
