// Canonical listening content. Used by the seed script; the app keeps a typed
// copy in src/lib/listeningData.ts as an offline fallback.
const M = (s) => `<mark class="bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-bold">${s}</mark>`;
const SEC = (n) => `<strong class="text-amber-500 font-mono">[Section ${n}]</strong>`;

export const LISTENING_TESTS = {
  campus: {
    id: "campus",
    title: "Campus Accommodation & Facilities",
    sentences: [
      "Welcome to the student accommodation services.",
      "I am here to help you register.",
      "May I have your name, please?",
      "Yes, it's John Smith. That is S-M-I-T-H.",
      "Great. And your contact number?",
      "It's 0-7-1-2-3-4-5-6-7-8-9.",
      "OK. What type of room are you looking for?",
      "A single room, please.",
      "OK, we have a single room available.",
      "Now let me tell you about our campus facilities.",
      "The library is located in the north building, which is open from 8:00 AM to 10:00 PM daily.",
      "We also have a state-of-the-art sports center next to the library.",
      "It includes an indoor swimming pool, which is heated throughout the year, and a fully equipped gym.",
      "To use the gym, students must attend an induction session first.",
      "Lastly, the student cafeteria is in the central block, serving hot meals from 11:30 AM to 2:30 PM.",
    ],
    transcriptHtml:
      `<p class="mb-2">${SEC(1)} Welcome to the student accommodation services. I am here to help you register. May I have your name, please? Yes, it's John ${M("Smith")} (Q1). That is S-M-I-T-H. Great. And your contact number? It's ${M("07123456789")} (Q2). OK. What type of room are you looking for? A ${M("single")} (Q3) room, please. OK, we have a single room available...</p>` +
      `<p>${SEC(2)} Okay, now let me tell you about our campus facilities. The library is located in the ${M("north building")} (Q4), which is open from 8:00 AM to 10:00 PM daily. We also have a state-of-the-art sports center next to the library. It includes an indoor swimming pool, which is ${M("heated throughout the year")} (Q6), and a fully equipped gym. To use the gym, students must ${M("attend an induction session")} (Q5) first. Lastly, the student cafeteria is in the central block, serving hot meals from ${M("11:30 AM to 2:30 PM")} (Q7).</p>`,
    vocab: [
      { word: "Accommodation", definition: "A room or building in which someone may live.", translation: "Turar joy" },
      { word: "Induction session", definition: "An introductory training or briefing.", translation: "Kirish mashg'uloti" },
      { word: "Heated throughout", definition: "Warmed all year round.", translation: "Yil davomida isitiladigan" },
      { word: "Cafeteria", definition: "A self-service restaurant.", translation: "Oshxona/bufet" },
    ],
    questions: [
      { qid: "q1", kind: "fill", prompt: "Name (Last name)", prefix: "John", suffix: "", answer_key: "SMITH" },
      { qid: "q2", kind: "fill", prompt: "Contact number", prefix: "", suffix: "", answer_key: "07123456789" },
      { qid: "q3", kind: "fill", prompt: "Type of room", prefix: "", suffix: "bedroom", answer_key: "SINGLE" },
      { qid: "q4", kind: "mcq", prompt: "Where is the library located on campus?", options: [{ value: "A", label: "North building" }, { value: "B", label: "South building" }, { value: "C", label: "Central block" }], answer_key: "A" },
      { qid: "q5", kind: "mcq", prompt: "What is required in order to use the gym?", options: [{ value: "A", label: "Pay a monthly fee" }, { value: "B", label: "Attend an induction session" }, { value: "C", label: "Bring your student ID card" }], answer_key: "B" },
      { qid: "q6", kind: "mcq", prompt: "What are the swimming pool heating terms?", options: [{ value: "A", label: "Closed in winter" }, { value: "B", label: "Heated throughout the year" }, { value: "C", label: "Free for all local residents" }], answer_key: "B" },
      { qid: "q7", kind: "mcq", prompt: "When is the cafeteria open for hot meals?", options: [{ value: "A", label: "8:00 AM - 10:00 PM" }, { value: "B", label: "11:30 AM - 2:30 PM" }, { value: "C", label: "All day long" }], answer_key: "B" },
    ],
  },
  travel: {
    id: "travel",
    title: "Travel Agency Booking & City Museum Tour",
    sentences: [
      "Good morning, City Travel Agency. How can I help you?",
      "Yes, I'd like to book a city tour.",
      "Sure. What is your name?",
      "It's Sarah Jenkins. That is J-E-N-K-I-N-S.",
      "OK, Sarah. And your contact number?",
      "It's 0-7-9-8-7-6-5-4-3-2-1.",
      "Great. Which date would you like to tour?",
      "The twelfth of July, please.",
      "Welcome to the City Historical Museum.",
      "Before we start, let me explain the layout.",
      "The main exhibition room is on the second floor, open from 9 AM to 5 PM.",
      "To see the special royal collection, visitors must purchase an extra ticket.",
      "Photography is strictly prohibited inside the collection hall.",
      "Finally, our gift shop is next to the exit, selling souvenirs and booklets from 10 AM to 4 PM.",
    ],
    transcriptHtml:
      `<p class="mb-2">${SEC(1)} Good morning, City Travel Agency. How can I help you? Yes, I'd like to book a city tour. Sure. What is your name? It's Sarah ${M("Jenkins")} (Q1). That is J-E-N-K-I-N-S. OK, Sarah. And your contact number? It's ${M("07987654321")} (Q2). Great. Which date would you like to tour? The ${M("12 JULY")} (Q3) (twelfth of July), please.</p>` +
      `<p>${SEC(2)} Welcome to the City Historical Museum. Before we start, let me explain the layout. The main exhibition room is on the ${M("second floor")} (Q4) (B), open from 9 AM to 5 PM. To see the special royal collection, visitors must ${M("purchase an extra ticket")} (Q5) (A). Photography is ${M("strictly prohibited")} (Q6) (C) inside the collection hall. Finally, our gift shop is next to the exit, selling souvenirs and booklets from ${M("10 AM to 4 PM")} (Q7) (B).</p>`,
    vocab: [
      { word: "Souvenirs", definition: "Things kept as a reminder of a place.", translation: "Esdalik sovg'alari" },
      { word: "Prohibited", definition: "Forbidden by law or rule.", translation: "Taqiqlangan" },
      { word: "Exhibition", definition: "A public display of works of art or items.", translation: "Ko'rgazma" },
      { word: "Souvenir booklet", definition: "A small book with information.", translation: "Esdalik bukleti" },
    ],
    questions: [
      { qid: "q1", kind: "fill", prompt: "Name (Last name)", prefix: "Sarah", suffix: "", answer_key: "JENKINS" },
      { qid: "q2", kind: "fill", prompt: "Contact number", prefix: "", suffix: "", answer_key: "07987654321" },
      { qid: "q3", kind: "fill", prompt: "Date of Tour (e.g. 12 July)", prefix: "", suffix: "", answer_key: "12 JULY" },
      { qid: "q4", kind: "mcq", prompt: "Where is the main exhibition room located?", options: [{ value: "A", label: "First floor" }, { value: "B", label: "Second floor" }, { value: "C", label: "Basement" }], answer_key: "B" },
      { qid: "q5", kind: "mcq", prompt: "What is required to see the royal collection?", options: [{ value: "A", label: "Purchase an extra ticket" }, { value: "B", label: "Join a guided group" }, { value: "C", label: "Leave bags in lockers" }], answer_key: "A" },
      { qid: "q6", kind: "mcq", prompt: "What are the rules regarding photography?", options: [{ value: "A", label: "Allowed everywhere" }, { value: "B", label: "Allowed for a fee" }, { value: "C", label: "Strictly prohibited inside the hall" }], answer_key: "C" },
      { qid: "q7", kind: "mcq", prompt: "When is the gift shop open?", options: [{ value: "A", label: "9:00 AM - 5:00 PM" }, { value: "B", label: "10:00 AM - 4:00 PM" }, { value: "C", label: "All day long" }], answer_key: "B" },
    ],
  },
  career: {
    id: "career",
    title: "Job Interview & Office Orientation",
    sentences: [
      "Hello, HR department of Tech Solutions.",
      "I am calling about my interview tomorrow.",
      "Ah, yes. Can I confirm your name, please?",
      "Yes, it's David Harrison. That is H-A-R-R-I-S-O-N.",
      "Thank you, David. Your contact email is david point h at tech point com?",
      "Yes.",
      "And what position are you interviewing for?",
      "The software engineer position.",
      "Welcome to your first day at Tech Solutions. Let me show you around the office.",
      "The conference room is on the third floor, which is used for all department meetings.",
      "To access the office after 7 PM, employees must use their security badge.",
      "Free parking is available for all staff members in the basement garage.",
      "Lastly, the company kitchen is on the first floor, offering free coffee and snacks from 8:30 AM to 6 PM.",
    ],
    transcriptHtml:
      `<p class="mb-2">${SEC(1)} Hello, HR department of Tech Solutions. I am calling about my interview tomorrow. Ah, yes. Can I confirm your name, please? Yes, it's David ${M("Harrison")} (Q1). That is H-A-R-R-I-S-O-N. Thank you, David. Your contact email is ${M("david.h@tech.com")} (Q2)? Yes. And what position are you interviewing for? The ${M("software engineer")} (Q3) position.</p>` +
      `<p>${SEC(2)} Welcome to your first day at Tech Solutions. Let me show you around the office. The conference room is on the ${M("third floor")} (Q4) (A), which is used for all department meetings. To access the office after 7 PM, employees must ${M("use their security badge")} (Q5) (C). Free parking is available for all staff members in the ${M("basement garage")} (Q6) (A). Lastly, the company kitchen is on the first floor, offering free coffee and snacks from ${M("8:30 AM to 6:00 PM")} (Q7) (B).</p>`,
    vocab: [
      { word: "Orientation", definition: "Introduction to a new workplace.", translation: "Moslashuv/tanishuv" },
      { word: "HR department", definition: "Human Resources department.", translation: "Kadrlar bo'limi" },
      { word: "Security badge", definition: "A card allowing access to a building.", translation: "Ruxsatnoma beyjigi" },
      { word: "Garage", definition: "A building or shed for housing motor vehicles.", translation: "Avtoturargoh" },
    ],
    questions: [
      { qid: "q1", kind: "fill", prompt: "Name (Last name)", prefix: "David", suffix: "", answer_key: "HARRISON" },
      { qid: "q2", kind: "fill", prompt: "Contact email", prefix: "", suffix: "", answer_key: "DAVID.H@TECH.COM" },
      { qid: "q3", kind: "fill", prompt: "Applied Position", prefix: "the", suffix: "position", answer_key: "SOFTWARE ENGINEER" },
      { qid: "q4", kind: "mcq", prompt: "Where is the conference room located?", options: [{ value: "A", label: "Third floor" }, { value: "B", label: "First floor" }, { value: "C", label: "Penthouse" }], answer_key: "A" },
      { qid: "q5", kind: "mcq", prompt: "What is required to access the office after 7 PM?", options: [{ value: "A", label: "Enter a passcode" }, { value: "B", label: "Sign in with security" }, { value: "C", label: "Use their security badge" }], answer_key: "C" },
      { qid: "q6", kind: "mcq", prompt: "Where can staff park their cars for free?", options: [{ value: "A", label: "Basement garage" }, { value: "B", label: "Street parking" }, { value: "C", label: "Nearby public lot" }], answer_key: "A" },
      { qid: "q7", kind: "mcq", prompt: "When is the kitchen open for coffee and snacks?", options: [{ value: "A", label: "24 hours a day" }, { value: "B", label: "8:30 AM - 6:00 PM" }, { value: "C", label: "Only during lunch hours" }], answer_key: "B" },
    ],
  },
};
