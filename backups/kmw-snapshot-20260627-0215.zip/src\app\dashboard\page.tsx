"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

interface TestRecord {
  id: string;
  type: "reading" | "listening" | "writing" | "speaking";
  date: string;
  band: number;
  correct?: number;
  total?: number;
  criteria?: Record<string, any>;
  improvements?: string[];
}

export default function Dashboard() {
  const [userData, setUserData] = useState<any>(null);
  const [history, setHistory] = useState<TestRecord[]>([]);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [doneTasks, setDoneTasks] = useState<Record<string, boolean>>({});
  const todayKey = new Date().toISOString().slice(0, 10);

  useEffect(() => {
    const data = localStorage.getItem("ielts_prep_data");
    if (data) {
      setUserData(JSON.parse(data));
    }

    const historyJson = localStorage.getItem("ielts_test_history");
    if (historyJson) {
      try {
        setHistory(JSON.parse(historyJson));
      } catch (e) {
        console.warn("Failed to parse test history:", e);
      }
    }

    const savedTheme = localStorage.getItem("ielts_theme");
    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
    }
    try {
      const dt = JSON.parse(localStorage.getItem(`ielts_daily_${todayKey}`) || "{}");
      setDoneTasks(dt);
    } catch {}
  }, []);

  const toggleTask = (id: string) => {
    setDoneTasks((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      localStorage.setItem(`ielts_daily_${todayKey}`, JSON.stringify(next));
      return next;
    });
  };

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    localStorage.setItem("ielts_theme", next);
  };

  // Calculate averages per section
  const getSectionStats = (type: string) => {
    const sectionTests = history.filter((t) => t.type === type);
    if (sectionTests.length === 0) return { avg: "Not Taken", count: 0 };
    const sum = sectionTests.reduce((acc, curr) => acc + curr.band, 0);
    const rawAvg = sum / sectionTests.length;
    return { avg: rawAvg.toFixed(1), count: sectionTests.length };
  };

  const readingStats = getSectionStats("reading");
  const listeningStats = getSectionStats("listening");
  const writingStats = getSectionStats("writing");
  const speakingStats = getSectionStats("speaking");

  // Overall Est. Band Score calculation
  const getOverallEstBand = () => {
    const activeSections = [readingStats, listeningStats, writingStats, speakingStats]
      .filter((s) => s.count > 0);
    
    if (activeSections.length === 0) return "?";
    
    const sumOfAverages = activeSections.reduce((acc, curr) => acc + parseFloat(curr.avg), 0);
    const rawAverage = sumOfAverages / activeSections.length;
    
    // Official IELTS rounding
    const val = rawAverage;
    const decimal = val - Math.floor(val);
    if (decimal < 0.25) {
      return Math.floor(val).toFixed(1);
    } else if (decimal < 0.75) {
      return (Math.floor(val) + 0.5).toFixed(1);
    } else {
      return Math.ceil(val).toFixed(1);
    }
  };

  const overallEstBand = getOverallEstBand();

  // ── Personal AI Coach: surface the weakest sub-skill + recent AI tips from history ──
  const CRITERIA_LABELS: Record<string, string> = {
    taskResponse: "Task Response",
    coherence: "Coherence & Cohesion",
    lexical: "Lexical Resource",
    grammar: "Grammar (GRA)",
    fluency: "Fluency",
    vocabulary: "Vocabulary",
    pronunciation: "Pronunciation",
  };
  const getCoachProfile = () => {
    const sums: Record<string, { sum: number; count: number }> = {};
    history.forEach((h) => {
      const c = h.criteria;
      if (c && typeof c === "object") {
        Object.entries(c).forEach(([k, v]) => {
          const n = parseFloat(v as any);
          if (CRITERIA_LABELS[k] && !isNaN(n)) {
            sums[k] = sums[k] || { sum: 0, count: 0 };
            sums[k].sum += n;
            sums[k].count++;
          }
        });
      }
    });
    const averaged = Object.entries(sums)
      .map(([k, v]) => ({ key: k, label: CRITERIA_LABELS[k], avg: v.sum / v.count }))
      .sort((a, b) => a.avg - b.avg);

    const tips: string[] = [];
    history
      .filter((h) => h.type === "writing" || h.type === "speaking")
      .slice(0, 4)
      .forEach((h) => {
        (h.improvements || []).forEach((t) => {
          if (t && !tips.includes(t)) tips.push(t);
        });
      });
    return { weakest: averaged[0], averaged, tips: tips.slice(0, 5) };
  };
  const coach = getCoachProfile();

  // ── Daily plan: tailored to the weak section from onboarding ──
  const weakKey = (userData?.weakness as string) || "writing";
  const weakMeta: Record<string, { label: string; icon: string }> = {
    reading: { label: "Reading", icon: "📖" }, listening: { label: "Listening", icon: "🎧" },
    writing: { label: "Writing", icon: "✍️" }, speaking: { label: "Speaking", icon: "🗣️" },
  };
  const wk = weakMeta[weakKey] || weakMeta.writing;
  const dailyTasks = [
    { id: "vocab", label: "10 ta yangi so'z o'rganing", href: "/vocabulary", icon: "📚" },
    { id: "weak", label: `${wk.label} mashqi (kuchsiz bo'limingiz)`, href: `/test/${weakKey}`, icon: wk.icon },
    { id: "speak", label: "AI bilan 5 daqiqa jonli suhbat", href: "/test/speaking", icon: "🗣️" },
    { id: "pron", label: "Talaffuz mashqi (3 jumla)", href: "/test/pronunciation", icon: "🎙️" },
  ];
  const doneCount = dailyTasks.filter((t) => doneTasks[t.id]).length;
  const dailyPct = Math.round((doneCount / dailyTasks.length) * 100);

  const clearHistory = () => {
    if (confirm("Testlar tarixini tozalashni xohlaysizmi?")) {
      localStorage.removeItem("ielts_test_history");
      setHistory([]);
    }
  };

  return (
    <div className={`min-h-screen font-sans flex flex-col selection:bg-amber-500/20 selection:text-amber-500 relative overflow-hidden transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#09090b] text-[#f4f4f5]' : 'bg-[#f8f9fa] text-[#18181b]'
    }`}>
      {/* Background radial glows */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[140px] -z-10 pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-yellow-600/5 rounded-full blur-[140px] -z-10 pointer-events-none"></div>

      {/* Header */}
      <header className={`border-b sticky top-0 z-30 backdrop-blur-md transition-colors duration-300 ${
        theme === 'dark' ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'
      }`}>
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <Link href="/dashboard" className="text-xl font-bold tracking-tight flex items-center gap-2">
            <span className="bg-amber-500 text-black w-8 h-8 flex items-center justify-center rounded-lg font-black text-sm">9.0</span>
            kmw<span className="text-amber-500">.bb</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/stats" className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
              theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white' : 'bg-zinc-100 border-zinc-200 text-zinc-700 hover:text-black'
            }`}>
              📊 Statistika
            </Link>
            <button
              onClick={toggleTheme}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                theme === 'dark'
                  ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                  : 'bg-zinc-100 border-zinc-200 text-zinc-700 hover:text-black'
              }`}
            >
              {theme === 'dark' ? "☀️ Light" : "🌙 Dark"}
            </button>
            <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-600 flex items-center justify-center text-black font-black text-sm shadow-md shadow-amber-500/10">
              {userData?.target ? `T:${userData.target}` : "US"}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl w-full px-6 py-10 flex-1 z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <h1 className={`text-3xl md:text-4xl font-extrabold tracking-tight mb-2 bg-gradient-to-r bg-clip-text text-transparent ${
              theme === 'dark' ? 'from-white via-zinc-100 to-zinc-500' : 'from-zinc-900 via-zinc-800 to-zinc-600'
            }`}>
              Xush kelibsiz! / Welcome back
            </h1>
            <p className="text-sm text-zinc-500">IELTS darajangizni oshirish uchun shaxsiy AI tizimingiz tayyor.</p>
          </div>
          {history.length > 0 && (
            <button 
              onClick={clearHistory}
              className={`text-xs font-semibold uppercase tracking-wider self-start md:self-auto border px-3 py-1.5 rounded-lg transition-colors ${
                theme === 'dark' 
                  ? 'text-zinc-500 hover:text-red-400 border-zinc-900 hover:border-red-500/20 bg-zinc-950/20' 
                  : 'text-zinc-500 hover:text-red-500 border-zinc-200 hover:border-red-500/20 bg-zinc-50'
              }`}
            >
              Tarixni tozalash
            </button>
          )}
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Action Area */}
          <div className="lg:col-span-2 space-y-8">
            {/* Daily Plan */}
            <div className={`rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-md transition-colors duration-300 ${
              theme === 'dark' ? 'border-zinc-900 bg-zinc-950/40' : 'border-zinc-200 bg-white'
            }`}>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold tracking-tight">Bugungi reja</h2>
                  <p className="text-sm text-zinc-500">{doneCount}/{dailyTasks.length} bajarildi · har kuni yangilanadi</p>
                </div>
                <div className="relative w-14 h-14">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="15" fill="none" stroke={theme === 'dark' ? '#27272a' : '#e4e4e7'} strokeWidth="4" />
                    <circle cx="18" cy="18" r="15" fill="none" stroke="#f59e0b" strokeWidth="4" strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 15}`} strokeDashoffset={`${2 * Math.PI * 15 * (1 - dailyPct / 100)}`} className="transition-all duration-500" />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-xs font-black text-amber-500">{dailyPct}%</div>
                </div>
              </div>
              <div className="space-y-2">
                {dailyTasks.map((t) => {
                  const done = !!doneTasks[t.id];
                  return (
                    <div key={t.id} className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                      done ? 'border-emerald-500/20 bg-emerald-500/5' : theme === 'dark' ? 'border-zinc-900 bg-zinc-950/40' : 'border-zinc-200 bg-zinc-50'
                    }`}>
                      <button onClick={() => toggleTask(t.id)} className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center shrink-0 transition-all ${
                        done ? 'bg-emerald-500 border-emerald-500 text-black' : 'border-zinc-600 hover:border-amber-500'
                      }`}>
                        {done && <span className="text-xs font-black">✓</span>}
                      </button>
                      <span className="text-lg">{t.icon}</span>
                      <span className={`flex-1 text-sm font-medium ${done ? 'line-through text-zinc-500' : ''}`}>{t.label}</span>
                      <Link href={t.href} className="text-xs font-bold text-amber-500 hover:text-amber-400 shrink-0">Boshlash →</Link>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Teacher Protocol Card */}
            <div className={`relative overflow-hidden rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-sm group transition-colors duration-300 ${
              theme === 'dark' 
                ? 'border-cyan-500/20 bg-gradient-to-br from-cyan-950/20 to-zinc-950' 
                : 'border-cyan-500/30 bg-gradient-to-br from-cyan-50/40 to-white'
            }`}>
              <div className="absolute top-0 right-0 w-[200px] h-[200px] bg-cyan-500/5 rounded-full blur-[50px] pointer-events-none"></div>
              
              <div className="flex flex-col md:flex-row gap-6 items-start justify-between">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="animate-pulse w-2 h-2 rounded-full bg-cyan-400"></span>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-500 font-mono">SYSTEM ACTIVE // PROTOCOL TEACHER</span>
                  </div>
                  <h2 className="text-xl md:text-2xl font-extrabold tracking-tight">AI Teacher Tutor / Shaxsiy Ustoz</h2>
                  <p className={`text-sm leading-relaxed ${theme === 'dark' ? 'text-zinc-400' : 'text-zinc-600'}`}>
                    Eski darsliklarni unuting! Shaxsiy sun'iy intellekt ustozingiz bilan cheksiz muloqot qiling, grammatika va talaffuz xatolaringiz bo'yicha darhol tahlil oling.
                  </p>
                </div>
                <Link 
                  href="/jarvis" 
                  className="bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold px-6 py-3 rounded-xl transition-all shadow-lg shadow-cyan-500/10 hover:shadow-cyan-400/20 text-sm w-full md:w-auto text-center"
                >
                  Ustoz bilan gaplashish
                </Link>
              </div>
            </div>

            {/* Test Sections */}
            <div className={`rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-md transition-colors duration-300 ${
              theme === 'dark' ? 'border-zinc-900 bg-zinc-950/40' : 'border-zinc-200 bg-white'
            }`}>
              <h2 className="text-xl font-bold tracking-tight mb-2">Simulyator Bo'limlari</h2>
              <p className="text-sm text-zinc-500 mb-8">Kerakli imtihon bo'limini tanlang va real baholash standartlarida sinab ko'ring.</p>
              
              <div className="grid gap-4 sm:grid-cols-2">
                <Link href="/test/reading" className={`flex flex-col justify-between p-6 rounded-xl border hover:shadow-lg transition-all group relative overflow-hidden ${
                  theme === 'dark' 
                    ? 'border-zinc-900 hover:border-amber-500/40 bg-zinc-950/60' 
                    : 'border-zinc-200 hover:border-amber-500/60 bg-zinc-50/50'
                }`}>
                  <div className="absolute top-3 right-3 text-xs font-bold font-mono text-amber-500/80">
                    {readingStats.avg !== "Not Taken" ? `Band ${readingStats.avg}` : "Not Taken"}
                  </div>
                  <div>
                    <span className="text-3xl block mb-4">📖</span>
                    <h3 className="font-bold text-lg group-hover:text-amber-500 transition-colors">Reading / O'qish</h3>
                    <p className={`text-sm mt-2 leading-relaxed ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-600'}`}>Academic darajadagi matnlar, matnni belgilash (highlighter) va qattiq baholash tizimi.</p>
                  </div>
                  <div className="text-xs font-bold text-zinc-600 mt-6 group-hover:text-zinc-400 transition-colors">
                    {readingStats.count} marta topshirilgan →
                  </div>
                </Link>
                
                <Link href="/test/listening" className={`flex flex-col justify-between p-6 rounded-xl border hover:shadow-lg transition-all group relative overflow-hidden ${
                  theme === 'dark' 
                    ? 'border-zinc-900 hover:border-amber-500/40 bg-zinc-950/60' 
                    : 'border-zinc-200 hover:border-amber-500/60 bg-zinc-50/50'
                }`}>
                  <div className="absolute top-3 right-3 text-xs font-bold font-mono text-amber-500/80">
                    {listeningStats.avg !== "Not Taken" ? `Band ${listeningStats.avg}` : "Not Taken"}
                  </div>
                  <div>
                    <span className="text-3xl block mb-4">🎧</span>
                    <h3 className="font-bold text-lg group-hover:text-amber-500 transition-colors">Listening / Eshitish</h3>
                    <p className={`text-sm mt-2 leading-relaxed ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-600'}`}>Tezlik sozlamalari, interaktiv savollar va topshirgandan so'ng rangli tahlil transkripti.</p>
                  </div>
                  <div className="text-xs font-bold text-zinc-600 mt-6 group-hover:text-zinc-400 transition-colors">
                    {listeningStats.count} marta topshirilgan →
                  </div>
                </Link>
                
                <Link href="/test/writing" className={`flex flex-col justify-between p-6 rounded-xl border hover:shadow-lg transition-all group relative overflow-hidden ${
                  theme === 'dark' 
                    ? 'border-zinc-900 hover:border-amber-500/40 bg-zinc-950/60' 
                    : 'border-zinc-200 hover:border-amber-500/60 bg-zinc-50/50'
                }`}>
                  <div className="absolute top-3 right-3 text-xs font-bold font-mono text-amber-500/80">
                    {writingStats.avg !== "Not Taken" ? `Band ${writingStats.avg}` : "Not Taken"}
                  </div>
                  <div>
                    <span className="text-3xl block mb-4">✍️</span>
                    <h3 className="font-bold text-lg group-hover:text-amber-500 transition-colors">Writing / Yozish</h3>
                    <p className={`text-sm mt-2 leading-relaxed ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-600'}`}>Cambridge IELTS imtihoni mezonlari (TR, CC, LR, GRA) bo'yicha chuqur sun'iy intellekt tahlili.</p>
                  </div>
                  <div className="text-xs font-bold text-zinc-600 mt-6 group-hover:text-zinc-400 transition-colors">
                    {writingStats.count} marta topshirilgan →
                  </div>
                </Link>
                
                <Link href="/test/speaking" className={`flex flex-col justify-between p-6 rounded-xl border hover:shadow-lg transition-all group relative overflow-hidden ${
                  theme === 'dark' 
                    ? 'border-zinc-900 hover:border-amber-500/40 bg-zinc-950/60' 
                    : 'border-zinc-200 hover:border-amber-500/60 bg-zinc-50/50'
                }`}>
                  <div className="absolute top-3 right-3 text-xs font-bold font-mono text-amber-500/80">
                    {speakingStats.avg !== "Not Taken" ? `Band ${speakingStats.avg}` : "Not Taken"}
                  </div>
                  <div>
                    <span className="text-3xl block mb-4">🗣️</span>
                    <h3 className="font-bold text-lg group-hover:text-amber-500 transition-colors">Speaking / Gapirish</h3>
                    <p className={`text-sm mt-2 leading-relaxed ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-600'}`}>Ovozni aniqlash tizimi bilan rasmiy IELTS Speaking Part 1 formatidagi jonli simulyatsiya.</p>
                  </div>
                  <div className="text-xs font-bold text-zinc-600 mt-6 group-hover:text-zinc-400 transition-colors">
                    {speakingStats.count} marta topshirilgan →
                  </div>
                </Link>
              </div>
            </div>

            {/* Practice Tools — Vocabulary + Pronunciation */}
            <div className="grid sm:grid-cols-2 gap-4">
              <Link href="/vocabulary" className={`flex items-center gap-4 p-5 rounded-2xl border hover:shadow-lg transition-all group ${
                theme === 'dark' ? 'border-zinc-900 hover:border-amber-500/40 bg-zinc-950/60' : 'border-zinc-200 hover:border-amber-500/60 bg-white'
              }`}>
                <span className="text-3xl">📖</span>
                <div>
                  <div className="font-bold group-hover:text-amber-500 transition-colors">Lug'at + Takrorlash</div>
                  <div className={`text-xs ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-600'}`}>Spaced repetition, IPA, ovozli talaffuz</div>
                </div>
              </Link>
              <Link href="/test/pronunciation" className={`flex items-center gap-4 p-5 rounded-2xl border hover:shadow-lg transition-all group ${
                theme === 'dark' ? 'border-zinc-900 hover:border-amber-500/40 bg-zinc-950/60' : 'border-zinc-200 hover:border-amber-500/60 bg-white'
              }`}>
                <span className="text-3xl">🗣️</span>
                <div>
                  <div className="font-bold group-hover:text-amber-500 transition-colors">Talaffuz Mashqi</div>
                  <div className={`text-xs ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-600'}`}>Gapni o'qing — so'z-ba-so'z baho oling</div>
                </div>
              </Link>
            </div>

            {/* Recent Activity Table */}
            <div className={`rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-md transition-colors duration-300 ${
              theme === 'dark' ? 'border-zinc-900 bg-zinc-950/40' : 'border-zinc-200 bg-white'
            }`}>
              <h2 className="text-xl font-bold tracking-tight mb-2">Recent Activity / Yaqindagi Natijalar</h2>
              <p className="text-sm text-zinc-500 mb-6">Topshirgan barcha testlaringizning xronologik tarixi.</p>

              {history.length === 0 ? (
                <div className={`text-center py-12 text-sm border border-dashed rounded-xl ${
                  theme === 'dark' ? 'text-zinc-600 border-zinc-900/60' : 'text-zinc-400 border-zinc-200'
                }`}>
                  Hali hech qanday imtihon topshirmagansiz. Boshlash uchun yuqoridagi bo'limlardan birini tanlang.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead>
                      <tr className={`border-b text-zinc-500 text-xs font-bold uppercase tracking-wider ${
                        theme === 'dark' ? 'border-zinc-900' : 'border-zinc-200'
                      }`}>
                        <th className="pb-3 font-semibold">Test turi</th>
                        <th className="pb-3 font-semibold">Sana</th>
                        <th className="pb-3 font-semibold">To'g'ri javoblar</th>
                        <th className="pb-3 font-semibold text-right">Band Score</th>
                      </tr>
                    </thead>
                    <tbody className={`divide-y ${theme === 'dark' ? 'divide-zinc-900/50' : 'divide-zinc-200/50'}`}>
                      {history.map((record) => (
                        <tr key={record.id} className={`group transition-colors ${
                          theme === 'dark' ? 'hover:bg-zinc-900/10' : 'hover:bg-zinc-50'
                        }`}>
                          <td className="py-4 font-bold flex items-center gap-2">
                            <span className="text-base">
                              {record.type === "reading" && "📖"}
                              {record.type === "listening" && "🎧"}
                              {record.type === "writing" && "✍️"}
                              {record.type === "speaking" && "🗣️"}
                            </span>
                            <span className="capitalize">{record.type} Practice</span>
                          </td>
                          <td className="py-4 text-zinc-500 font-mono text-xs">
                            {new Date(record.date).toLocaleDateString("uz-UZ", {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit"
                            })}
                          </td>
                          <td className="py-4 text-zinc-400 font-mono">
                            {record.correct !== undefined && record.total !== undefined 
                              ? `${record.correct} / ${record.total}` 
                              : "AI Evaluated"}
                          </td>
                          <td className="py-4 text-right font-black text-amber-500 font-mono text-base">
                            Band {record.band.toFixed(1)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Area */}
          <div className="space-y-8">
            {/* Goal Score Card */}
            <div className={`rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-md transition-colors duration-300 ${
              theme === 'dark' ? 'border-zinc-900 bg-zinc-950/40' : 'border-zinc-200 bg-white'
            }`}>
              <h2 className="text-lg font-bold tracking-tight mb-6">Mening Maqsadlarim</h2>
              
              <div className="space-y-4">
                <div className={`flex items-center justify-between p-4 border rounded-xl ${
                  theme === 'dark' ? 'bg-zinc-950/60 border-zinc-900' : 'bg-zinc-50 border-zinc-200'
                }`}>
                  <span className="text-sm font-semibold text-zinc-450">Target Band Score</span>
                  <span className="text-2xl font-black text-amber-500 font-mono">{userData?.target || "7.5"}</span>
                </div>
                
                <div className={`flex items-center justify-between p-4 border rounded-xl ${
                  theme === 'dark' ? 'bg-zinc-950/60 border-zinc-900' : 'bg-zinc-50 border-zinc-200'
                }`}>
                  <span className="text-sm font-semibold text-zinc-450">Current Est. Band</span>
                  <span className={`text-2xl font-black font-mono ${theme === 'dark' ? 'text-white' : 'text-zinc-900'}`}>
                    {overallEstBand !== "?" ? `Band ${overallEstBand}` : "?"}
                  </span>
                </div>
              </div>

              {userData && (
                <div className={`mt-6 pt-6 border-t text-xs space-y-2 ${
                  theme === 'dark' ? 'border-zinc-900/60 text-zinc-500' : 'border-zinc-200 text-zinc-500'
                }`}>
                  <div className="flex justify-between">
                    <span>Boshlang'ich daraja:</span>
                    <span className={`capitalize font-semibold ${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-800'}`}>{userData.level}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Kuchsiz bo'lim:</span>
                    <span className={`capitalize font-semibold ${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-800'}`}>{userData.weakness}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Imtihon muddati:</span>
                    <span className={`font-semibold ${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-800'}`}>{userData.exam_date.replace("_", " ")}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Personal AI Coach — weakness profile + targeted tips (the differentiator) */}
            <div className={`rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-md transition-colors duration-300 ${
              theme === 'dark' ? 'border-amber-500/20 bg-gradient-to-br from-amber-950/10 to-zinc-950/40' : 'border-amber-500/30 bg-gradient-to-br from-amber-50/40 to-white'
            }`}>
              <div className="flex items-center gap-2 mb-1">
                <span className="animate-pulse w-2 h-2 rounded-full bg-amber-500"></span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-amber-500 font-mono">PERSONAL AI COACH</span>
              </div>
              <h2 className="text-lg font-bold tracking-tight mb-4">Shaxsiy Tahlil</h2>

              {coach.averaged.length === 0 ? (
                <p className="text-sm text-zinc-500 leading-relaxed">
                  Writing yoki Speaking testlarini topshiring — AI murabbiy sizning <span className="text-amber-500 font-semibold">kuchsiz tomonlaringizni</span> aniqlab, maqsadli tavsiyalar beradi.
                </p>
              ) : (
                <div className="space-y-5">
                  {coach.weakest && (
                    <div className={`p-4 rounded-xl border ${theme === 'dark' ? 'bg-red-500/5 border-red-500/20' : 'bg-red-50 border-red-200'}`}>
                      <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold mb-1">Eng kuchsiz mezon</div>
                      <div className="flex items-baseline justify-between">
                        <span className="font-bold text-sm">{coach.weakest.label}</span>
                        <span className="font-mono font-black text-red-400">{coach.weakest.avg.toFixed(1)}</span>
                      </div>
                      <p className={`text-xs mt-2 ${theme === 'dark' ? 'text-zinc-400' : 'text-zinc-600'}`}>
                        Shu yo'nalishga e'tibor bering — ballingizni eng tez shu ko'taradi.
                      </p>
                    </div>
                  )}

                  {/* All sub-skills as mini bars */}
                  <div className="space-y-2">
                    {coach.averaged.map((c) => (
                      <div key={c.key} className="flex items-center gap-3">
                        <span className="text-[11px] w-32 shrink-0 text-zinc-500">{c.label}</span>
                        <div className={`flex-1 h-1.5 rounded-full overflow-hidden ${theme === 'dark' ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
                          <div className="h-full bg-gradient-to-r from-amber-500 to-yellow-500" style={{ width: `${Math.min((c.avg / 9) * 100, 100)}%` }}></div>
                        </div>
                        <span className="text-[11px] font-mono font-bold w-7 text-right text-amber-500">{c.avg.toFixed(1)}</span>
                      </div>
                    ))}
                  </div>

                  {coach.tips.length > 0 && (
                    <div className={`pt-4 border-t ${theme === 'dark' ? 'border-zinc-900' : 'border-zinc-200'}`}>
                      <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold mb-2">AI tavsiyalari</div>
                      <ul className="space-y-2">
                        {coach.tips.map((t, i) => (
                          <li key={i} className={`text-xs flex gap-2 leading-relaxed ${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-700'}`}>
                            <span className="text-amber-500 font-bold shrink-0">→</span>{t}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Quick Tips */}
            <div className={`rounded-2xl border p-6 md:p-8 shadow-xl backdrop-blur-md transition-colors duration-300 ${
              theme === 'dark' ? 'border-zinc-900 bg-zinc-950/40' : 'border-zinc-200 bg-white'
            }`}>
              <h2 className="text-lg font-bold tracking-tight mb-4">IELTS Maslahatlari</h2>
              <div className={`space-y-4 text-sm leading-relaxed ${theme === 'dark' ? 'text-zinc-400' : 'text-zinc-650'}`}>
                <div className={`p-3 border rounded-xl ${
                  theme === 'dark' ? 'bg-zinc-950/40 border-zinc-900/80' : 'bg-zinc-50 border-zinc-200'
                }`}>
                  <strong className={`${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-800'} block mb-1`}>📖 Reading Tip:</strong>
                  Paragraph heading savollarini eng birinchi bo'lib bajarmang, avval boshqa savollar orqali matn mazmunini tushunib oling.
                </div>
                <div className={`p-3 border rounded-xl ${
                  theme === 'dark' ? 'bg-zinc-950/40 border-zinc-900/80' : 'bg-zinc-50 border-zinc-200'
                }`}>
                  <strong className={`${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-800'} block mb-1`}>🎧 Listening Tip:</strong>
                  Audio boshlanishidan oldin berilgan 30-40 soniyada savollarni diqqat bilan o'qib, qanday turdagi so'z kerakligini taxmin qiling.
                </div>
                <div className={`p-3 border rounded-xl ${
                  theme === 'dark' ? 'bg-zinc-950/40 border-zinc-900/80' : 'bg-zinc-50 border-zinc-200'
                }`}>
                  <strong className={`${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-800'} block mb-1`}>✍️ Writing Tip:</strong>
                  Task 2 da kamida 250 ta so'z yozilganligiga ishonch hosil qiling, aks holda ballingiz pasayadi.
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
