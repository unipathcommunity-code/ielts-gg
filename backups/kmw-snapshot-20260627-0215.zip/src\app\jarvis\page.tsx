"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";

interface ChatMessage {
  role: "ai" | "user";
  text: string;
}

const GREETINGS = {
  kind: "Salom! Men sizning mehribon ustozingizman. Bugun qaysi mavzuda suhbatlashamiz? Xatolardan qo'rqmang, bemalol gapiring!",
  sarcastic: "Salom! Men sizning qattiqqo'l ustozingizman. IELTS dan 9.0 olishingizga ishonasizmi? Hozir gapirganingizda xatolaringizni ayab o'tirmayman. Qani, boshlang!",
  formal: "Xayrli kun. Teacher tayyorgarlik protokoli faollashtirildi. Sizning gapirish ko'nikmalaringizni tahlil qilish uchun tayyorman. Boshlash uchun gapiring.",
  toxic: "Voybo'o'y, yana sizmi? Darsga kelishga arang vaqt topdingizmi, dangasa? Qani gapiring-chi, bugun qanday grammatik xatolar bilan qulog'imni og'ritmoqchisiz?",
  romantic: "Salom jonim! O'zingiz kabi go'zal ovozingizni eshitishni intizorlik bilan kutayotgan edim. Qani, asalim, gapiring, bugun nimalar haqida suhbatlashamiz?"
};

const VOCAB_BOOSTER_DATABASE = [
  { simple: "very important", band9: "paramount", xp: 50 },
  { simple: "important", band9: "crucial", xp: 30 },
  { simple: "help", band9: "foster", xp: 30 },
  { simple: "solve", band9: "mitigate", xp: 40 },
  { simple: "bad", band9: "detrimental", xp: 40 },
  { simple: "good", band9: "advantageous", xp: 30 },
  { simple: "many", band9: "a myriad of", xp: 50 },
  { simple: "think", band9: "reckon", xp: 30 },
  { simple: "use", band9: "utilize", xp: 30 },
  { simple: "change", band9: "revolutionize", xp: 50 },
  { simple: "agree", band9: "concur", xp: 40 },
  { simple: "show", band9: "illustrate", xp: 30 }
];

const renderCyberFace = (stage: string) => {
  const isSpeaking = stage === "speaking";
  const isListening = stage === "listening";
  const isThinking = stage === "thinking";
  
  return (
    <svg className="w-36 h-36 cyber-face-container text-cyan-400 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M25 35 C25 20, 75 20, 75 35 C75 55, 65 80, 50 85 C35 80, 25 55, 25 35 Z" stroke="currentColor" strokeWidth="2.5" className="neon-glow-cyan" />
      <ellipse cx="40" cy="42" rx="3.5" ry="3.5" fill="currentColor" className="avatar-blink text-cyan-400" />
      <ellipse cx="60" cy="42" rx="3.5" ry="3.5" fill="currentColor" className="avatar-blink text-cyan-400" />
      <path d="M50 45 L50 53 L47 56" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path 
        d="M40 65 Q50 65 60 65" 
        stroke="currentColor" 
        strokeWidth="3.5" 
        strokeLinecap="round"
        className={
          isSpeaking 
            ? "avatar-mouth-speaking" 
            : isListening 
              ? "avatar-mouth-listening" 
              : isThinking 
                ? "avatar-mouth-thinking" 
                : "avatar-mouth-idle"
        }
      />
      <path d="M30 30 C35 25, 45 25, 48 28" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.5" />
      <path d="M70 30 C65 25, 55 25, 52 28" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.5" />
    </svg>
  );
};

const renderRoboTutor = (stage: string) => {
  const isSpeaking = stage === "speaking";
  const isListening = stage === "listening";
  const isThinking = stage === "thinking";
  
  return (
    <svg className="w-36 h-36 text-purple-400 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="25" y="25" width="50" height="42" rx="10" stroke="currentColor" strokeWidth="2.5" className="neon-glow-purple" />
      <rect x="18" y="38" width="7" height="16" rx="3" fill="currentColor" />
      <rect x="75" y="38" width="7" height="16" rx="3" fill="currentColor" />
      <line x1="50" y1="25" x2="50" y2="15" stroke="currentColor" strokeWidth="2.5" />
      <circle cx="50" cy="12" r="4" fill="currentColor" className={isThinking ? "animate-ping" : ""} />
      
      <g className={isThinking ? "robot-eye-thinking-left" : ""}>
        <circle cx="40" cy="45" r="7" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="40" cy="45" r="2.5" fill="currentColor" />
        {isThinking && <line x1="40" y1="38" x2="40" y2="52" stroke="currentColor" strokeWidth="1" />}
      </g>
      <g className={isThinking ? "robot-eye-thinking-right" : ""}>
        <circle cx="60" cy="45" r="7" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="60" cy="45" r="2.5" fill="currentColor" />
        {isThinking && <line x1="60" y1="38" x2="60" y2="52" stroke="currentColor" strokeWidth="1" />}
      </g>
      
      {isSpeaking ? (
        <g className="avatar-mouth-speaking">
          <line x1="38" y1="58" x2="62" y2="58" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <line x1="44" y1="55" x2="56" y2="55" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <line x1="44" y1="61" x2="56" y2="61" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </g>
      ) : isListening ? (
        <line x1="38" y1="58" x2="62" y2="58" stroke="currentColor" strokeWidth="3" strokeLinecap="round" className="avatar-mouth-listening" />
      ) : isThinking ? (
        <line x1="46" y1="58" x2="54" y2="58" stroke="currentColor" strokeWidth="3" strokeLinecap="round" className="avatar-mouth-thinking" />
      ) : (
        <line x1="42" y1="58" x2="58" y2="58" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" className="avatar-mouth-idle" />
      )}
    </svg>
  );
};

const renderPandaMascot = (stage: string) => {
  const isSpeaking = stage === "speaking";
  const isListening = stage === "listening";
  
  return (
    <svg className="w-36 h-36 text-emerald-455 mx-auto" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="28" cy="28" r="10" fill="currentColor" className={`panda-ear-l ${isSpeaking || isListening ? "panda-ear-l-wiggle" : ""}`} />
      <circle cx="72" cy="28" r="10" fill="currentColor" className={`panda-ear-r ${isSpeaking || isListening ? "panda-ear-r-wiggle" : ""}`} />
      <circle cx="50" cy="52" r="30" stroke="currentColor" strokeWidth="2.5" fill="#0c101d" className="neon-glow-emerald" />
      
      <ellipse cx="40" cy="48" rx="6" ry="8" transform="rotate(-15 40 48)" fill="currentColor" opacity="0.3" />
      <ellipse cx="60" cy="48" rx="6" ry="8" transform="rotate(15 60 48)" fill="currentColor" opacity="0.3" />
      
      <circle cx="40" cy="48" r="3.5" fill="currentColor" className="avatar-blink" />
      <circle cx="60" cy="48" r="3.5" fill="currentColor" className="avatar-blink" />
      <circle cx="39.5" cy="46.5" r="1" fill="#fff" />
      <circle cx="59.5" cy="46.5" r="1" fill="#fff" />
      
      <polygon points="48,56 52,56 50,58" fill="currentColor" />
      
      <path 
        d="M44 63 Q50 63 56 63" 
        stroke="currentColor" 
        strokeWidth="3" 
        strokeLinecap="round"
        className={
          isSpeaking 
            ? "avatar-mouth-speaking" 
            : isListening 
              ? "avatar-mouth-listening" 
              : "avatar-mouth-idle"
        }
      />
    </svg>
  );
};

export default function JarvisTutor() {
  const [stage, setStage] = useState<"idle" | "listening" | "thinking" | "speaking">("idle");
  const [transcript, setTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const [personality, setPersonality] = useState<"kind" | "sarcastic" | "formal" | "toxic" | "romantic">("sarcastic");
  const [jarvisText, setJarvisText] = useState(GREETINGS.sarcastic);
  const [conversation, setConversation] = useState<ChatMessage[]>([{ role: "ai", text: GREETINGS.sarcastic }]);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [notice, setNotice] = useState<string | null>(null);
  const [conversationMode, setConversationMode] = useState<"tutor" | "casual">("tutor");
  const [customVoiceId, setCustomVoiceId] = useState("");
  const [customAzureKey, setCustomAzureKey] = useState("");
  const [customAzureRegion, setCustomAzureRegion] = useState("");

  const [avatarStyle, setAvatarStyle] = useState<"orb" | "face" | "robot" | "animal">("orb");
  const [verbosity, setVerbosity] = useState<"concise" | "normal" | "detailed">("normal");
  const [xp, setXp] = useState<number>(0);
  const [xpAnimation, setXpAnimation] = useState<{ active: boolean; message: string } | null>(null);
  const [vocabTip, setVocabTip] = useState<{ simple: string; band9: string } | null>(null);

  const loadAzureToken = async () => {
    const savedKey = localStorage.getItem("ielts_custom_azure_key") || "";
    const savedRegion = localStorage.getItem("ielts_custom_azure_region") || "";
    try {
      const res = await fetch("/api/speaking/azure-token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: savedKey || undefined, region: savedRegion || undefined })
      });
      if (res.ok) {
        const data = await res.json();
        setAzureConfig(data);
        const savedUseAzure = localStorage.getItem("ielts_use_azure_speech");
        if (savedUseAzure !== "false") setUseAzure(true);
      } else {
        setAzureConfig(null);
        setUseAzure(false);
      }
    } catch (err) {
      setAzureConfig(null);
      setUseAzure(false);
    }
  };

  const [gender, setGender] = useState<"male" | "female">("male");
  const [rate, setRate] = useState(0.95);
  const [pitch, setPitch] = useState(1.0);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState("");
  const [noSpeechTimeout, setNoSpeechTimeout] = useState<number>(30);
  const noSpeechTimeoutRefVal = useRef(noSpeechTimeout);

  const [showHistory, setShowHistory] = useState(false);
  const [useElevenLabs, setUseElevenLabs] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [silenceThreshold, setSilenceThreshold] = useState<number>(2.0);
  const silenceThresholdRef = useRef(silenceThreshold);

  const [language, setLanguage] = useState<"english" | "korean" | "chinese" | "uzbek">("english");
  const languageRef = useRef(language);

  // Azure Speech states
  const [speechSDK, setSpeechSDK] = useState<any>(null);
  const [azureConfig, setAzureConfig] = useState<{ token: string; region: string } | null>(null);
  const [useAzure, setUseAzure] = useState(false);

  // Refs
  const recognitionRef = useRef<any>(null);
  const azureRecognizerRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const activeUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const stageRef = useRef(stage);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const isSessionActiveRef = useRef<boolean>(false);
  const noSpeechTimeoutRef = useRef<any>(null);
  const silenceTimerRef = useRef<any>(null);
  const useAzureRef = useRef(false);

  useEffect(() => {
    noSpeechTimeoutRefVal.current = noSpeechTimeout;
  }, [noSpeechTimeout]);

  useEffect(() => {
    silenceThresholdRef.current = silenceThreshold;
  }, [silenceThreshold]);

  useEffect(() => {
    stageRef.current = stage;
  }, [stage]);

  useEffect(() => {
    useAzureRef.current = useAzure && !!speechSDK && !!azureConfig;
  }, [useAzure, speechSDK, azureConfig]);

  const showNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => {
      setNotice(null);
    }, 4000);
  };

  // Load Saved settings & Fetch Azure Token
  useEffect(() => {
    const saved = localStorage.getItem("ielts_theme");
    if (saved === "light" || saved === "dark") {
      setTheme(saved);
    }
    const savedGender = localStorage.getItem("ielts_voice_gender");
    if (savedGender === "male" || savedGender === "female") {
      setGender(savedGender as any);
    }
    const savedRate = localStorage.getItem("ielts_voice_rate");
    if (savedRate) {
      setRate(parseFloat(savedRate));
    }
    const savedPitch = localStorage.getItem("ielts_voice_pitch");
    if (savedPitch) {
      setPitch(parseFloat(savedPitch));
    }
    const savedVoiceName = localStorage.getItem("ielts_voice_name");
    if (savedVoiceName) {
      setSelectedVoiceName(savedVoiceName);
    }
    const savedNoSpeech = localStorage.getItem("ielts_no_speech_timeout");
    if (savedNoSpeech) {
      setNoSpeechTimeout(parseInt(savedNoSpeech));
    }
    const savedElevenLabs = localStorage.getItem("ielts_use_eleven_labs");
    if (savedElevenLabs !== null) {
      setUseElevenLabs(savedElevenLabs === "true");
    }
    const savedSilence = localStorage.getItem("ielts_silence_threshold");
    if (savedSilence) {
      setSilenceThreshold(parseFloat(savedSilence));
    }
    const savedLang = localStorage.getItem("ielts_practice_language");
    if (savedLang === "english" || savedLang === "korean" || savedLang === "chinese" || savedLang === "uzbek") {
      setLanguage(savedLang as any);
    }
    const savedConvMode = localStorage.getItem("ielts_conversation_mode");
    if (savedConvMode === "tutor" || savedConvMode === "casual") {
      setConversationMode(savedConvMode as any);
    }
    const savedCustomVoice = localStorage.getItem("ielts_custom_voice_id");
    if (savedCustomVoice) {
      setCustomVoiceId(savedCustomVoice);
    }
    const savedAzureKey = localStorage.getItem("ielts_custom_azure_key");
    const savedAzureRegion = localStorage.getItem("ielts_custom_azure_region");
    if (savedAzureKey) setCustomAzureKey(savedAzureKey);
    if (savedAzureRegion) setCustomAzureRegion(savedAzureRegion);

    const savedAvatar = localStorage.getItem("ielts_avatar_style");
    if (savedAvatar === "orb" || savedAvatar === "face" || savedAvatar === "robot" || savedAvatar === "animal") {
      setAvatarStyle(savedAvatar);
    }
    const savedVerbosity = localStorage.getItem("ielts_verbosity");
    if (savedVerbosity === "concise" || savedVerbosity === "normal" || savedVerbosity === "detailed") {
      setVerbosity(savedVerbosity);
    }
    const savedXp = localStorage.getItem("ielts_vocab_xp");
    if (savedXp) {
      setXp(parseInt(savedXp));
    }

    loadAzureToken();

    // Dynamic Azure SDK Import
    import("microsoft-cognitiveservices-speech-sdk")
      .then(SDK => setSpeechSDK(SDK))
      .catch(err => console.warn("Failed to load Azure Speech SDK:", err));
  }, []);

  const awardXp = (amount: number, message: string) => {
    setXp(prev => {
      const next = prev + amount;
      localStorage.setItem("ielts_vocab_xp", next.toString());
      return next;
    });
    setXpAnimation({ active: true, message });
    setTimeout(() => {
      setXpAnimation(null);
    }, 4000);
  };

  const checkVocabularyBooster = (text: string) => {
    const lowerText = text.toLowerCase();
    
    // Check if used band 9 word
    for (const item of VOCAB_BOOSTER_DATABASE) {
      const band9Regex = new RegExp(`\\b${item.band9}\\b`, 'i');
      if (band9Regex.test(lowerText)) {
        awardXp(item.xp, `Used "${item.band9}" instead of "${item.simple}" (+${item.xp} XP)!`);
        setVocabTip(null);
        return;
      }
    }
    
    // Check if used simple word instead
    for (const item of VOCAB_BOOSTER_DATABASE) {
      const simpleRegex = new RegExp(`\\b${item.simple}\\b`, 'i');
      if (simpleRegex.test(lowerText)) {
        setVocabTip({ simple: item.simple, band9: item.band9 });
        return;
      }
    }
  };

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    localStorage.setItem("ielts_theme", next);
  };

  const handleSaveLanguage = (lang: "english" | "korean" | "chinese" | "uzbek") => {
    setLanguage(lang);
    localStorage.setItem("ielts_practice_language", lang);
  };

  const stopListeningAndAnalyzeRef = useRef<any>(null);
  useEffect(() => {
    stopListeningAndAnalyzeRef.current = stopListeningAndAnalyze;
  });

  // Dynamically update Speech Recognition language
  useEffect(() => {
    languageRef.current = language;
    if (recognitionRef.current) {
      if (language === "korean") {
        recognitionRef.current.lang = "ko-KR";
      } else if (language === "chinese") {
        recognitionRef.current.lang = "zh-CN";
      } else if (language === "uzbek") {
        recognitionRef.current.lang = "uz-UZ";
      } else {
        recognitionRef.current.lang = "en-US";
      }
    }
  }, [language]);

  // Update greeting when personality, mode or language changes
  useEffect(() => {
    let greet = "";
    if (conversationMode === "casual") {
      if (language === "korean") {
        greet = "안녕하세요! 만나서 반가워요. 오늘 하루 어때요?";
      } else if (language === "chinese") {
        greet = "你好！很高兴和你聊天。今天过得怎么样？";
      } else if (language === "uzbek") {
        greet = "Salom! Siz bilan suhbatlashishdan xursandman. Bugun qandaysiz?";
      } else {
        greet = "Hey there! It's so good to talk to you. How is your day going so far?";
      }
    } else {
      greet = GREETINGS[personality];
    }
    setJarvisText(greet);
    setConversation([{ role: "ai", text: greet }]);
    setTranscript("");
    setInterimTranscript("");
    setStage("idle");
    stopAllSpeech();
  }, [personality, conversationMode, language]);

  // Reset silence timer and no-speech timer
  const resetNoSpeechTimeout = () => {
    if (noSpeechTimeoutRef.current) clearTimeout(noSpeechTimeoutRef.current);
    const timeoutDuration = noSpeechTimeoutRefVal.current * 1000;
    noSpeechTimeoutRef.current = setTimeout(() => {
      isSessionActiveRef.current = false;
      stopListening();
      setStage("idle");
      showNotice(`Jimlik sababli muloqot vaqtincha to'xtatildi (${noSpeechTimeoutRefVal.current}s).`);
    }, timeoutDuration);
  };

  // Initialize Browser Speech Recognition & Load System Voices
  useEffect(() => {
    if (typeof window !== "undefined") {
      synthRef.current = window.speechSynthesis;
      
      const loadVoices = () => {
        if (synthRef.current) {
          const availableVoices = synthRef.current.getVoices();
          setVoices(availableVoices);
          
          const savedVoiceName = localStorage.getItem("ielts_voice_name");
          if (!savedVoiceName) {
            let defaultVoice = availableVoices.find(v => v.lang.includes("en-GB") && v.name.toLowerCase().includes("female"));
            if (!defaultVoice) defaultVoice = availableVoices.find(v => v.lang.includes("en-US") && v.name.toLowerCase().includes("female"));
            if (!defaultVoice) defaultVoice = availableVoices.find(v => v.lang.includes("en"));
            if (defaultVoice) {
              setSelectedVoiceName(defaultVoice.name);
            }
          }
        }
      };
      
      loadVoices();
      if (synthRef.current && synthRef.current.onvoiceschanged !== undefined) {
        synthRef.current.onvoiceschanged = loadVoices;
      }

      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event: any) => {
          let finalTrans = "";
          let interimTrans = "";
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const text = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTrans += text + " ";
            } else {
              interimTrans += text;
            }
          }
          if (finalTrans) {
            setTranscript((prev) => prev + finalTrans);
            setInterimTranscript("");
          } else {
            setInterimTranscript(interimTrans);
          }

          resetNoSpeechTimeout();
          
          if ((finalTrans + interimTrans).trim().length > 0 && silenceThresholdRef.current > 0 && stageRef.current === "listening") {
            if (silenceTimerRef.current) {
              clearTimeout(silenceTimerRef.current);
            }
            silenceTimerRef.current = setTimeout(() => {
              stopListeningAndAnalyzeRef.current();
            }, silenceThresholdRef.current * 1000);
          }
        };

        recognitionRef.current.onend = () => {
          if (stageRef.current === "listening" && !useAzureRef.current) {
            try {
              recognitionRef.current.start();
            } catch (e) {
              console.log("Auto-restart ignored:", e);
            }
          }
        };

        recognitionRef.current.onerror = (event: any) => {
          console.warn("Speech recognition error:", event.error);
        };
      }
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAllSpeech();
      if (azureRecognizerRef.current) {
        try { azureRecognizerRef.current.close(); } catch (_) {}
      }
    };
  }, []);

  const speakBrowser = (text: string, onEnd?: () => void) => {
    if (synthRef.current) {
      synthRef.current.resume();
      synthRef.current.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      activeUtteranceRef.current = utterance;

      const selectedVoice = voices.find(v => v.name === selectedVoiceName);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
        utterance.lang = selectedVoice.lang;
      } else {
        const voicesList = synthRef.current.getVoices();
        let targetVoice = voicesList.find(v => v.lang.includes("en-GB") && v.name.toLowerCase().includes(gender));
        if (!targetVoice) targetVoice = voicesList.find(v => v.lang.includes("en-US") && v.name.toLowerCase().includes(gender));
        if (!targetVoice) targetVoice = voicesList.find(v => v.lang.includes("en"));
        if (targetVoice) {
          utterance.voice = targetVoice;
          utterance.lang = targetVoice.lang;
        } else {
          utterance.lang = "en-US";
        }
      }

      utterance.rate = rate;
      utterance.pitch = pitch;

      setStage("speaking");
      utterance.onend = () => {
        setStage("idle");
        if (onEnd) onEnd();
      };
      utterance.onerror = (e) => {
        console.warn("Speech error", e);
        setStage("idle");
        if (onEnd) onEnd();
      };

      synthRef.current.speak(utterance);
    } else {
      setStage("idle");
      if (onEnd) onEnd();
    }
  };

  const stopAllSpeech = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
    }
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.pause();
        activeAudioRef.current.currentTime = 0;
      } catch (e) {
        console.warn("Audio pause error:", e);
      }
      activeAudioRef.current = null;
    }
  };

  /**
   * speakWithAzureTTS – uses Azure Neural TTS for a given language.
   * Returns a promise that resolves when audio completes.
   */
  const speakWithAzureTTS = async (text: string, lang: string, onEnd?: () => void) => {
    if (!text.trim()) {
      if (onEnd) onEnd();
      return;
    }
    const azureKey = customAzureKey || '';
    const azureRegion = customAzureRegion || azureConfig?.region || '';
    try {
      const response = await fetch('/api/speaking/azure-tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, language: lang, gender, key: azureKey || undefined, region: azureRegion || undefined })
      });
      if (!response.ok) throw new Error('Azure TTS failed');
      const blob = await response.blob();
      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);
      activeAudioRef.current = audio;
      audio.playbackRate = rate;
      audio.onended = () => {
        activeAudioRef.current = null;
        if (onEnd) onEnd();
      };
      audio.onerror = () => {
        activeAudioRef.current = null;
        if (onEnd) onEnd();
      };
      await audio.play();
    } catch (err) {
      console.warn('Azure TTS error:', err);
      if (onEnd) onEnd();
    }
  };

  const speak = async (text: string, onEnd?: () => void, uzbekText?: string) => {
    stopAllSpeech();
    setStage("speaking");

    // If there is Uzbek text (e.g. a correction in Uzbek) and Azure is configured,
    // speak the Uzbek part first with Azure uz-UZ, then the English part.
    if (uzbekText && uzbekText.trim() && useAzure && azureConfig) {
      await speakWithAzureTTS(uzbekText, 'uzbek', async () => {
        // After Uzbek correction is spoken, speak the follow-up question
        if (text && text.trim()) {
          const lang = language === 'uzbek' ? 'uzbek' : language;
          if (useAzure && azureConfig) {
            await speakWithAzureTTS(text, lang, () => {
              setStage('idle');
              if (onEnd) onEnd();
            });
          } else {
            speakElevenLabs(text, onEnd);
          }
        } else {
          setStage('idle');
          if (onEnd) onEnd();
        }
      });
      return;
    }

    // If language is Uzbek, always prefer Azure TTS (ElevenLabs has no uz-UZ voice)
    if (language === 'uzbek' && useAzure && azureConfig) {
      await speakWithAzureTTS(text, 'uzbek', () => {
        setStage('idle');
        if (onEnd) onEnd();
      });
      return;
    }

    // Default: ElevenLabs or browser
    speakElevenLabs(text, onEnd);
  };

  const speakElevenLabs = async (text: string, onEnd?: () => void) => {
    if (useElevenLabs) {
      try {
        const response = await fetch('/api/speaking/synth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            text, 
            gender,
            model_id: 'eleven_multilingual_v2',
            stability: 0.38,
            style: 0.15,
            voiceId: customVoiceId || undefined
          })
        });

        if (!response.ok) throw new Error('ElevenLabs synthesis failed');

        const blob = await response.blob();
        const audioUrl = URL.createObjectURL(blob);
        const audio = new Audio(audioUrl);
        activeAudioRef.current = audio;

        audio.preservesPitch = false;
        // @ts-ignore
        if (typeof audio.webkitPreservesPitch !== 'undefined') {
          // @ts-ignore
          audio.webkitPreservesPitch = false;
        }
        audio.playbackRate = pitch !== 1.0 ? rate * pitch : rate;

        audio.onended = () => {
          activeAudioRef.current = null;
          setStage("idle");
          if (onEnd) onEnd();
        };

        audio.onerror = (e) => {
          activeAudioRef.current = null;
          console.warn("Audio playback error, falling back to browser voice", e);
          speakBrowser(text, onEnd);
        };

        await audio.play();
      } catch (error) {
        activeAudioRef.current = null;
        console.warn("ElevenLabs failed, falling back to browser voice:", error);
        speakBrowser(text, onEnd);
      }
    } else {
      speakBrowser(text, onEnd);
    }
  };

  const toggleJarvis = () => {
    if (stage === "idle") {
      startListening();
    } else if (stage === "listening") {
      stopListeningAndAnalyze();
    } else if (stage === "speaking" || stage === "thinking") {
      isSessionActiveRef.current = false;
      stopAllSpeech();
      stopListening();
      if (noSpeechTimeoutRef.current) {
        clearTimeout(noSpeechTimeoutRef.current);
      }
      setStage("idle");
    }
  };

  const startBrowserListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
        setStage("listening");
      } catch (e) {
        console.warn("Browser SpeechRecognition failed:", e);
      }
    } else {
      showNotice("Sizning brauzeringizda ovozni aniqlash moslamasi topilmadi.");
    }
  };

  const startListening = async () => {
    isSessionActiveRef.current = true;
    setTranscript("");
    setInterimTranscript("");
    resetNoSpeechTimeout();

    if (useAzure && speechSDK && azureConfig) {
      try {
        if (azureRecognizerRef.current) {
          try { azureRecognizerRef.current.stopContinuousRecognitionAsync(); } catch (_) {}
        }
        const { token, region } = azureConfig;
        const speechConfig = speechSDK.SpeechConfig.fromAuthorizationToken(token, region);
        
        if (language === "korean") speechConfig.speechRecognitionLanguage = "ko-KR";
        else if (language === "chinese") speechConfig.speechRecognitionLanguage = "zh-CN";
        else if (language === "uzbek") speechConfig.speechRecognitionLanguage = "uz-UZ";
        else speechConfig.speechRecognitionLanguage = "en-US";

        const pronConfig = new speechSDK.PronunciationAssessmentConfig(
          "", // unscripted
          speechSDK.PronunciationAssessmentGradingSystem.HundredPoint,
          speechSDK.PronunciationAssessmentGranularity.Phoneme,
          true
        );

        const audioConfig = speechSDK.AudioConfig.fromDefaultMicrophoneInput();
        const recognizer = new speechSDK.SpeechRecognizer(speechConfig, audioConfig);
        pronConfig.applyTo(recognizer);

        recognizer.recognizing = (s: any, e: any) => {
          setInterimTranscript(e.result.text);
          resetNoSpeechTimeout();
          if (e.result.text.trim() && silenceThresholdRef.current > 0) {
            if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
            silenceTimerRef.current = setTimeout(() => stopListeningAndAnalyzeRef.current(), silenceThresholdRef.current * 1000);
          }
        };

        recognizer.recognized = (s: any, e: any) => {
          if (e.result.reason === speechSDK.ResultReason.RecognizedSpeech) {
            const text = e.result.text;
            if (text) {
              setTranscript(prev => (prev + " " + text).trim());
              setInterimTranscript("");
              resetNoSpeechTimeout();
              if (silenceThresholdRef.current > 0) {
                if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
                silenceTimerRef.current = setTimeout(() => stopListeningAndAnalyzeRef.current(), silenceThresholdRef.current * 1000);
              }
            }
          }
        };

        azureRecognizerRef.current = recognizer;
        recognizer.startContinuousRecognitionAsync();
        setStage("listening");
      } catch (err) {
        console.error("Failed starting Azure Recognizer:", err);
        startBrowserListening();
      }
    } else {
      startBrowserListening();
    }
  };

  const stopListening = () => {
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    try { recognitionRef.current?.stop(); } catch (_) {}
    if (azureRecognizerRef.current) {
      try { azureRecognizerRef.current.stopContinuousRecognitionAsync(); } catch (_) {}
      azureRecognizerRef.current = null;
    }
  };

  const stopListeningAndAnalyze = async () => {
    if (noSpeechTimeoutRef.current) {
      clearTimeout(noSpeechTimeoutRef.current);
    }
    stopListening();

    const finalAnswer = (transcript + " " + interimTranscript).trim();
    setInterimTranscript("");

    if (!finalAnswer) {
      showNotice("Iltimos, mikrofonga biror narsa gapiring.");
      setStage("idle");
      return;
    }

    checkVocabularyBooster(finalAnswer);

    const updatedConversation = [...conversation, { role: "user" as const, text: finalAnswer }];
    setConversation(updatedConversation);
    setStage("thinking");
    setJarvisText("...");

    try {
      const response = await fetch('/api/speaking/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation: updatedConversation,
          personality: personality,
          language: language,
          conversationMode: conversationMode,
          verbosity: verbosity
        })
      });

      if (!response.ok) {
        throw new Error('Teacher javob bera olmadi. Tizimda xatolik.');
      }

      const data = await response.json();
      const aiReply = data.nextResponse;
      const speechText = data.speechText || aiReply;
      const uzbekTts = data.uzbekText || '';

      setJarvisText(aiReply);
      setConversation(prev => [...prev, { role: "ai" as const, text: aiReply }]);
      speak(speechText, () => {
        if (isSessionActiveRef.current) {
          startListening();
        }
      }, uzbekTts);
    } catch (error: any) {
      console.warn("Teacher API error:", error);
      const fallbackReplies = {
        kind: "Uzr, biroz aloqa yaxshi emas. Hammasi joyida, qaytadan gapirib ko'ring!",
        sarcastic: "Internetim qotib qoldi, lekin sizning ingliz tili xatolaringiz baribir ko'rinib turibdi. Qaytadan gapiring!",
        formal: "Tizim xatoligi yuz berdi. Iltimos, qaytadan urinib ko'ring.",
        toxic: "Tizim ham sizning signalingizdan charchadi shekilli, xatolik yuz berdi. Tezda qaytadan urinib ko'ring!",
        romantic: "Voy baxtim, aloqa uzilib qoldi. Sizni yana eshitishim uchun qaytadan gapira olasizmi?"
      };
      const fallbackSpeech = {
        kind: "Sorry, I had a connection issue. Please say that again.",
        sarcastic: "My server lagged, but your English mistakes are still there. Say it again!",
        formal: "A system error occurred. Please try again.",
        toxic: "Even the system is tired of your signal, an error occurred. Speak again!",
        romantic: "Oh dear, the connection was lost. Could you speak again for me?"
      };
      const fallbackText = fallbackReplies[personality];
      const fallbackSpeechText = fallbackSpeech[personality];
      
      setJarvisText(fallbackText);
      setConversation(prev => [...prev, { role: "ai" as const, text: fallbackText }]);
      speak(fallbackSpeechText, () => {
        if (isSessionActiveRef.current) {
          startListening();
        }
      });
    }
  };

  const isDark = theme === "dark";

  return (
    <div className={`min-h-screen flex flex-col font-sans overflow-hidden selection:bg-cyan-500/20 selection:text-cyan-400 relative transition-colors duration-300 ${
      isDark ? 'bg-[#020205] text-white' : 'bg-[#f4f5f8] text-[#18181b]'
    }`}>
      {notice && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className={`px-4 py-3 rounded-xl border backdrop-blur-md shadow-2xl flex items-center gap-2 text-xs font-semibold ${
            isDark 
              ? 'bg-zinc-950/80 border-cyan-500/30 text-cyan-400' 
              : 'bg-white/90 border-cyan-500/20 text-cyan-700'
          }`}>
            <span className="animate-pulse">🔔</span>
            {notice}
          </div>
        </div>
      )}
      
      {/* Background cyber glows */}
      <div className={`absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full blur-[130px] transition-colors duration-1000 pointer-events-none -z-10 ${
        isDark ? 'opacity-10' : 'opacity-15'
      } ${
        personality === 'kind' ? 'bg-emerald-500' :
        personality === 'formal' ? 'bg-purple-600' :
        personality === 'toxic' ? 'bg-rose-500' :
        personality === 'romantic' ? 'bg-sky-500' :
        'bg-amber-500'
      }`}></div>

      <header className="p-6 flex justify-between items-center z-10">
        <Link href="/dashboard" className={`transition-colors uppercase text-[10px] tracking-widest font-mono font-bold ${
          isDark ? 'text-zinc-550 hover:text-cyan-400' : 'text-zinc-500 hover:text-cyan-600'
        }`}>
          [ Terminate Session ]
        </Link>
        
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-[10px] uppercase font-mono font-black tracking-widest text-zinc-500">
            <span className={`w-1.5 h-1.5 rounded-full ${useElevenLabs ? "bg-emerald-500" : "bg-zinc-700"}`} />
            ElevenLabs: {useElevenLabs ? "ON" : "OFF"}
            <span className="w-1.5 h-1.5 rounded-full ml-2 bg-zinc-700" style={useAzure ? { backgroundColor: "#10b981" } : undefined} />
            Azure: {useAzure ? "Active" : "OFF"}
          </div>

          <button
            onClick={toggleTheme}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
              isDark
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                : 'bg-white border-zinc-200 text-zinc-700 hover:text-black shadow-sm'
            }`}
          >
            {isDark ? "☀️ Light" : "🌙 Dark"}
          </button>
          
          <button
            onClick={() => setShowSettings(true)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
              isDark
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                : 'bg-white border-zinc-200 text-zinc-700 hover:text-black shadow-sm'
            }`}
          >
            ⚙️ Sozlamalar
          </button>
          
          {xp > 0 && (
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 font-mono text-[9px] font-black uppercase tracking-wider shadow-[0_0_10px_rgba(16,185,129,0.15)]`}>
              <span>🏆 Vocab XP:</span>
              <span>{xp}</span>
            </div>
          )}
          
          <div className={`font-bold tracking-widest uppercase text-xs font-mono ${
            isDark ? 'text-cyan-500' : 'text-cyan-600'
          }`}>
            TEACHER // {conversationMode === "casual" ? "Casual Chat" : "IELTS Protocol"}
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6 relative">
        {/* Cyber grid background */}
        <div className={`absolute inset-0 bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none -z-10 ${
          isDark
            ? 'bg-[linear-gradient(to_right,#0b0b14_1px,transparent_1px),linear-gradient(to_bottom,#0b0b14_1px,transparent_1px)]'
            : 'bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)]'
        }`}></div>

        {/* Teacher Core (3D Morphing Liquid Orb) */}
        <button 
          onClick={toggleJarvis}
          className={`relative w-48 h-48 md:w-60 md:h-60 rounded-full border flex items-center justify-center cursor-pointer group z-10 orb-3d ${
            stage === 'listening' 
              ? 'orb-3d-glow-rose text-rose-500 orb-listening-anim scale-105'
              : stage === 'thinking'
                ? 'orb-3d-glow-sky text-sky-500 orb-thinking-anim scale-105'
                : stage === 'speaking'
                  ? `orb-speaking-anim scale-105 ${
                      personality === 'kind' ? 'orb-3d-glow-emerald text-emerald-500' :
                      personality === 'formal' ? 'orb-3d-glow-purple text-purple-500' :
                      personality === 'toxic' ? 'orb-3d-glow-rose text-rose-500' :
                      personality === 'romantic' ? 'orb-3d-glow-sky text-sky-500' :
                      'orb-3d-glow-amber text-amber-500'
                    }`
                  : `orb-morph-anim ${
                      personality === 'kind' ? 'orb-3d-glow-emerald text-emerald-500' :
                      personality === 'formal' ? 'orb-3d-glow-purple text-purple-500' :
                      personality === 'toxic' ? 'orb-3d-glow-rose text-rose-500' :
                      personality === 'romantic' ? 'orb-3d-glow-sky text-sky-500' :
                      'orb-3d-glow-amber text-amber-500'
                    }`
          }`}
        >
          {/* Dynamic 3D Ripple Rings on listening */}
          {stage === 'listening' && (
            <>
              <div className="ripple-ring ripple-ring-1 text-rose-500/30"></div>
              <div className="ripple-ring ripple-ring-2 text-rose-500/20"></div>
              <div className="ripple-ring ripple-ring-3 text-rose-500/10"></div>
            </>
          )}
          
          {/* Inner metallic rotating rings */}
          {avatarStyle === "orb" && (
            <>
              <div className="absolute inset-4 border border-zinc-500/5 rounded-full animate-[spin_12s_linear_infinite] pointer-events-none"></div>
              <div className="absolute inset-8 border border-zinc-500/5 rounded-full animate-[spin_18s_linear_infinite_reverse] pointer-events-none"></div>
            </>
          )}
          
          <div className="text-center px-4 select-none z-20 w-full flex items-center justify-center">
            {avatarStyle === "orb" ? (
              <>
                {stage === "idle" && (
                  <div className="flex flex-col items-center gap-1.5 animate-pulse">
                    <span className="text-2xl drop-shadow-md">🎙️</span>
                    <span className="font-mono text-[9px] uppercase tracking-widest font-bold opacity-80 drop-shadow-md">
                      Tap to Speak
                    </span>
                  </div>
                )}
                {stage === "listening" && (
                  <div className="flex flex-col items-center gap-1.5">
                    <span className="text-2xl animate-ping text-rose-500">🔴</span>
                    <span className="font-mono text-[9px] uppercase tracking-widest font-bold text-rose-400 drop-shadow-md">
                      Listening
                    </span>
                  </div>
                )}
                {stage === "thinking" && (
                  <div className="flex flex-col items-center gap-1.5">
                    <span className="text-2xl animate-spin text-sky-400">🌀</span>
                    <span className="font-mono text-[9px] uppercase tracking-widest font-bold text-sky-400 drop-shadow-md">
                      Thinking
                    </span>
                  </div>
                )}
                {stage === "speaking" && (
                  <div className="flex flex-col items-center gap-1.5">
                    <div className="flex gap-1 items-center justify-center h-5">
                      <div className="w-1 h-3 bg-current rounded animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-1 h-5 bg-current rounded animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-1 h-2 bg-current rounded animate-bounce" style={{ animationDelay: '0.3s' }}></div>
                      <div className="w-1 h-4 bg-current rounded animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                    <span className="font-mono text-[9px] uppercase tracking-widest font-bold opacity-80 drop-shadow-md">
                      Speaking
                    </span>
                  </div>
                )}
              </>
            ) : (
              <div className="flex items-center justify-center w-full">
                {avatarStyle === "face" && renderCyberFace(stage)}
                {avatarStyle === "robot" && renderRoboTutor(stage)}
                {avatarStyle === "animal" && renderPandaMascot(stage)}
              </div>
            )}
          </div>
        </button>

        {avatarStyle !== "orb" && (
          <div className={`mt-4 px-3.5 py-1.5 rounded-full text-[9px] uppercase font-mono tracking-widest font-black border backdrop-blur-md shadow-lg transition-all ${
            stage === 'listening' ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 animate-pulse' :
            stage === 'thinking' ? 'bg-sky-500/10 border-sky-500/30 text-sky-400 animate-pulse' :
            stage === 'speaking' ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' :
            'bg-zinc-500/10 border-zinc-550/30 text-zinc-400'
          }`}>
            {stage === 'listening' ? '🎙️ Listening' :
             stage === 'thinking' ? '🌀 Thinking' :
             stage === 'speaking' ? '🔊 Speaking' :
             '💤 Tap to Speak'}
          </div>
        )}

        {/* Subtitles / Text Output */}
        <div className="mt-16 text-center max-w-2xl z-10 px-4">
          {/* Waveform visualizer beneath orb */}
          {stage === 'speaking' && (
            <div className="flex justify-center gap-1.5 mb-6 h-8 items-center">
              {[...Array(12)].map((_, i) => {
                const heights = ["h-3", "h-6", "h-4", "h-7", "h-2", "h-5", "h-8", "h-3", "h-6", "h-4", "h-7", "h-2"];
                return (
                  <div
                    key={i}
                    className={`w-1 rounded transition-all duration-300 ${
                      personality === 'kind' ? 'bg-emerald-500' :
                      personality === 'formal' ? 'bg-purple-500' :
                      personality === 'toxic' ? 'bg-rose-500' :
                      personality === 'romantic' ? 'bg-sky-500' : 'bg-amber-500'
                    } ${heights[i]} animate-pulse`}
                    style={{ animationDelay: `${i * 0.05}s`, animationDuration: "0.6s" }}
                  />
                );
              })}
            </div>
          )}

          <p className={`text-lg md:text-xl font-medium leading-relaxed drop-shadow-sm min-h-[60px] transition-colors ${
            isDark ? 'text-zinc-100' : 'text-zinc-800'
          }`}>
            "{jarvisText}"
          </p>

          {stage === "listening" && silenceThreshold > 0 && (
            <p className="text-[10px] uppercase font-mono text-zinc-500 animate-pulse mt-2 mb-4">
              ⏱️ Jimlik aniqlansa avtomatik yuboriladi ({silenceThreshold}s)
            </p>
          )}
          
          {(transcript || interimTranscript) && stage === "listening" && (
            <div className={`mt-8 border rounded-xl p-4 text-left max-w-md mx-auto shadow-2xl animate-in fade-in transition-all ${
              isDark ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white border-zinc-200'
            }`}>
              <p className="text-[10px] uppercase font-bold tracking-wider text-rose-500 font-mono block mb-2">Live Transcript:</p>
              <p className={`text-sm italic font-mono ${
                isDark ? 'text-zinc-400' : 'text-zinc-650'
              }`}>
                {transcript} <span className={isDark ? 'text-zinc-600 not-italic' : 'text-zinc-400 not-italic'}>{interimTranscript}</span>
              </p>
            </div>
          )}
        </div>

        {/* Vocabulary Booster Suggestion Box */}
        {vocabTip && (
          <div className={`mt-6 p-4 rounded-xl border animate-in fade-in slide-in-from-bottom-2 duration-300 max-w-md mx-auto shadow-2xl flex items-center justify-between gap-4 z-15 relative ${
            isDark ? 'bg-zinc-950/90 border-emerald-500/30' : 'bg-emerald-50/90 border-emerald-500/20'
          }`}>
            <div className="flex flex-col gap-1 text-left">
              <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-400 font-mono">💡 Band 9 Vocabulary Tip</span>
              <span className={`text-xs leading-normal ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>
                You used <strong className="text-rose-500 font-bold">"{vocabTip.simple}"</strong>. Next time, try using <strong className="text-emerald-400 font-bold">"{vocabTip.band9}"</strong> instead to boost your IELTS score!
              </span>
            </div>
            <button 
              onClick={() => setVocabTip(null)} 
              className={`text-xs p-1 opacity-60 hover:opacity-100 ${isDark ? 'text-white' : 'text-black'}`}
            >
              ✕
            </button>
          </div>
        )}

        {/* XP Level Up Toast */}
        {xpAnimation?.active && (
          <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 animate-bounce">
            <div className="px-6 py-4 rounded-2xl bg-emerald-500 text-black border-2 border-emerald-400 shadow-[0_0_40px_rgba(16,185,129,0.6)] font-black text-center uppercase tracking-widest text-xs flex flex-col items-center gap-1">
              <span className="text-xl">✨ LEVEL UP! ✨</span>
              <span className="text-[10px] tracking-normal font-bold">{xpAnimation.message}</span>
            </div>
          </div>
        )}

        {/* Conversation Log Toggle */}
        {conversation.length > 1 && (
          <div className={`w-full max-w-xl mt-12 border-t pt-6 z-10 transition-all ${
            isDark ? 'border-zinc-900/60' : 'border-zinc-200'
          }`}>
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className={`text-[10px] font-bold font-mono tracking-widest uppercase transition-colors mx-auto block ${
                isDark ? 'text-zinc-550 hover:text-zinc-300' : 'text-zinc-450 hover:text-zinc-800'
              }`}
            >
              {showHistory ? "[ Hide Conversation Log ]" : "[ Show Conversation Log ]"}
            </button>

            {showHistory && (
              <div className="mt-4 space-y-4 max-h-[200px] overflow-y-auto pr-2">
                {conversation.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[85%] p-3.5 rounded-xl border text-sm leading-relaxed transition-all ${
                      msg.role === "user" 
                        ? (isDark ? 'bg-zinc-900/40 border-zinc-800 text-zinc-200' : 'bg-zinc-100 border-zinc-200 text-zinc-800') 
                        : (isDark ? 'bg-zinc-950/60 border-zinc-900 text-zinc-400' : 'bg-white border-zinc-200 text-zinc-500')
                    }`}>
                      <span className="text-[8px] font-bold uppercase tracking-wider font-mono block opacity-40 mb-1">
                        {msg.role === "user" ? "You" : "Teacher"}
                      </span>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Settings Modal (Overlay) */}
        {showSettings && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 animate-in fade-in-50 duration-200">
            <div className={`border p-8 rounded-2xl max-w-md w-full shadow-2xl transition-all ${
              isDark ? 'bg-zinc-950 border-zinc-900 text-white' : 'bg-white border-zinc-200 text-zinc-900'
            }`}>
              <div className="flex justify-between items-center mb-6 border-b pb-3 border-zinc-900/30 dark:border-zinc-800/60">
                <h3 className="font-bold text-base flex items-center gap-1.5">
                  <span>⚙️</span> Ovoz va Muloqot Sozlamalari
                </h3>
                <button onClick={() => setShowSettings(false)} className={`text-xl hover:opacity-75 ${isDark ? "text-zinc-400 hover:text-white" : "text-zinc-500 hover:text-black"}`}>✕</button>
              </div>
              
              <div className="space-y-5 overflow-y-auto max-h-[65vh] pr-2 scrollbar-none text-xs">
                
                {/* Language Selector */}
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Muloqot tili (Practice Language)</label>
                  <div className={`p-1 flex gap-1 border rounded-xl ${
                    isDark ? 'bg-zinc-900/50 border-zinc-850' : 'bg-zinc-50 border-zinc-200'
                  }`}>
                    {[
                      { key: "english", label: "🇺🇸 English" },
                      { key: "uzbek", label: "🇺🇿 O'zbek" },
                      { key: "korean", label: "🇰🇷 Korean" },
                      { key: "chinese", label: "🇨🇳 Chinese" }
                    ].map((langOpt) => (
                      <button
                        key={langOpt.key}
                        type="button"
                        onClick={() => handleSaveLanguage(langOpt.key as any)}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all border ${
                          language === langOpt.key
                            ? 'bg-cyan-500 text-black border-transparent shadow-sm'
                            : (isDark
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white'
                              : 'bg-white border-zinc-250 text-zinc-750 hover:text-black shadow-sm')
                        }`}
                      >
                        {langOpt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Avatar Style Selector */}
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Muloqot Avatari (AI Avatar)</label>
                  <div className={`p-1 flex gap-1 border rounded-xl ${
                    isDark ? 'bg-zinc-900/50 border-zinc-850' : 'bg-zinc-50 border-zinc-200'
                  }`}>
                    {[
                      { key: "orb", label: "🔮 Orb" },
                      { key: "face", label: "👤 Face" },
                      { key: "robot", label: "🤖 Robot" },
                      { key: "animal", label: "🐼 Mascot" }
                    ].map((opt) => (
                      <button
                        key={opt.key}
                        type="button"
                        onClick={() => {
                          setAvatarStyle(opt.key as any);
                          localStorage.setItem("ielts_avatar_style", opt.key);
                        }}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all border ${
                          avatarStyle === opt.key
                            ? 'bg-cyan-500 text-black border-transparent shadow-sm'
                            : (isDark
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white'
                              : 'bg-white border-zinc-250 text-zinc-750 hover:text-black shadow-sm')
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Verbosity Selector */}
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">AI Gapirish Hajmi (Verbosity)</label>
                  <div className={`p-1 flex gap-1 border rounded-xl ${
                    isDark ? 'bg-zinc-900/50 border-zinc-850' : 'bg-zinc-50 border-zinc-200'
                  }`}>
                    {[
                      { key: "concise", label: "Qisqa", desc: "20-30 so'z" },
                      { key: "normal", label: "O'rtacha", desc: "40-60 so'z" },
                      { key: "detailed", label: "Batafsil", desc: "70-100 so'z" }
                    ].map((opt) => (
                      <button
                        key={opt.key}
                        type="button"
                        onClick={() => {
                          setVerbosity(opt.key as any);
                          localStorage.setItem("ielts_verbosity", opt.key);
                        }}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold transition-all border ${
                          verbosity === opt.key
                            ? 'bg-cyan-500 text-black border-transparent shadow-sm'
                            : (isDark
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white'
                              : 'bg-white border-zinc-250 text-zinc-750 hover:text-black shadow-sm')
                        }`}
                        title={opt.desc}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Conversation Mode Selector */}
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Muloqot Rejimi (Conversation Mode)</label>
                  <div className={`p-1 flex gap-1 border rounded-xl ${
                    isDark ? 'bg-zinc-900/50 border-zinc-850' : 'bg-zinc-50 border-zinc-200'
                  }`}>
                    {[
                      { key: "tutor", label: "🎓 IELTS Tutor" },
                      { key: "casual", label: "💬 Casual Chat" }
                    ].map((modeOpt) => (
                      <button
                        key={modeOpt.key}
                        type="button"
                        onClick={() => {
                          setConversationMode(modeOpt.key as any);
                          localStorage.setItem("ielts_conversation_mode", modeOpt.key);
                        }}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                          conversationMode === modeOpt.key
                            ? 'bg-cyan-500 text-black border-transparent shadow-sm'
                            : (isDark
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white'
                              : 'bg-white border-zinc-250 text-zinc-750 hover:text-black shadow-sm')
                        }`}
                      >
                        {modeOpt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Personality Selector */}
                {conversationMode === "tutor" && (
                  <div className="flex flex-col gap-2 animate-in fade-in duration-200">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Ustoz Shaxsiyati (Tone)</label>
                    <div className={`p-1.5 border rounded-xl flex flex-col gap-1.5 ${
                      isDark ? 'bg-zinc-900/50 border-zinc-850' : 'bg-zinc-50 border-zinc-200'
                    }`}>
                      {[
                        { key: "kind", label: "😇 Mehribon (Kind)", desc: "Do'stona va rag'batlantiruvchi" },
                        { key: "sarcastic", label: "😈 Pichingchi (Strict)", desc: "Kinoyali va xatolarga keskin" },
                        { key: "formal", label: "👔 Rasmiy (Academic)", desc: "Akademik va jiddiy tahlil" },
                        { key: "toxic", label: "🤬 Asabiy (Toxic)", desc: "Asabi tez o'qituvchi, tanbeh beradi" },
                        { key: "romantic", label: "💖 Romantik (Emotional)", desc: "Jonim, asalim deb erkalab suhbatlashadi" }
                      ].map((p) => (
                        <button
                          key={p.key}
                          onClick={() => setPersonality(p.key as any)}
                          className={`w-full p-2.5 rounded-lg text-left transition-all border ${
                            personality === p.key
                              ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 font-bold shadow-inner'
                              : (isDark ? 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-805/30' : 'border-transparent text-zinc-650 hover:text-zinc-900 hover:bg-zinc-200/50')
                          }`}
                        >
                          <div className="text-xs">{p.label}</div>
                          <div className="text-[10px] opacity-60 font-normal leading-normal">{p.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Azure Speech settings */}
                <div className={`p-4 border rounded-xl transition-all ${isDark ? "bg-zinc-900/50 border-zinc-850" : "bg-zinc-50 border-zinc-200"}`}>
                  <div className="flex flex-col gap-1 mb-3">
                    <span className="font-extrabold text-sm flex items-center gap-1.5">
                      <span>🎯</span> Azure Speech (Talaffuz tahlili)
                    </span>
                    <span className="text-[10px] text-zinc-550 leading-normal">
                      Azure ulanishi bilan yuqori aniqlikdagi muloqot va talaffuz (pronunciation) baholash faollashadi.
                    </span>
                  </div>

                  <div className="flex flex-col gap-2.5 mb-3.5 text-left">
                    <div className="flex flex-col gap-1">
                      <label className="text-[9px] uppercase tracking-wider text-zinc-450 font-bold">API Key</label>
                      <input
                        type="password"
                        placeholder="Masalan: d0c1b7..."
                        value={customAzureKey}
                        onChange={e => {
                          setCustomAzureKey(e.target.value);
                          localStorage.setItem("ielts_custom_azure_key", e.target.value);
                        }}
                        className={`border rounded-lg p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 ${
                          isDark ? "bg-zinc-950 border-zinc-800 text-white placeholder-zinc-700" : "bg-white border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-sm"
                        }`}
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[9px] uppercase tracking-wider text-zinc-450 font-bold">Speech Region (Hudud)</label>
                      <input
                        type="text"
                        placeholder="Masalan: eastus, westeurope"
                        value={customAzureRegion}
                        onChange={e => {
                          setCustomAzureRegion(e.target.value);
                          localStorage.setItem("ielts_custom_azure_region", e.target.value);
                        }}
                        className={`border rounded-lg p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 ${
                          isDark ? "bg-zinc-950 border-zinc-800 text-white placeholder-zinc-700" : "bg-white border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-sm"
                        }`}
                      />
                    </div>
                  </div>

                  {azureConfig ? (
                    <button
                      type="button"
                      onClick={() => {
                        const v = !useAzure;
                        setUseAzure(v);
                        localStorage.setItem("ielts_use_azure_speech", v.toString());
                      }}
                      className={`w-full py-2 rounded-lg font-bold border transition-all ${
                        useAzure 
                          ? "bg-amber-500 text-black border-transparent shadow-sm"
                          : isDark ? "bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-750" : "bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50 shadow-sm"
                      }`}
                    >
                      {useAzure ? "✓ Azure Speech: FAOL" : "Azure Speech: O'CHIRILGAN"}
                    </button>
                  ) : (
                    <div className="p-3 bg-zinc-950/20 border border-zinc-800/40 dark:border-zinc-850 text-zinc-500 rounded-lg italic leading-relaxed text-[10px] text-center">
                      Kalit va regionni kiriting hamda Saqlash tugmasini bosing.
                    </div>
                  )}
                </div>

                {/* VAD Silence threshold */}
                <div className={`p-4 border rounded-xl transition-all ${isDark ? "bg-zinc-900/50 border-zinc-850" : "bg-zinc-50 border-zinc-200"}`}>
                  <div className="flex flex-col gap-1 mb-3">
                    <span className="font-extrabold text-sm">Avtomatik yuborish (VAD)</span>
                    <span className="text-[10px] text-zinc-500 leading-normal">Gapirishdan to'xtaganingizda tizim muloqotni avtomatik davom ettiradi.</span>
                  </div>
                  <div className="flex gap-2">
                    {[
                      { label: "O'chirilgan", value: 0 },
                      { label: "Tez (1.5s)", value: 1.5 },
                      { label: "O'rtacha (2s)", value: 2 },
                      { label: "Sekin (3s)", value: 3 }
                    ].map(opt => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => {
                          setSilenceThreshold(opt.value);
                          localStorage.setItem("ielts_silence_threshold", opt.value.toString());
                        }}
                        className={`flex-1 py-1.5 rounded-lg font-bold transition-all border ${
                          silenceThreshold === opt.value
                            ? "bg-cyan-500 text-black border-transparent shadow-sm"
                            : isDark ? "bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white" : "bg-white border-zinc-200 text-zinc-700 hover:text-black shadow-sm"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Auto-Stop on No Speech */}
                <div className={`p-4 border rounded-xl transition-all ${isDark ? "bg-zinc-900/50 border-zinc-850" : "bg-zinc-50 border-zinc-200"}`}>
                  <div className="flex flex-col gap-1 mb-3">
                    <span className="font-extrabold text-sm">Jimlikda avtomatik to'xtash</span>
                    <span className="text-[10px] text-zinc-500 leading-normal font-normal">Hech narsa gapirmasangiz, muloqot vaqtincha to'xtatiladi.</span>
                  </div>
                  
                  <div className="flex gap-2">
                    {[
                      { label: "30 soniya", value: 30 },
                      { label: "1 daqiqa", value: 60 }
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => {
                          setNoSpeechTimeout(opt.value);
                          localStorage.setItem("ielts_no_speech_timeout", opt.value.toString());
                        }}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                          noSpeechTimeout === opt.value
                            ? 'bg-cyan-500 text-black border-transparent shadow-sm'
                            : (isDark
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white'
                              : 'bg-white border-zinc-250 text-zinc-705 hover:text-black shadow-sm')
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* ElevenLabs Custom Voice ID */}
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">ElevenLabs Maxsus Ovoz ID (Custom Voice ID)</label>
                  <input
                    type="text"
                    placeholder="Standart ovozlarni ishlatish uchun bo'sh qoldiring"
                    value={customVoiceId}
                    onChange={e => {
                      setCustomVoiceId(e.target.value);
                      localStorage.setItem("ielts_custom_voice_id", e.target.value);
                    }}
                    className={`border rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 ${
                      isDark ? "bg-zinc-900 border-zinc-800 text-white placeholder-zinc-650" : "bg-zinc-50 border-zinc-200 text-zinc-900 placeholder-zinc-400 shadow-sm"
                    }`}
                  />
                </div>

                {/* ElevenLabs Premium TTS Toggle */}
                <div className={`flex items-center justify-between p-4 border rounded-xl transition-all ${
                  isDark ? "bg-zinc-900/50 border-zinc-850" : "bg-zinc-50 border-zinc-200"
                }`}>
                  <div className="flex flex-col">
                    <span className="font-extrabold text-sm">ElevenLabs Premium</span>
                    <span className="text-[10px] text-zinc-500">O'ta yuqori sifatli AI ovozida suhbatlashish.</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={useElevenLabs}
                    onChange={e => {
                      const val = e.target.checked;
                      setUseElevenLabs(val);
                      localStorage.setItem("ielts_use_eleven_labs", val.toString());
                    }}
                    className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                  />
                </div>

                {/* Voice Gender Selection */}
                <div className="flex flex-col gap-2">
                  <label className="font-bold uppercase tracking-wider text-zinc-500">Ovoz turi (Voice Gender)</label>
                  <div className={`p-1 border rounded-xl flex gap-1 ${isDark ? "bg-zinc-900/50 border-zinc-850" : "bg-zinc-50 border-zinc-200"}`}>
                    {[
                      { key: "male", label: "👨 Erkak (Male)" },
                      { key: "female", label: "👩 Ayol (Female)" }
                    ].map(g => (
                      <button
                        key={g.key}
                        onClick={() => {
                          setGender(g.key as any);
                          localStorage.setItem("ielts_voice_gender", g.key);
                        }}
                        className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all border ${
                          gender === g.key
                            ? "bg-cyan-500 text-black border-transparent shadow-sm"
                            : isDark ? "bg-zinc-800 border-zinc-700 text-zinc-300 hover:text-white" : "bg-white border-zinc-200 text-zinc-700 hover:text-black shadow-sm"
                        }`}
                      >
                        {g.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Speech rate / speed */}
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between font-bold uppercase tracking-wider text-zinc-500">
                    <span>Ovoz tezligi (Speed)</span>
                    <span className="font-mono text-cyan-400">{rate}x</span>
                  </div>
                  <input
                    type="range" min="0.5" max="1.5" step="0.05"
                    value={rate}
                    onChange={e => {
                      const val = parseFloat(e.target.value);
                      setRate(val);
                      localStorage.setItem("ielts_voice_rate", val.toString());
                    }}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                {/* Voice Pitch Slider */}
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between font-bold uppercase tracking-wider text-zinc-550">
                    <span>Ovoz ohangi (Pitch)</span>
                    <span className="font-mono text-cyan-400">{pitch}</span>
                  </div>
                  <input 
                    type="range" min="0.5" max="1.5" step="0.05"
                    value={pitch}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPitch(val);
                      localStorage.setItem("ielts_voice_pitch", val.toString());
                    }}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                {!useElevenLabs && (
                  <div className="flex flex-col gap-2">
                    <label className="font-bold uppercase tracking-wider text-zinc-500">Tizim ovozi (Browser Voice)</label>
                    <select
                      value={selectedVoiceName}
                      onChange={e => {
                        setSelectedVoiceName(e.target.value);
                        localStorage.setItem("ielts_voice_name", e.target.value);
                      }}
                      className={`border rounded-lg p-3 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 ${
                        isDark ? "bg-zinc-900 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900 shadow-sm"
                      }`}
                    >
                      {voices.map(v => (
                        <option key={v.name} value={v.name}>
                          {v.name} ({v.lang})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="pt-3 flex gap-4">
                  <button
                    onClick={() => speak("Testing voice configuration.", () => {})}
                    className={`flex-1 border py-3 rounded-lg font-bold uppercase tracking-wider transition-colors ${
                      isDark ? "bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-white" : "bg-zinc-50 hover:bg-zinc-100 border-zinc-250 text-zinc-800"
                    }`}
                  >
                    Test Speech
                  </button>
                  <button
                    onClick={() => {
                      loadAzureToken();
                      setShowSettings(false);
                    }}
                    className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-black py-3 rounded-lg font-bold uppercase tracking-wider transition-colors"
                  >
                    Saqlash
                  </button>
                </div>

              </div>
            </div>
          </div>
        )}

        <footer className="p-6 text-center z-10">
          <p className="text-zinc-550 text-[10px] uppercase tracking-widest font-mono">
            {stage === "idle" ? "Gapirish uchun yadro ustiga bosing" : stage === "listening" ? "Javobni yakunlash uchun yadro ustiga bosing" : "Teacher gapirmoqda..."}
          </p>
        </footer>
      </main>
    </div>
  );
}
