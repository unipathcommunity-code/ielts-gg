"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

type Step =
  | { type: "intro" }
  | { type: "social" }
  | { type: "question"; id: string; question: string; subtitle?: string; options: { label: string; value: string; emoji?: string }[]; grid?: boolean }
  | { type: "name" }
  | { type: "loading" }
  | { type: "plan" };

const STEPS: Step[] = [
  { type: "intro" },
  {
    type: "question", id: "level",
    question: "Hozirgi ingliz tili darajangiz qanday?",
    subtitle: "Bu sizga mos rejani tuzishimizga yordam beradi",
    options: [
      { label: "Beginner (A1–A2)", value: "beginner", emoji: "🌱" },
      { label: "Intermediate (B1–B2)", value: "intermediate", emoji: "📘" },
      { label: "Advanced (C1–C2)", value: "advanced", emoji: "🚀" },
      { label: "Bilmayman", value: "unknown", emoji: "🤔" },
    ],
  },
  {
    type: "question", id: "target", grid: true,
    question: "Yakuniy balingiz nechi bo'lishi kerak?",
    subtitle: "Maqsadingizni tanlang",
    options: ["5.5", "6.0", "6.5", "7.0", "7.5", "8.0", "8.5", "9.0"].map((v) => ({ label: v, value: v })),
  },
  { type: "social" },
  {
    type: "question", id: "weakness",
    question: "Qaysi bo'limda ko'proq qiynalasiz?",
    subtitle: "Rejangiz shu bo'limga ko'proq e'tibor beradi",
    options: [
      { label: "Reading / O'qish", value: "reading", emoji: "📖" },
      { label: "Listening / Eshitish", value: "listening", emoji: "🎧" },
      { label: "Writing / Yozish", value: "writing", emoji: "✍️" },
      { label: "Speaking / Gapirish", value: "speaking", emoji: "🗣️" },
    ],
  },
  {
    type: "question", id: "study_time",
    question: "Kuniga qancha vaqt ajratasiz?",
    subtitle: "Siz uchun reja tayyorlaymiz",
    options: [
      { label: "15 daqiqa — Tezkor mashqlar", value: "15m", emoji: "⚡" },
      { label: "30 daqiqa — Bir bo'lim", value: "30m", emoji: "⏱️" },
      { label: "1 soat — To'liq mashq", value: "1h", emoji: "💪" },
      { label: "2+ soat — Intensiv", value: "2h", emoji: "🔥" },
    ],
  },
  {
    type: "question", id: "exam_date",
    question: "Imtihoningiz qachon?",
    options: [
      { label: "1–2 hafta ichida", value: "2_weeks", emoji: "🔴" },
      { label: "1 oy ichida", value: "1_month", emoji: "🟠" },
      { label: "2–3 oy ichida", value: "3_months", emoji: "🟢" },
      { label: "Hali band qilmaganman", value: "not_booked", emoji: "📅" },
    ],
  },
  {
    type: "question", id: "goal",
    question: "IELTS sizga nima uchun kerak?",
    options: [
      { label: "Chet elda o'qish", value: "study", emoji: "🎓" },
      { label: "Ish / Karyera", value: "work", emoji: "💼" },
      { label: "Immigratsiya", value: "immigration", emoji: "✈️" },
      { label: "Shaxsiy rivojlanish", value: "personal", emoji: "⭐" },
    ],
  },
  { type: "name" },
  { type: "loading" },
  { type: "plan" },
];

const LEVEL_BASE: Record<string, number> = { beginner: 4.5, intermediate: 6.0, advanced: 7.5, unknown: 5.5 };

export default function StartQuiz() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const [loadPct, setLoadPct] = useState(0);
  const router = useRouter();
  const current = STEPS[step];

  const progress = (step / (STEPS.length - 1)) * 100;

  const next = () => setStep((s) => Math.min(s + 1, STEPS.length - 1));
  const back = () => setStep((s) => Math.max(s - 1, 0));

  const select = (id: string, value: string) => {
    setAnswers((a) => ({ ...a, [id]: value }));
    setTimeout(next, 150);
  };

  // Loading animation → auto-advance to plan
  useEffect(() => {
    if (current.type !== "loading") return;
    setLoadPct(0);
    const iv = setInterval(() => {
      setLoadPct((p) => {
        if (p >= 100) { clearInterval(iv); setTimeout(next, 400); return 100; }
        return p + 4;
      });
    }, 60);
    return () => clearInterval(iv);
  }, [current.type]);

  const savePlan = () => {
    const data = { ...answers, name, exam_date: answers.exam_date || "not_booked", level: answers.level || "unknown", target: answers.target || "7.0", weakness: answers.weakness || "writing" };
    localStorage.setItem("ielts_prep_data", JSON.stringify(data));
    router.push("/dashboard");
  };

  // Derived plan
  const targetBand = answers.target || "7.0";
  const projected = LEVEL_BASE[answers.level || "unknown"] || 5.5;
  const weaknessLabel: Record<string, string> = { reading: "Reading", listening: "Listening", writing: "Writing", speaking: "Speaking" };
  const weakness = weaknessLabel[answers.weakness] || "Writing";

  return (
    <div className="min-h-screen flex flex-col bg-[#09090b] text-[#f4f4f5] font-sans relative overflow-hidden">
      <div className="absolute top-0 left-1/3 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[140px] -z-10 pointer-events-none" />

      {/* Header / progress */}
      <header className="w-full px-6 py-4 flex items-center gap-4">
        {step > 1 && current.type !== "plan" && (
          <button onClick={back} className="text-zinc-500 hover:text-white text-sm">←</button>
        )}
        <div className="flex-1 h-1.5 bg-zinc-900 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-amber-500 to-yellow-500 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
        <Link href="/" className="text-sm font-bold tracking-tight shrink-0">kmw<span className="text-amber-500">.bb</span></Link>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6 w-full max-w-2xl mx-auto text-center">
        {/* INTRO */}
        {current.type === "intro" && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-7xl md:text-8xl font-black mb-4">9.0</div>
            <h1 className="text-3xl md:text-5xl font-extrabold mb-4 leading-tight">Orzu qilgan ballni <span className="text-amber-500">birinchi urinishda</span> oling</h1>
            <p className="text-zinc-400 mb-10 text-lg">7 ta savolga javob bering — shaxsiy AI rejangizga ega bo'ling.</p>
            <button onClick={next} className="bg-amber-500 hover:bg-amber-400 text-black font-bold px-10 py-4 rounded-full text-lg transition-all hover:-translate-y-0.5 shadow-xl shadow-amber-500/20">
              Boshlash →
            </button>
            <div className="mt-8 text-xs text-zinc-600">⭐ 4.8 · minglab o'quvchi ishonadi</div>
          </div>
        )}

        {/* QUESTION */}
        {current.type === "question" && (
          <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-300" key={step}>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">{current.question}</h1>
            {current.subtitle && <p className="text-zinc-500 mb-8">{current.subtitle}</p>}
            <div className={current.grid ? "grid grid-cols-2 sm:grid-cols-4 gap-3" : "flex flex-col gap-3"}>
              {current.options.map((o) => {
                const selected = answers[current.id] === o.value;
                return (
                  <button
                    key={o.value}
                    onClick={() => select(current.id, o.value)}
                    className={`p-5 rounded-2xl border-2 transition-all duration-150 font-semibold flex items-center gap-3 ${current.grid ? "justify-center text-xl" : "text-left text-lg"} ${
                      selected ? "border-amber-500 bg-amber-500/10" : "border-zinc-800 bg-zinc-950 hover:border-zinc-600 hover:bg-zinc-900"
                    }`}
                  >
                    {o.emoji && <span className="text-2xl">{o.emoji}</span>}
                    {o.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* SOCIAL PROOF */}
        {current.type === "social" && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 w-full">
            <div className="text-5xl mb-4">🎉</div>
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Siz to'g'ri joydasiz</h2>
            <div className="space-y-3 mb-8 text-left">
              {[
                { n: "Aziz", t: "Atigi 6 hafta tayyorlanib 7.5 oldim. Speaking eng ko'p qo'rqardim — har kuni AI bilan mashq qildim." },
                { n: "Malika", t: "AI Writing'ni shunchalik aniq baholaydi deb kutmagandim. Haqiqiy imtihonim bilan atigi 0.5 farq." },
              ].map((r, i) => (
                <div key={i} className="bg-zinc-950 border border-zinc-900 rounded-xl p-4">
                  <div className="text-amber-500 text-sm mb-1">★★★★★</div>
                  <p className="text-sm text-zinc-300">"{r.t}"</p>
                  <div className="text-xs text-zinc-500 mt-2">— {r.n}</div>
                </div>
              ))}
            </div>
            <p className="text-2xl font-bold mb-6">Va yana minglab 5 baholi izoh ⭐</p>
            <button onClick={next} className="bg-amber-500 hover:bg-amber-400 text-black font-bold px-10 py-3.5 rounded-full transition-all">Davom etish →</button>
          </div>
        )}

        {/* NAME */}
        {current.type === "name" && (
          <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-300">
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Ismingiz nima?</h1>
            <p className="text-zinc-500 mb-8">Rejangizni shaxsiylashtirish uchun</p>
            <input
              value={name} onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && name.trim() && next()}
              placeholder="Ismingiz" autoFocus
              className="w-full h-14 bg-zinc-950 border-2 border-zinc-800 rounded-2xl px-5 text-lg outline-none focus:border-amber-500 text-center mb-6"
            />
            <button onClick={() => name.trim() && next()} disabled={!name.trim()} className="bg-amber-500 hover:bg-amber-400 text-black font-bold px-10 py-3.5 rounded-full transition-all disabled:opacity-40">
              Davom etish →
            </button>
          </div>
        )}

        {/* LOADING */}
        {current.type === "loading" && (
          <div className="animate-in fade-in duration-300 flex flex-col items-center">
            <div className="relative w-28 h-28 mb-8">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="44" fill="none" stroke="#27272a" strokeWidth="8" />
                <circle cx="50" cy="50" r="44" fill="none" stroke="#f59e0b" strokeWidth="8" strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 44}`} strokeDashoffset={`${2 * Math.PI * 44 * (1 - loadPct / 100)}`} className="transition-all duration-100" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-2xl font-black">{loadPct}%</div>
            </div>
            <h2 className="text-xl font-bold mb-2">Shaxsiy rejangizni yaratyapmiz…</h2>
            <p className="text-zinc-500 text-sm">Javoblaringizni tahlil qilyapmiz</p>
          </div>
        )}

        {/* PLAN */}
        {current.type === "plan" && (
          <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-2xl md:text-3xl font-extrabold mb-2">{name ? `${name}, ` : ""}rejangiz tayyor! 🎯</h1>
            <p className="text-zinc-400 mb-8">Maqsadingiz uchun shaxsiy yo'l tuzdik.</p>

            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 mb-1">Hozirgi (taxminiy)</div>
                <div className="text-3xl font-black text-zinc-300">{projected.toFixed(1)}</div>
              </div>
              <div className="bg-amber-500/5 border border-amber-500/30 rounded-2xl p-5">
                <div className="text-[10px] uppercase tracking-widest text-amber-500 mb-1">Maqsad</div>
                <div className="text-3xl font-black text-amber-500">{targetBand}</div>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-6 mb-8 text-left">
              <div className="text-[10px] uppercase tracking-widest text-zinc-500 mb-3">Sizning haftalik fokus</div>
              <ul className="space-y-3 text-sm">
                <li className="flex gap-3"><span className="text-amber-500 font-bold">1</span> <span><b>{weakness}</b> — kuchsiz bo'limingiz, har kuni 1 mashq</span></li>
                <li className="flex gap-3"><span className="text-amber-500 font-bold">2</span> Jonli AI Speaking suhbati + talaffuz mashqi</li>
                <li className="flex gap-3"><span className="text-amber-500 font-bold">3</span> AI baholash bilan Writing (TR/CC/LR/GRA)</li>
                <li className="flex gap-3"><span className="text-amber-500 font-bold">4</span> Lug'at va kunlik so'z mashqi</li>
              </ul>
            </div>

            <button onClick={savePlan} className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold py-4 rounded-full text-lg transition-all shadow-xl shadow-amber-500/20">
              Rejani boshlash →
            </button>
            <p className="text-xs text-zinc-600 mt-4">Bepul boshlang — karta talab qilinmaydi.</p>
          </div>
        )}
      </main>
    </div>
  );
}
