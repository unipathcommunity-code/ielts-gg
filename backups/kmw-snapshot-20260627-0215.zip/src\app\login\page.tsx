"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const router = useRouter();

  useEffect(() => {
    const saved = localStorage.getItem("ielts_theme");
    if (saved === "light" || saved === "dark") {
      setTheme(saved);
    }
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    localStorage.setItem("ielts_theme", next);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login
    setTimeout(() => {
      // Create default user profile data if not exists
      const existingData = localStorage.getItem("ielts_prep_data");
      if (!existingData) {
        localStorage.setItem("ielts_prep_data", JSON.stringify({
          level: "intermediate",
          target: "7.5",
          weakness: "writing",
          exam_date: "1_month"
        }));
      }
      setIsLoading(false);
      router.push("/dashboard");
    }, 1000);
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between font-sans selection:bg-amber-500/20 selection:text-amber-500 relative overflow-hidden transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#09090b] text-[#f4f4f5]' : 'bg-[#f8f9fa] text-[#18181b]'
    }`}>
      {/* Background radial glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[120px] -z-10 pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-yellow-600/5 rounded-full blur-[120px] -z-10 pointer-events-none"></div>

      <header className="p-6 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold tracking-tight flex items-center gap-2 w-fit">
          <span className="bg-amber-500 text-black w-8 h-8 flex items-center justify-center rounded-lg font-black text-sm">9.0</span>
          kmw<span className="text-amber-500">.bb</span>
        </Link>

        <button
          onClick={toggleTheme}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
            theme === 'dark'
              ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
              : 'bg-zinc-100 border-zinc-200 text-zinc-700 hover:text-black'
          }`}
        >
          {theme === 'dark' ? "☀️ Light" : "🌙 Dark"}
        </button>
      </header>

      <main className="flex-1 flex items-center justify-center p-6 z-10">
        <div className={`w-full max-w-md rounded-2xl p-8 md:p-10 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-8 duration-500 border transition-all ${
          theme === 'dark' ? 'bg-zinc-950/40 border-zinc-900 text-white' : 'bg-white border-zinc-200 text-zinc-900'
        }`}>
          <div className="text-center mb-8">
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight mb-2">Xush kelibsiz</h1>
            <p className="text-sm text-zinc-500">AI tayyorgarligingizni davom ettirish uchun kiring.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="flex flex-col gap-2">
              <label className={`text-xs font-bold uppercase tracking-wider ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-400'}`}>Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className={`w-full rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all placeholder:text-zinc-500 border ${
                  theme === 'dark' 
                    ? 'bg-zinc-900/50 border-zinc-800 text-white placeholder:text-zinc-600 focus:border-amber-500' 
                    : 'bg-zinc-50 border-zinc-200 text-zinc-900 placeholder:text-zinc-400 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <label className={`text-xs font-bold uppercase tracking-wider ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-400'}`}>Parol</label>
                <Link href="#" className="text-xs text-amber-500 hover:underline">Parolni unutdingizmi?</Link>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className={`w-full rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all placeholder:text-zinc-500 border ${
                  theme === 'dark' 
                    ? 'bg-zinc-900/50 border-zinc-800 text-white placeholder:text-zinc-600 focus:border-amber-500' 
                    : 'bg-zinc-50 border-zinc-200 text-zinc-900 placeholder:text-zinc-400 focus:border-amber-500'
                }`}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-amber-500 hover:bg-amber-600 text-black font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-amber-500/10 focus:outline-none focus:ring-2 focus:ring-amber-500 disabled:opacity-50 text-sm"
            >
              {isLoading ? "Kirilmoqda..." : "Kirish"}
            </button>
          </form>

          <div className="text-center mt-8 pt-6 border-t border-zinc-900/80 text-xs text-zinc-500">
            Akkauntingiz yo'qmi?{" "}
            <Link href="/start" className="text-amber-500 font-semibold hover:underline">
              Bepul boshlang
            </Link>
          </div>
        </div>
      </main>

      <footer className="p-6 text-center text-xs text-zinc-600">
        © {new Date().getFullYear()} KMW BB Alternative. All rights reserved.
      </footer>
    </div>
  );
}
