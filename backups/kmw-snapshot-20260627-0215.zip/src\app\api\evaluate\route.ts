import { NextResponse } from 'next/server';

const READING_QUESTIONS_UNIVERSE: Record<string, string> = {
  q1: 'Definitively disproved a competing theory',
  q2: 'Modern phenomena currently trying to understand',
  q3: 'Initial observation changing the consensus',
  q4: 'Theory suggesting universe looks the same',
  q5: 'Before 1929, most scientists believed universe expanding',
  q6: 'Steady State theory proposed by CMB discoverers',
  q7: 'Dark matter makes up majority of mass'
};

const PASSAGE_DATA: Record<string, {
  keys: Record<string, string>;
  questions: Record<string, string>;
  title: string;
  text: string;
}> = {
  universe: {
    title: "The Origins of the Universe",
    keys: { q1: 'D', q2: 'E', q3: 'A', q4: 'C', q5: 'FALSE', q6: 'FALSE', q7: 'NOT GIVEN' },
    questions: READING_QUESTIONS_UNIVERSE,
    text: `Paragraph A: The question of how the universe began has puzzled philosophers and scientists for millennia. In the early 20th century, the prevailing scientific view was that the universe was static and eternal. However, this view was fundamentally challenged by Edwin Hubble's observation in 1929 that galaxies were moving away from each other, suggesting that the universe was expanding.
Paragraph B: This observation led to the formulation of the Big Bang theory. According to this model, the universe began as a hot, dense singularity approximately 13.8 billion years ago. Since then, it has been expanding and cooling, allowing for the formation of subatomic particles, and eventually simple atoms. Giant clouds of these primordial elements later coalesced through gravity to form stars and galaxies.
Paragraph C: Not all scientists immediately accepted the Big Bang theory. Fred Hoyle, Thomas Gold, and Hermann Bondi proposed an alternative known as the Steady State theory in 1948. This model suggested that the universe is continually expanding but maintaining a constant average density, with matter being continuously created to form new stars and galaxies at the same rate that old ones become unobservable.
Paragraph D: The debate between these two theories was largely settled by the discovery of the Cosmic Microwave Background (CMB) radiation in 1964 by Arno Penzias and Robert Wilson. The CMB is the residual heat from the Big Bang, spread uniformly across the universe, and its existence provided overwhelming evidence in favor of the Big Bang model, rendering the Steady State theory obsolete.
Paragraph E: Today, cosmologists continue to refine our understanding of the universe's origins and its ultimate fate. Concepts such as dark matter and dark energy have been introduced to explain anomalies in the observed rotation of galaxies and the accelerating rate of cosmic expansion.`
  },
  ai: {
    title: "The Evolution of Artificial Intelligence",
    keys: { q1: 'C', q2: 'E', q3: 'A', q4: 'B', q5: 'FALSE', q6: 'TRUE', q7: 'NOT GIVEN' },
    questions: {
      q1: 'The shift from rule-based programming to data-driven learning',
      q2: 'Future risks associated with superintelligent systems',
      q3: 'The initial standard proposed to define machine intelligence',
      q4: 'A period characterized by a decline in interest and investment',
      q5: 'Before 1950, most scientists believed expert systems were successful',
      q6: 'Turing believed machine intelligence could be achieved in the 20th century',
      q7: 'AlphaGo was developed using a hybrid of expert systems and deep learning'
    },
    text: `Paragraph A: The quest to build machines capable of human-like intelligence has its roots in early computing history. In 1950, Alan Turing famously proposed the Turing Test as a benchmark for artificial intelligence. During this early era, optimism was high, and scientists believed that creating an intelligent machine was only a few decades away.
Paragraph B: By the 1970s and 1980s, the field entered the first "AI winter" as early rule-based systems failed to scale to complex real-world problems. These expert systems, which relied on hardcoded "if-then" rules created by human experts, were brittle and could not handle uncertainty or learn from new data, leading to a loss of funding.
Paragraph C: A major paradigm shift occurred in the late 1990s and 2000s with the rise of machine learning. Instead of programming explicit rules, researchers began developing algorithms that allowed computers to learn patterns directly from massive datasets. The availability of high-performance GPUs and big data accelerated this transition.
Paragraph D: In the 2010s, deep learning—a subset of machine learning based on artificial neural networks with multiple layers—revolutionized fields like image recognition and natural language processing. Systems like AlphaGo demonstrated superhuman performance in complex tasks, capturing global attention and reviving massive commercial interest.
Paragraph E: Today, generative AI models and Large Language Models (LLMs) have achieved remarkable fluency and capability. However, critical challenges remain, including machine alignment, ethical concerns regarding bias, and the theoretical risk of artificial general intelligence (AGI) escaping human control, which keeps researchers divided.`
  },
  tea: {
    title: "The History and Impact of Tea",
    keys: { q1: 'B', q2: 'E', q3: 'A', q4: 'C', q5: 'TRUE', q6: 'FALSE', q7: 'NOT GIVEN' },
    questions: {
      q1: 'The introduction of tea to British high society',
      q2: 'Traditional tea rituals in different world regions',
      q3: 'The mythical origins of tea consumption',
      q4: 'A geopolitical conflict driven by the tea trade',
      q5: 'King Charles II married a princess who popularized tea in England',
      q6: 'Tea was originally developed as a recreational beverage in Europe',
      q7: 'Opium wars led to the establishment of tea plantations in India'
    },
    text: `Paragraph A: The discovery of tea is steeped in Chinese mythology, dating back to 2737 BC when Emperor Shen Nong allegedly tasted water into which tea leaves had accidentally drifted. For centuries, tea was consumed primarily for its medicinal properties and as a tonic to promote mental alertness among Buddhist monks.
Paragraph B: It was not until the 17th century that tea made its way to Europe via Dutch and Portuguese merchants. In England, the marriage of King Charles II to Catherine of Braganza, a Portuguese princess who loved tea, established it as a fashionable beverage among the British nobility and aristocracy.
Paragraph C: By the 18th and 19th centuries, the demand for tea in Britain had exploded, creating a massive trade imbalance with China. Because China only accepted silver in exchange for tea, the British began illicitly exporting opium to China to balance the trade, culminating in the Opium Wars.
Paragraph D: In the modern era, tea has become the second most consumed beverage in the world, surpassed only by water. Scientific research continues to highlight its numerous health benefits, including high concentrations of antioxidants, cardiovascular support, and its role in boosting cognitive function.
Paragraph E: Tea culture manifests uniquely across the globe. From the highly ritualized Japanese tea ceremony (Chado) to the social, casual nature of British afternoon tea, the beverage serves as a cornerstone of social interaction and cultural expression in diverse societies.`
  }
};

const LISTENING_TESTS_DATA: Record<string, {
  id: string;
  title: string;
  keys: Record<string, string>;
  questions: Record<string, string>;
  transcript: string;
}> = {
  campus: {
    id: "campus",
    title: "Campus Accommodation & Facilities",
    keys: {
      q1: 'SMITH',
      q2: '07123456789',
      q3: 'SINGLE',
      q4: 'A',
      q5: 'B',
      q6: 'B',
      q7: 'B'
    },
    questions: {
      q1: 'Accommodation Form: Name (Last name)',
      q2: 'Accommodation Form: Contact number',
      q3: 'Accommodation Form: Type of room',
      q4: 'Section 2: Library location',
      q5: 'Section 2: Requirement to use the gym',
      q6: 'Section 2: Swimming pool availability',
      q7: 'Section 2: Cafeteria hot meals hours'
    },
    transcript: `[Section 1] Welcome to the student accommodation services. I am here to help you register. May I have your name, please? Yes, it's John Smith. That is S-M-I-T-H. Great. And your contact number? It's 07123456789. OK. What type of room are you looking for? A single room, please. OK, we have a single room available...
[Section 2] Okay, now let me tell you about our campus facilities. The library is located in the north building, which is open from 8:00 AM to 10:00 PM daily. We also have a state-of-the-art sports center next to the library. It includes an indoor swimming pool, which is heated throughout the year, and a fully equipped gym. To use the gym, students must attend an induction session first. Lastly, the student cafeteria is in the central block, serving hot meals from 11:30 AM to 2:30 PM.`
  },
  travel: {
    id: "travel",
    title: "Travel Agency Booking & City Museum Tour",
    keys: {
      q1: 'JENKINS',
      q2: '07987654321',
      q3: '12 JULY',
      q4: 'B',
      q5: 'A',
      q6: 'C',
      q7: 'B'
    },
    questions: {
      q1: 'Travel Agency Form: Name (Last name)',
      q2: 'Travel Agency Form: Contact number',
      q3: 'Travel Agency Form: Date of the tour',
      q4: 'Section 2: Main exhibition room location',
      q5: 'Section 2: Requirement to see the royal collection',
      q6: 'Section 2: Photography rules',
      q7: 'Section 2: Gift shop hours'
    },
    transcript: `[Section 1] Good morning, City Travel Agency. How can I help you? Yes, I'd like to book a city tour. Sure. What is your name? It's Sarah Jenkins. That is J-E-N-K-I-N-S. OK, Sarah. And your contact number? It's 07987654321. Great. Which date would you like to tour? The twelfth of July, please.
[Section 2] Welcome to the City Historical Museum. Before we start, let me explain the layout. The main exhibition room is on the second floor, open from 9 AM to 5 PM. To see the special royal collection, visitors must purchase an extra ticket. Photography is strictly prohibited inside the collection hall. Finally, our gift shop is next to the exit, selling souvenirs and booklets from 10 AM to 4 PM.`
  },
  career: {
    id: "career",
    title: "Job Interview & Office Orientation",
    keys: {
      q1: 'HARRISON',
      q2: 'DAVID.H@TECH.COM',
      q3: 'SOFTWARE ENGINEER',
      q4: 'A',
      q5: 'C',
      q6: 'A',
      q7: 'B'
    },
    questions: {
      q1: 'HR Form: Name (Last name)',
      q2: 'HR Form: Contact email',
      q3: 'HR Form: Position applied for',
      q4: 'Section 2: Conference room location',
      q5: 'Section 2: Requirement to access office after 7 PM',
      q6: 'Section 2: Staff free parking location',
      q7: 'Section 2: Kitchen open hours'
    },
    transcript: `[Section 1] Hello, HR department of Tech Solutions. I am calling about my interview tomorrow. Ah, yes. Can I confirm your name, please? Yes, it's David Harrison. That is H-A-R-R-I-S-O-N. Thank you, David. Your contact email is david.h@tech.com? Yes. And what position are you interviewing for? The software engineer position.
[Section 2] Welcome to your first day at Tech Solutions. Let me show you around the office. The conference room is on the third floor, which is used for all department meetings. To access the office after 7 PM, employees must use their security badge. Free parking is available for all staff members in the basement garage. Lastly, the company kitchen is on the first floor, offering free coffee and snacks from 8:30 AM to 6 PM.`
  }
};

// Helper function to call Claude API using fetch
async function callClaude(systemPrompt: string, userPrompt: string): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error('Anthropic API key is missing. Please add it to .env.local');
  }

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4000,
      system: systemPrompt,
      messages: [
        { role: 'user', content: userPrompt }
      ]
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Claude API call failed:', errorText);
    throw new Error(`Claude API call failed: ${response.statusText} (${response.status}) - ${errorText}`);
  }

  const data = await response.json();
  if (!data.content || data.content.length === 0 || data.content[0].type !== 'text') {
    throw new Error('Invalid response structure from Claude API');
  }

  return data.content[0].text;
}

// Helper to strip markdown code blocks and parse JSON
function parseJSONResponse(text: string): any {
  let cleanText = text.trim();
  
  if (cleanText.startsWith('```')) {
    const firstNewLine = cleanText.indexOf('\n');
    if (firstNewLine !== -1) {
      cleanText = cleanText.slice(firstNewLine + 1);
    }
    if (cleanText.endsWith('```')) {
      cleanText = cleanText.slice(0, -3);
    }
    cleanText = cleanText.trim();
  }
  
  const startIdx = cleanText.indexOf('{');
  const endIdx = cleanText.lastIndexOf('}');
  if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
    cleanText = cleanText.slice(startIdx, endIdx + 1);
  }
  
  return JSON.parse(cleanText);
}

export async function POST(request: Request) {
  try {
    const { type, content, prompt, answers, passageId, azurePronunciationMetrics } = await request.json();

    // 0. WRITING TASK 1 EVALUATION
    if (type === 'writing_task1') {
      if (!content) return NextResponse.json({ error: 'Content is required' }, { status: 400 });

      const systemPrompt = `You are a Chief Cambridge IELTS Writing Examiner with 20+ years of experience. Evaluate this IELTS Academic Writing Task 1 response with absolute strictness and detail.

Task prompt: ${prompt}

Candidate's response: ${content}

Score using official IELTS Writing Task 1 band descriptors:
- Task Achievement (TA): Does it cover all key features? Is there a clear overview? Are comparisons made? Is data cited accurately?
- Coherence & Cohesion (CC): Is it well organised with clear paragraphing? Good use of cohesive devices?
- Lexical Resource (LR): Range and accuracy of vocabulary? Appropriate use of data-specific language?
- Grammatical Range & Accuracy (GRA): Variety and accuracy of grammatical structures?

Important: If the response is under 150 words, penalise TA significantly. Do not award 7.0+ unless it is truly deserved. IELTS 7.0+ is very difficult to achieve.

Return a pure JSON object with this exact structure (no markdown, no extra text):
{
  "score": "Overall Band Score rounded to nearest 0.5 (e.g. 6.5)",
  "taskResponse": "TA band score (e.g. 7.0)",
  "coherence": "CC band score (e.g. 6.0)",
  "lexical": "LR band score (e.g. 6.5)",
  "grammar": "GRA band score (e.g. 6.5)",
  "comments": "2-3 sentences of detailed examiner commentary covering all four criteria. Written in Uzbek.",
  "improvements": [
    "Aniq va amaliy maslahat 1 — Task Achievement yaxshilash uchun o'zbekcha",
    "Aniq va amaliy maslahat 2 — Lug'at boyligini oshirish bo'yicha o'zbekcha",
    "Aniq va amaliy maslahat 3 — Grammatik aniqlikni oshirish bo'yicha o'zbekcha"
  ],
  "detailedCorrections": [
    {
      "original": "The original sentence or phrase with a mistake from the student's response",
      "corrected": "The corrected, polished, academic version",
      "explanation": "Xatolik sababi va qanday qilib yaxshiroq yozish mumkinligi haqida o'zbekcha izoh"
    }
  ],
  "band9Sample": "A full Band 9 model answer for this specific Task 1 prompt. Must include a clear overview, detailed comparisons with data, and sophisticated academic vocabulary. Written entirely in English."
}`;

      const userPrompt = `Task 1 Prompt: "${prompt}"\nCandidate's Response: "${content}"`;

      const responseText = await callClaude(systemPrompt, userPrompt);
      const feedback = parseJSONResponse(responseText);
      return NextResponse.json(feedback);
    }

    // 1. WRITING EVALUATION
    if (type === 'writing') {
      if (!content) return NextResponse.json({ error: 'Content is required' }, { status: 400 });

      const systemPrompt = `You are a Chief Cambridge IELTS Writing Examiner with 20+ years of experience. You evaluate essays with absolute strictness and detail, matching the exact band descriptors for Writing Task 2.
Your goal is to provide a premium, comprehensive critique of the student's essay.

The evaluation must be written in Uzbek (except for original/corrected sentences and names of criteria) and returned as a pure JSON object.

The output JSON MUST follow this exact structure:
{
  "score": "Overall Band Score (e.g. 6.5) - strictly rounded to nearest 0.5 according to IELTS guidelines",
  "taskResponse": "Band Score for Task Response (e.g. 7.0)",
  "coherence": "Band Score for Coherence and Cohesion (e.g. 6.0)",
  "lexical": "Band Score for Lexical Resource (e.g. 6.5)",
  "grammar": "Band Score for Grammatical Range and Accuracy (e.g. 6.5)",
  "comments": "O'ta chuqur tahliliy fikr-mulohazalar o'zbek tilida. Har bir mezon bo'yicha inshoning kamchiliklari va yutuqlarini batafsil tushuntiring.",
  "improvements": [
    "Inshoning tuzilishi yoki mazmunini yaxshilash uchun 1-aniq va amaliy maslahat",
    "Lug'at boyligini (vocab) oshirish bo'yicha 2-aniq maslahat",
    "Grammatik xatolarni kamaytirish bo'yicha 3-aniq maslahat"
  ],
  "detailedCorrections": [
    {
      "original": "The original sentence or phrase with grammar/lexical mistakes from the student's essay",
      "corrected": "The corrected, polished, academic version of that sentence",
      "explanation": "Qanday xato qilingani va qoidasi haqida tushunarli o'zbekcha izoh"
    }
  ],
  "band9Sample": "Ushbu insho mavzusi bo'yicha Band 9.0 darajasidagi to'liq namuna insho (Sample Essay). U IELTS talablariga to'liq javob beruvchi kirish, asosiy qismlar va xulosa qismidan iborat bo'lishi, murakkab va o'rinli lug'at boyligi hamda mukammal grammatika bilan yozilgan bo'lishi kerak."
}

Ensure all criteria scores are realistic and strict. IELTS 7.0+ is very hard to achieve; do not award high scores unless they are truly deserved. If the essay word count is under 250 words, penalize the Task Response score significantly. Do not add any conversational intro or outro text, only the pure JSON.`;

      const userPrompt = `Topic/Prompt: "${prompt}"
Student's Essay: "${content}"`;

      const responseText = await callClaude(systemPrompt, userPrompt);
      const feedback = parseJSONResponse(responseText);
      return NextResponse.json(feedback);
    }

    // 2. SPEAKING EVALUATION
    if (type === 'speaking') {
      if (!content) return NextResponse.json({ error: 'Content is required' }, { status: 400 });

      const metricsContext = azurePronunciationMetrics
        ? `\nAdditionally, the speech was assessed by Azure Speech Pronunciation Assessment, yielding the following objective metrics (scores are on a 1-100 scale):
- Pronunciation overall score: ${azurePronunciationMetrics.pronunciation}/100
- Accuracy (phoneme pronunciation precision): ${azurePronunciationMetrics.accuracy}/100
- Fluency (speed, pauses, rhythm): ${azurePronunciationMetrics.fluency}/100
- Completeness (how many words were pronounced): ${azurePronunciationMetrics.completeness}/100
- Prosody (intonation, stress, natural melody): ${azurePronunciationMetrics.prosody}/100

Please align your band scores for Pronunciation and Fluency & Coherence with these objective measurements (e.g. a score of 80-90 typically corresponds to Band 7.5-8.5, 65-79 to Band 6.0-7.0, 50-64 to Band 5.0-5.5, and below 50 to lower bands).`
        : '';

      const systemPrompt = `You are a Chief Cambridge IELTS Speaking Examiner. You grade with absolute accuracy and strictness, following the official speaking band descriptors.
Analyze the transcribed speech of the student. Because it is a transcript of spoken language, take filler words, pauses, and repetition into account when grading Fluency & Coherence.${metricsContext}

Important: If Azure Pronunciation Metrics are not available, please note that the transcript is generated by a browser-based speech-to-text engine and may contain transcription errors, phonetic typos, or missing word endings. Do not penalize the candidate's Grammar or Vocabulary for obvious transcription errors (e.g. confusing homophones or minor missing word endings). Focus on their core vocabulary, grammatical complexity, and logic.

The evaluation must be written in Uzbek (except for original/corrected sentences and criteria names) and returned as a pure JSON object.

The output JSON MUST follow this exact structure:
{
  "overall": "Overall Band Score (e.g. 6.0) - strictly rounded to nearest 0.5 according to IELTS guidelines",
  "criteria": {
    "fluency": "Band Score for Fluency and Coherence (e.g. 6.0)",
    "lexical": "Band Score for Lexical Resource (e.g. 6.5)",
    "grammar": "Band Score for Grammatical Range and Accuracy (e.g. 5.5)",
    "pronunciation": "Band Score for Pronunciation (e.g. 6.0) - estimate based on spoken flow, hesitation, and clarity"
  },
  "transcript": "The provided student speech transcript",
  "analysis": "Talabaning gapirish ko'nikmasi bo'yicha o'ta professional tahlil o'zbek tilida. Uning ravonligi, so'z boyligi, grammatik qamrovi va talaffuz xususiyatlarini batafsil tahlil qiling.",
  "actionable_steps": [
    "Ravonlik va fikrni bog'lashni yaxshilash bo'yicha maslahat o'zbek tilida",
    "Lug'at boyligini yanada boyitish (idiomalar, sinonimlar) bo'yicha maslahat o'zbek tilida",
    "Grammatik barqarorlik va murakkab gaplarni ishlatish bo'yicha maslahat o'zbek tilida"
  ],
  "detailedCorrections": [
    {
      "original": "The student's spoken phrase containing a mistake or awkward phrasing",
      "corrected": "A natural, fluent, and correct IELTS way of saying it",
      "explanation": "Xatolik sababi va qanday qilib yaxshiroq aytish mumkinligi haqida o'zbekcha izoh"
    }
  ],
  "band9Sample": "Talaba gapirmoqchi bo'lgan fikrlarni o'z ichiga olgan, Band 9.0 darajasidagi ravon, tabiiy va mukammal inglizcha javob namunasi."
}

Ensure the grading is highly realistic and matches real Cambridge standards. Do not over-grade. Do not add any conversational intro or outro text, only the pure JSON.`;

      const userPrompt = `Cue Card/Prompt: "${prompt}"
Student's Transcribed Speech: "${content}"`;

      const responseText = await callClaude(systemPrompt, userPrompt);
      const feedback = parseJSONResponse(responseText);
      return NextResponse.json(feedback);
    }

    // 3. READING EVALUATION (GRADES MULTIPLE PASSAGES DYNAMICALLY)
    if (type === 'reading') {
      if (!answers) return NextResponse.json({ error: 'Answers are required' }, { status: 400 });

      const selectedPassageId = passageId || 'universe';
      const passageInfo = PASSAGE_DATA[selectedPassageId] || PASSAGE_DATA['universe'];

      let correctCount = 0;
      const totalCount = Object.keys(passageInfo.keys).length;
      const allQuestionsList: any[] = [];

      for (const key of Object.keys(passageInfo.keys)) {
        const userAns = (answers[key] || '').trim().toUpperCase();
        const correctAns = passageInfo.keys[key];
        if (userAns === correctAns) {
          correctCount++;
        }
        allQuestionsList.push({
          id: key,
          question: passageInfo.questions[key],
          userAnswer: userAns || '(Javob berilmagan)',
          correctAnswer: correctAns
        });
      }

      // Calculate band score
      let band = "4.0";
      if (correctCount === 7) band = "9.0";
      else if (correctCount === 6) band = "8.0";
      else if (correctCount === 5) band = "7.0";
      else if (correctCount === 4) band = "6.0";
      else if (correctCount === 3) band = "5.0";
      else if (correctCount === 2) band = "4.5";

      let explanations: Record<string, string> = {};

      try {
        const systemPrompt = `You are a helpful IELTS Reading tutor. A student completed a reading test on the passage "${passageInfo.title}".
Passage:
${passageInfo.text}

You must write a short, clear, and detailed explanation in UZBEK for each of the 7 questions.
1. State what the correct answer is and why.
2. Where the correct answer is located in the passage (refer to the paragraph or key sentence), quoting the passage text, and explaining why it matches.
3. If the student got it wrong, briefly comment on why their answer is incorrect.

Return the result as a pure JSON object mapping the Question ID to the Uzbek explanation, like this:
{
  "q1": "Tushuntirish...",
  "q2": "Tushuntirish...",
  "q3": "Tushuntirish...",
  "q4": "Tushuntirish...",
  "q5": "Tushuntirish...",
  "q6": "Tushuntirish...",
  "q7": "Tushuntirish..."
}
Do not add any markdown formatting or explanations outside the JSON.`;

        const userPrompt = `Here are the questions and student's answers:
${allQuestionsList.map(iq => `- Question ID: ${iq.id}\n  Question: ${iq.question}\n  Student's Answer: "${iq.userAnswer}"\n  Correct Answer: "${iq.correctAnswer}"`).join('\n')}`;

        const responseText = await callClaude(systemPrompt, userPrompt);
        explanations = parseJSONResponse(responseText);
      } catch (err: any) {
        console.warn("Failed to generate reading explanations:", err);
      }

      return NextResponse.json({
        correct: correctCount,
        total: totalCount,
        band,
        explanations
      });
    }

    // 4. LISTENING EVALUATION (GRADES SECTION 1 & 2 DYNAMICALLY)
    if (type === 'listening') {
      if (!answers) return NextResponse.json({ error: 'Answers are required' }, { status: 400 });

      const selectedTestId = passageId || 'campus';
      const testInfo = LISTENING_TESTS_DATA[selectedTestId] || LISTENING_TESTS_DATA['campus'];

      let correctCount = 0;
      const totalCount = Object.keys(testInfo.keys).length;
      const allQuestionsList: any[] = [];

      for (const key of Object.keys(testInfo.keys)) {
        const userAns = (answers[key] || '').trim().toUpperCase();
        const correctAns = testInfo.keys[key];
        if (userAns === correctAns) {
          correctCount++;
        }
        allQuestionsList.push({
          id: key,
          question: testInfo.questions[key],
          userAnswer: userAns || '(Javob berilmagan)',
          correctAnswer: correctAns
        });
      }

      // 7 questions total grading
      let band = "4.0";
      if (correctCount === 7) band = "9.0";
      else if (correctCount === 6) band = "8.0";
      else if (correctCount === 5) band = "7.0";
      else if (correctCount === 4) band = "6.0";
      else if (correctCount === 3) band = "5.0";
      else if (correctCount === 2) band = "4.5";
      else if (correctCount === 1) band = "4.0";

      let explanations: Record<string, string> = {};

      try {
        const systemPrompt = `You are a helpful IELTS Listening tutor. A student completed a listening test.
Audio Transcript:
"${testInfo.transcript}"

You must write a short, clear, and detailed explanation in UZBEK for each of the 7 questions.
1. State what the correct answer is and why.
2. Where the correct answer is mentioned in the audio transcript, quoting the transcription text, and explaining why it is correct.
3. If the student got it wrong, briefly comment on why their answer is incorrect.

Return the result as a pure JSON object mapping the Question ID to the Uzbek explanation, like this:
{
  "q1": "Tushuntirish...",
  "q2": "Tushuntirish...",
  "q3": "Tushuntirish...",
  "q4": "Tushuntirish...",
  "q5": "Tushuntirish...",
  "q6": "Tushuntirish...",
  "q7": "Tushuntirish..."
}
Do not add any markdown formatting or explanations outside the JSON.`;

        const userPrompt = `Here are the questions and student's answers:
${allQuestionsList.map(iq => `- Question ID: ${iq.id}\n  Question: ${iq.question}\n  Student's Answer: "${iq.userAnswer}"\n  Correct Answer: "${iq.correctAnswer}"`).join('\n')}`;

        const responseText = await callClaude(systemPrompt, userPrompt);
        explanations = parseJSONResponse(responseText);
      } catch (err: any) {
        console.warn("Failed to generate listening explanations:", err);
      }

      return NextResponse.json({
        correct: correctCount,
        total: totalCount,
        band,
        explanations
      });
    }

    return NextResponse.json({ error: 'Invalid evaluation type' }, { status: 400 });

  } catch (error: any) {
    console.error('API Error:', error);
    return NextResponse.json({ error: error.message || 'An error occurred during evaluation' }, { status: 500 });
  }
}
