"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

type Word = { word: string; ipa: string; def: string; uz: string; cefr: string; example: string };

const WORDS: Word[] = [
  { word: "ubiquitous", ipa: "/juːˈbɪkwɪtəs/", def: "present, appearing, or found everywhere", uz: "hamma joyda mavjud", cefr: "C1", example: "Smartphones have become ubiquitous in modern life." },
  { word: "mitigate", ipa: "/ˈmɪtɪɡeɪt/", def: "make something less severe or serious", uz: "yumshatmoq, kamaytirmoq", cefr: "C1", example: "Planting trees can mitigate the effects of climate change." },
  { word: "deteriorate", ipa: "/dɪˈtɪəriəreɪt/", def: "become progressively worse", uz: "yomonlashmoq", cefr: "B2", example: "Her health began to deteriorate rapidly." },
  { word: "fluctuate", ipa: "/ˈflʌktʃueɪt/", def: "rise and fall irregularly", uz: "o'zgarib turmoq", cefr: "B2", example: "Prices fluctuate according to demand." },
  { word: "exacerbate", ipa: "/ɪɡˈzæsərbeɪt/", def: "make a problem worse", uz: "kuchaytirmoq (yomon tomonga)", cefr: "C1", example: "The new policy may exacerbate unemployment." },
  { word: "paramount", ipa: "/ˈpærəmaʊnt/", def: "more important than anything else", uz: "eng muhim", cefr: "C1", example: "Safety is of paramount importance." },
  { word: "albeit", ipa: "/ɔːlˈbiːɪt/", def: "although", uz: "garchi, bo'lsa-da", cefr: "C1", example: "He accepted the job, albeit reluctantly." },
  { word: "scrutinise", ipa: "/ˈskruːtɪnaɪz/", def: "examine closely and thoroughly", uz: "sinchiklab tekshirmoq", cefr: "C1", example: "Investors scrutinise the company's accounts." },
  { word: "unprecedented", ipa: "/ʌnˈpresɪdentɪd/", def: "never done or known before", uz: "misli ko'rilmagan", cefr: "B2", example: "The pandemic caused unprecedented disruption." },
  { word: "comprehensive", ipa: "/ˌkɒmprɪˈhensɪv/", def: "complete and including everything", uz: "keng qamrovli", cefr: "B2", example: "The report offers a comprehensive analysis." },
  { word: "inevitable", ipa: "/ɪnˈevɪtəbl/", def: "certain to happen; unavoidable", uz: "muqarrar", cefr: "B2", example: "Change is inevitable in any society." },
  { word: "substantial", ipa: "/səbˈstænʃl/", def: "large in amount, value, or importance", uz: "salmoqli, katta", cefr: "B2", example: "There has been a substantial increase in sales." },
  { word: "prevalent", ipa: "/ˈprevələnt/", def: "widespread in a particular area or time", uz: "keng tarqalgan", cefr: "C1", example: "Obesity is increasingly prevalent among children." },
  { word: "detrimental", ipa: "/ˌdetrɪˈmentl/", def: "tending to cause harm", uz: "zararli", cefr: "C1", example: "Smoking is detrimental to your health." },
  { word: "alleviate", ipa: "/əˈliːvieɪt/", def: "make suffering or a problem less severe", uz: "yengillashtirmoq", cefr: "C1", example: "The medicine helped to alleviate the pain." },
  { word: "diverse", ipa: "/daɪˈvɜːs/", def: "showing a great deal of variety", uz: "xilma-xil", cefr: "B2", example: "The city has a diverse population." },
  { word: "sustainable", ipa: "/səˈsteɪnəbl/", def: "able to be maintained over time", uz: "barqaror", cefr: "B2", example: "We need a sustainable approach to energy." },
  { word: "profound", ipa: "/prəˈfaʊnd/", def: "very great or intense; deep", uz: "chuqur, teran", cefr: "C1", example: "The book had a profound effect on me." },
  { word: "compelling", ipa: "/kəmˈpelɪŋ/", def: "evoking interest or conviction", uz: "ishonarli, jalb qiluvchi", cefr: "C1", example: "She made a compelling argument." },
  { word: "notion", ipa: "/ˈnəʊʃn/", def: "a concept or belief about something", uz: "tushuncha, fikr", cefr: "B2", example: "He rejected the notion that money brings happiness." },
  { word: "enhance", ipa: "/ɪnˈhɑːns/", def: "intensify or improve the quality of", uz: "yaxshilamoq, oshirmoq", cefr: "B2", example: "Good lighting can enhance a photograph." },
  { word: "advocate", ipa: "/ˈædvəkeɪt/", def: "publicly recommend or support", uz: "yoqlamoq, targ'ib qilmoq", cefr: "C1", example: "Many experts advocate a balanced diet." },
  { word: "dilemma", ipa: "/dɪˈlemə/", def: "a difficult choice between alternatives", uz: "qiyin tanlov, dilemma", cefr: "B2", example: "She faced the dilemma of work versus family." },
  { word: "inherent", ipa: "/ɪnˈhɪərənt/", def: "existing as a natural, permanent part", uz: "tabiiy, azaliy", cefr: "C1", example: "There are risks inherent in any investment." },
  { word: "plausible", ipa: "/ˈplɔːzəbl/", def: "seeming reasonable or probable", uz: "ishonarli, maqbul", cefr: "C1", example: "That sounds like a plausible explanation." },
  { word: "discrepancy", ipa: "/dɪsˈkrepənsi/", def: "a lack of compatibility; a difference", uz: "nomutanosiblik, farq", cefr: "C1", example: "There is a discrepancy between the two reports." },
  { word: "resilient", ipa: "/rɪˈzɪliənt/", def: "able to recover quickly from difficulties", uz: "bardoshli, chidamli", cefr: "C1", example: "Children are often remarkably resilient." },
  { word: "ambiguous", ipa: "/æmˈbɪɡjuəs/", def: "open to more than one interpretation", uz: "noaniq, ikki ma'noli", cefr: "C1", example: "The question was ambiguous and confusing." },
  { word: "consensus", ipa: "/kənˈsensəs/", def: "general agreement", uz: "umumiy kelishuv", cefr: "B2", example: "There is a growing consensus on this issue." },
  { word: "tentative", ipa: "/ˈtentətɪv/", def: "not certain or fixed; provisional", uz: "taxminiy, ehtiyotkor", cefr: "C1", example: "We made a tentative plan to meet next week." },
];

type SRS = { ease: number; interval: number; due: number; reps: number };
const DAY = 86400000;

export default function VocabularyPage() {
  const [srs, setSrs] = useState<Record<string, SRS>>({});
  const [tab, setTab] = useState<"browse" | "review">("browse");
  const [cefr, setCefr] = useState("all");
  const [playing, setPlaying] = useState<string | null>(null);

  // Review session state
  const [queue, setQueue] = useState<Word[]>([]);
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("ielts_vocab_srs") || "{}");
      setSrs(saved);
    } catch {}
  }, []);

  const save = (next: Record<string, SRS>) => {
    setSrs(next);
    localStorage.setItem("ielts_vocab_srs", JSON.stringify(next));
  };

  const now = Date.now();
  const dueWords = WORDS.filter((w) => !srs[w.word] || srs[w.word].due <= now);
  const learnedCount = Object.values(srs).filter((s) => s.interval >= 1).length;

  const speak = async (text: string) => {
    if (playing) return;
    try {
      setPlaying(text);
      const res = await fetch("/api/speaking/synth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text, gender: "female" }) });
      if (!res.ok) throw new Error();
      const audio = new Audio(URL.createObjectURL(await res.blob()));
      audio.onended = () => setPlaying(null);
      await audio.play();
    } catch { setPlaying(null); }
  };

  const startReview = () => {
    setQueue(dueWords.length ? dueWords : WORDS.slice(0, 10));
    setIdx(0); setRevealed(false); setTab("review");
  };

  const rate = (q: 0 | 1 | 2 | 3) => {
    const w = queue[idx];
    const prev = srs[w.word] || { ease: 2.5, interval: 0, due: now, reps: 0 };
    let { ease, interval, reps } = prev;
    if (q === 0) { interval = 0; ease = Math.max(1.3, ease - 0.2); reps = 0; }
    else if (q === 1) { interval = Math.max(1, interval * 1.2); ease = Math.max(1.3, ease - 0.15); reps++; }
    else if (q === 2) { interval = reps === 0 ? 1 : interval * ease; reps++; }
    else { interval = (reps === 0 ? 1 : interval * ease) * 1.3; ease = ease + 0.1; reps++; }
    const due = now + (interval === 0 ? 60000 : interval * DAY); // "Again" = 1 min
    save({ ...srs, [w.word]: { ease, interval, due, reps } });

    if (idx + 1 < queue.length) { setIdx(idx + 1); setRevealed(false); }
    else { setTab("browse"); }
  };

  const filtered = cefr === "all" ? WORDS : WORDS.filter((w) => w.cefr === cefr);
  const cefrColor: Record<string, string> = { B1: "text-sky-400 bg-sky-500/10 border-sky-500/20", B2: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20", C1: "text-amber-400 bg-amber-500/10 border-amber-500/20", C2: "text-rose-400 bg-rose-500/10 border-rose-500/20" };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] font-sans">
      <header className="sticky top-0 z-30 bg-zinc-950/80 backdrop-blur border-b border-zinc-900">
        <div className="mx-auto max-w-4xl flex h-16 items-center justify-between px-6">
          <Link href="/dashboard" className="text-zinc-500 hover:text-white text-sm font-semibold">← Dashboard</Link>
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500">📖 Lug'at (Vocabulary)</span>
          <span className="text-xs text-zinc-500 font-mono">{learnedCount}/{WORDS.length}</span>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-6 py-8">
        {/* Stats + SRS card */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black">{WORDS.length}</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500">Jami so'z</div>
          </div>
          <div className="bg-amber-500/5 border border-amber-500/30 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black text-amber-500">{dueWords.length}</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500">Bugun takror</div>
          </div>
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 text-center">
            <div className="text-2xl font-black text-emerald-400">{learnedCount}</div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500">O'rganildi</div>
          </div>
        </div>

        {tab === "browse" ? (
          <>
            <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
              <div className="flex gap-2">
                {["all", "B2", "C1"].map((c) => (
                  <button key={c} onClick={() => setCefr(c)} className={`text-xs font-bold px-3 py-1.5 rounded-lg border ${cefr === c ? "bg-amber-500 text-black border-amber-500" : "bg-zinc-950 border-zinc-800 text-zinc-400"}`}>
                    {c === "all" ? "Barchasi" : c}
                  </button>
                ))}
              </div>
              <button onClick={startReview} className="bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm px-5 py-2 rounded-xl">
                🎴 Takrorlashni boshlash ({dueWords.length})
              </button>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {filtered.map((w) => (
                <div key={w.word} className="bg-zinc-950 border border-zinc-900 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-lg">{w.word}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${cefrColor[w.cefr] || ""}`}>{w.cefr}</span>
                    </div>
                    <button onClick={() => speak(w.word)} className="text-zinc-500 hover:text-amber-500 text-lg" title="Talaffuzni eshitish">
                      {playing === w.word ? "⏸" : "🔊"}
                    </button>
                  </div>
                  <div className="text-xs text-zinc-500 font-mono mb-2">{w.ipa}</div>
                  <div className="text-sm text-zinc-300 mb-1">{w.def}</div>
                  <div className="text-sm text-amber-500/90 mb-2">{w.uz}</div>
                  <div className="text-xs text-zinc-500 italic border-l-2 border-zinc-800 pl-2">"{w.example}"</div>
                </div>
              ))}
            </div>
          </>
        ) : (
          /* REVIEW (flashcards) */
          <div className="max-w-xl mx-auto">
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => setTab("browse")} className="text-zinc-500 hover:text-white text-sm">← Chiqish</button>
              <span className="text-xs text-zinc-500 font-mono">{idx + 1} / {queue.length}</span>
            </div>
            {queue[idx] && (
              <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 min-h-[320px] flex flex-col items-center justify-center text-center">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-3xl font-black">{queue[idx].word}</span>
                  <button onClick={() => speak(queue[idx].word)} className="text-zinc-500 hover:text-amber-500 text-2xl">🔊</button>
                </div>
                <div className="text-sm text-zinc-500 font-mono mb-6">{queue[idx].ipa}</div>

                {!revealed ? (
                  <button onClick={() => setRevealed(true)} className="bg-zinc-900 border border-zinc-800 px-8 py-3 rounded-xl font-bold hover:bg-zinc-800">
                    Ma'nosini ko'rsatish
                  </button>
                ) : (
                  <div className="animate-in fade-in duration-200 w-full">
                    <div className="text-zinc-300 mb-1">{queue[idx].def}</div>
                    <div className="text-amber-500 font-semibold mb-3">{queue[idx].uz}</div>
                    <div className="text-xs text-zinc-500 italic mb-6">"{queue[idx].example}"</div>
                    <div className="grid grid-cols-4 gap-2">
                      <button onClick={() => rate(0)} className="py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-bold hover:bg-red-500/20">Qaytadan</button>
                      <button onClick={() => rate(1)} className="py-3 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-bold hover:bg-orange-500/20">Qiyin</button>
                      <button onClick={() => rate(2)} className="py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold hover:bg-emerald-500/20">Yaxshi</button>
                      <button onClick={() => rate(3)} className="py-3 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs font-bold hover:bg-sky-500/20">Oson</button>
                    </div>
                  </div>
                )}
              </div>
            )}
            <p className="text-center text-xs text-zinc-600 mt-6">Spaced repetition: bilgan so'zlaringiz kamroq, unutganlaringiz tez-tez ko'rsatiladi.</p>
          </div>
        )}
      </main>
    </div>
  );
}
