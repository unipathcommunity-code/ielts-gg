import { NextResponse } from 'next/server';

/**
 * Azure Neural TTS API Route
 * Supports Uzbek (uz-UZ-SardorNeural / uz-UZ-MadinaNeural) and other languages.
 * Used as primary TTS when Azure is active, especially for Uzbek text.
 */
export async function POST(request: Request) {
  try {
    const { text, language, gender, key, region } = await request.json();

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const azureKey = key || process.env.AZURE_SPEECH_KEY;
    const azureRegion = region || process.env.AZURE_SPEECH_REGION;

    if (!azureKey || !azureRegion) {
      return NextResponse.json(
        { error: 'Azure Speech credentials not configured' },
        { status: 404 }
      );
    }

    // Select the best Azure Neural voice based on language and gender
    let voiceName = 'en-US-JennyNeural'; // default English female
    const lang = language || 'english';
    const isFemalePref = gender === 'female';

    if (lang === 'uzbek') {
      // Uzbek Neural voices – clean, native pronunciation
      voiceName = isFemalePref ? 'uz-UZ-MadinaNeural' : 'uz-UZ-SardorNeural';
    } else if (lang === 'korean') {
      voiceName = isFemalePref ? 'ko-KR-SunHiNeural' : 'ko-KR-InJoonNeural';
    } else if (lang === 'chinese') {
      voiceName = isFemalePref ? 'zh-CN-XiaoxiaoNeural' : 'zh-CN-YunxiNeural';
    } else {
      // English – British examiner-style voices
      voiceName = isFemalePref ? 'en-GB-SoniaNeural' : 'en-GB-RyanNeural';
    }

    // Determine the XML lang attribute for SSML
    const xmlLang =
      lang === 'uzbek'
        ? 'uz-UZ'
        : lang === 'korean'
        ? 'ko-KR'
        : lang === 'chinese'
        ? 'zh-CN'
        : 'en-GB';

    // Build SSML for natural prosody
    const ssml = `<speak version='1.0' xml:lang='${xmlLang}'>
  <voice name='${voiceName}'>
    <prosody rate='0%' pitch='0%'>
      ${escapeXml(text)}
    </prosody>
  </voice>
</speak>`;

    const ttsResponse = await fetch(
      `https://${azureRegion}.tts.speech.microsoft.com/cognitiveservices/v1`,
      {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': azureKey,
          'Content-Type': 'application/ssml+xml',
          'X-Microsoft-OutputFormat': 'audio-16khz-128kbitrate-mono-mp3',
          'User-Agent': 'IELTSgg-AzureTTS/1.0',
        },
        body: ssml,
      }
    );

    if (!ttsResponse.ok) {
      const errText = await ttsResponse.text();
      console.error('Azure TTS Error:', errText);
      return NextResponse.json(
        { error: 'Azure TTS failed: ' + errText },
        { status: ttsResponse.status }
      );
    }

    const audioBuffer = await ttsResponse.arrayBuffer();
    return new NextResponse(audioBuffer, {
      headers: {
        'Content-Type': 'audio/mpeg',
        'Cache-Control': 'no-store',
      },
    });
  } catch (error: any) {
    console.error('Azure TTS route error:', error);
    return NextResponse.json(
      { error: error.message || 'An error occurred during Azure TTS' },
      { status: 500 }
    );
  }
}

function escapeXml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
