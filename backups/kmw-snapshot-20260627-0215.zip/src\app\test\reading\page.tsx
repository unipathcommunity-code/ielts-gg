"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useDisplaySettings, DisplaySettings, MIN_SCALE, MAX_SCALE } from "@/components/DisplaySettings";
import { supabase } from "@/lib/supabase";

interface TestRecord {
  id: string;
  type: string;
  date: string;
  band: number;
  correct: number;
  total: number;
  passageId: string;
}

const VOCABULARY_LISTS: Record<string, { word: string; definition: string; translation: string }[]> = {
  universe: [
    { word: "Millennia", definition: "A period of a thousand years.", translation: "Ming yilliklar" },
    { word: "Prevailing", definition: "Existing at a particular time; current.", translation: "Keng tarqalgan/ustun" },
    { word: "Singularity", definition: "A point at which a function takes an infinite value (physics singularity).", translation: "Singulyarlik" },
    { word: "Coalesced", definition: "Combined elements in a mass or whole.", translation: "Birlashgan/qo'shilgan" },
    { word: "Obsolete", definition: "No longer produced or used; out of date.", translation: "Eskirgan/iste'moldan chiqqan" }
  ],
  ai: [
    { word: "Benchmark", definition: "A standard or point of reference against which things may be compared.", translation: "Mezon/o'lchov" },
    { word: "Expert systems", definition: "Software designed to solve complex problems in a specific domain.", translation: "Ekspert tizimlari" },
    { word: "Paradigm shift", definition: "A fundamental change in approach or underlying assumptions.", translation: "Fikrlash o'zgarishi/burilish" },
    { word: "Neural networks", definition: "Computer systems modeled on the human brain's structure.", translation: "Neyron tarmoqlari" },
    { word: "Machine alignment", definition: "Ensuring that artificial intelligence systems align with human goals.", translation: "Mashina muvofiqligi/moslashuvi" }
  ],
  tea: [
    { word: "Steeped in", definition: "Surrounded or filled with a quality or influence.", translation: "Shimib olingan/boy" },
    { word: "Medicinal properties", definition: "Properties used to cure or prevent diseases.", translation: "Shifobaxsh xususiyatlar" },
    { word: "Trade imbalance", definition: "A situation in which a country's imports exceed its exports.", translation: "Savdo nomutanosibligi" },
    { word: "Cardiovascular", definition: "Relating to the heart and blood vessels.", translation: "Yurak-qon tomir" },
    { word: "Cornerstone", definition: "An important quality or feature on which a thing is based.", translation: "Poydevor/asosiy tosh" }
  ]
};

const PASSAGES: Record<string, {
  id: string;
  title: string;
  paragraphs: { label: string; text: string }[];
  matchingQuestions: { id: string; number: string; text: string }[];
  tfQuestions: { id: string; number: string; text: string }[];
  keys: Record<string, string>;
  qQuestions: Record<string, string>;
}> = {
  universe: {
    id: "universe",
    title: "The Origins of the Universe",
    paragraphs: [
      { label: "A", text: "The question of how the universe began has puzzled philosophers and scientists for millennia. In the early 20th century, the prevailing scientific view was that the universe was static and eternal. However, this view was fundamentally challenged by Edwin Hubble's observation in 1929 that galaxies were moving away from each other, suggesting that the universe was expanding." },
      { label: "B", text: "This observation led to the formulation of the Big Bang theory. According to this model, the universe began as a hot, dense singularity approximately 13.8 billion years ago. Since then, it has been expanding and cooling, allowing for the formation of subatomic particles, and eventually simple atoms. Giant clouds of these primordial elements later coalesced through gravity to form stars and galaxies." },
      { label: "C", text: "Not all scientists immediately accepted the Big Bang theory. Fred Hoyle, Thomas Gold, and Hermann Bondi proposed an alternative known as the Steady State theory in 1948. This model suggested that the universe is continually expanding but maintaining a constant average density, with matter being continuously created to form new stars and galaxies at the same rate that old ones become unobservable as a consequence of their increasing distance and velocity of recession." },
      { label: "D", text: "The debate between these two theories was largely settled by the discovery of the Cosmic Microwave Background (CMB) radiation in 1964 by Arno Penzias and Robert Wilson. The CMB is the residual heat from the Big Bang, spread uniformly across the universe, and its existence provided overwhelming evidence in favor of the Big Bang model, rendering the Steady State theory obsolete." },
      { label: "E", text: "Today, cosmologists continue to refine our understanding of the universe's origins and its ultimate fate. Concepts such as dark matter and dark energy have been introduced to explain anomalies in the observed rotation of galaxies and the accelerating rate of cosmic expansion. Despite these advancements, the very instant of the Big Bang remains shrouded in mystery, lying beyond the current limits of our physical theories." }
    ],
    matchingQuestions: [
      { id: "q1", number: "1.", text: "The discovery that definitively disproved a competing theory." },
      { id: "q2", number: "2.", text: "Modern phenomena that scientists are currently trying to understand." },
      { id: "q3", number: "3.", text: "The initial observation that changed the scientific consensus about the universe." },
      { id: "q4", number: "4.", text: "A theory suggesting that the universe has always looked roughly the same." }
    ],
    tfQuestions: [
      { id: "q5", number: "5.", text: "Before 1929, most scientists believed the universe was expanding." },
      { id: "q6", number: "6.", text: "The Steady State theory was proposed by the same scientists who discovered the CMB." },
      { id: "q7", number: "7.", text: "Dark matter makes up the majority of the universe's mass." }
    ],
    keys: { q1: 'D', q2: 'E', q3: 'A', q4: 'C', q5: 'FALSE', q6: 'FALSE', q7: 'NOT GIVEN' },
    qQuestions: {
      q1: 'Definitively disproved a competing theory',
      q2: 'Modern phenomena currently trying to understand',
      q3: 'Initial observation changing the consensus',
      q4: 'Theory suggesting universe looks the same',
      q5: 'Before 1929, most scientists believed universe expanding',
      q6: 'Steady State theory proposed by CMB discoverers',
      q7: 'Dark matter makes up majority of mass'
    }
  },
  ai: {
    id: "ai",
    title: "The Evolution of Artificial Intelligence",
    paragraphs: [
      { label: "A", text: "The quest to build machines capable of human-like intelligence has its roots in early computing history. In 1950, Alan Turing famously proposed the Turing Test as a benchmark for artificial intelligence. During this early era, optimism was high, and scientists believed that creating an intelligent machine was only a few decades away." },
      { label: "B", text: "By the 1970s and 1980s, the field entered the first \"AI winter\" as early rule-based systems failed to scale to complex real-world problems. These expert systems, which relied on hardcoded \"if-then\" rules created by human experts, were brittle and could not handle uncertainty or learn from new data, leading to a loss of funding." },
      { label: "C", text: "A major paradigm shift occurred in the late 1990s and 2000s with the rise of machine learning. Instead of programming explicit rules, researchers began developing algorithms that allowed computers to learn patterns directly from massive datasets. The availability of high-performance GPUs and big data accelerated this transition." },
      { label: "D", text: "In the 2010s, deep learning—a subset of machine learning based on artificial neural networks with multiple layers—revolutionized fields like image recognition and natural language processing. Systems like AlphaGo demonstrated superhuman performance in complex tasks, capturing global attention and reviving massive commercial interest." },
      { label: "E", text: "Today, generative AI models and Large Language Models (LLMs) have achieved remarkable fluency and capability. However, critical challenges remain, including machine alignment, ethical concerns regarding bias, and the theoretical risk of artificial general intelligence (AGI) escaping human control, which keeps researchers divided." }
    ],
    matchingQuestions: [
      { id: "q1", number: "1.", text: "The shift from rule-based programming to data-driven learning." },
      { id: "q2", number: "2.", text: "Future risks associated with superintelligent systems." },
      { id: "q3", number: "3.", text: "The initial standard proposed to define machine intelligence." },
      { id: "q4", number: "4.", text: "A period characterized by a decline in interest and investment." }
    ],
    tfQuestions: [
      { id: "q5", number: "5.", text: "Before 1950, most scientists believed expert systems were successful." },
      { id: "q6", number: "6.", text: "Turing believed machine intelligence could be achieved in the 20th century." },
      { id: "q7", number: "7.", text: "AlphaGo was developed using a hybrid of expert systems and deep learning." }
    ],
    keys: { q1: 'C', q2: 'E', q3: 'A', q4: 'B', q5: 'FALSE', q6: 'TRUE', q7: 'NOT GIVEN' },
    qQuestions: {
      q1: 'The shift from rule-based programming to data-driven learning',
      q2: 'Future risks associated with superintelligent systems',
      q3: 'The initial standard proposed to define machine intelligence',
      q4: 'A period characterized by a decline in interest and investment',
      q5: 'Before 1950, most scientists believed expert systems were successful',
      q6: 'Turing believed machine intelligence could be achieved in the 20th century',
      q7: 'AlphaGo was developed using a hybrid of expert systems and deep learning'
    }
  },
  tea: {
    id: "tea",
    title: "The History and Impact of Tea",
    paragraphs: [
      { label: "A", text: "The discovery of tea is steeped in Chinese mythology, dating back to 2737 BC when Emperor Shen Nong allegedly tasted water into which tea leaves had accidentally drifted. For centuries, tea was consumed primarily for its medicinal properties and as a tonic to promote mental alertness among Buddhist monks." },
      { label: "B", text: "It was not until the 17th century that tea made its way to Europe via Dutch and Portuguese merchants. In England, the marriage of King Charles II to Catherine of Braganza, a Portuguese princess who loved tea, established it as a fashionable beverage among the British nobility and aristocracy." },
      { label: "C", text: "By the 18th and 19th centuries, the demand for tea in Britain had exploded, creating a massive trade imbalance with China. Because China only accepted silver in exchange for tea, the British began illicitly exporting opium to China to balance the trade, culminating in the Opium Wars." },
      { label: "D", text: "In the modern era, tea has become the second most consumed beverage in the world, surpassed only by water. Scientific research continues to highlight its numerous health benefits, including high concentrations of antioxidants, cardiovascular support, and its role in boosting cognitive function." },
      { label: "E", text: "Tea culture manifests uniquely across the globe. From the highly ritualized Japanese tea ceremony (Chado) to the social, casual nature of British afternoon tea, the beverage serves as a cornerstone of social interaction and cultural expression in diverse societies." }
    ],
    matchingQuestions: [
      { id: "q1", number: "1.", text: "The introduction of tea to British high society." },
      { id: "q2", number: "2.", text: "Traditional tea rituals in different world regions." },
      { id: "q3", number: "3.", text: "The mythical origins of tea consumption." },
      { id: "q4", number: "4.", text: "A geopolitical conflict driven by the tea trade." }
    ],
    tfQuestions: [
      { id: "q5", number: "5.", text: "King Charles II married a princess who popularized tea in England." },
      { id: "q6", number: "6.", text: "Tea was originally developed as a recreational beverage in Europe." },
      { id: "q7", number: "7.", text: "Opium wars led to the establishment of tea plantations in India." }
    ],
    keys: { q1: 'B', q2: 'E', q3: 'A', q4: 'C', q5: 'TRUE', q6: 'FALSE', q7: 'NOT GIVEN' },
    qQuestions: {
      q1: 'The introduction of tea to British high society',
      q2: 'Traditional tea rituals in different world regions',
      q3: 'The mythical origins of tea consumption',
      q4: 'A geopolitical conflict driven by the tea trade',
      q5: 'King Charles II married a princess who popularized tea in England',
      q6: 'Tea was originally developed as a recreational beverage in Europe',
      q7: 'Opium wars led to the establishment of tea plantations in India'
    }
  }
};

export default function ReadingTest() {
  const [passageId, setPassageId] = useState("universe");
  const [timeLeft, setTimeLeft] = useState(60 * 60); // 60 minutes
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState<any>(null);
  const [highlightResetKey, setHighlightResetKey] = useState(0);
  const [showVocab, setShowVocab] = useState(false);
  const [testHistory, setTestHistory] = useState<Record<string, TestRecord>>({});
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const display = useDisplaySettings();
  const { fontScale, scheme, readerActive } = display;

  // Content is loaded from Supabase; the inline constants act as an offline fallback.
  const [passages, setPassages] = useState<typeof PASSAGES>(PASSAGES);
  const [vocabLists, setVocabLists] = useState<typeof VOCABULARY_LISTS>(VOCABULARY_LISTS);

  const currentPassage = passages[passageId] || passages.universe;
  // Background applied to the reading panel when a custom scheme is on
  const panelStyle = readerActive ? { backgroundColor: scheme.bg } : undefined;
  // Text colour + zoom applied to the actual content
  const contentStyle = { zoom: fontScale, ...(readerActive ? { color: scheme.text } : {}) };
  // Applied to the question cards so questions/answers follow the colour scheme too
  const cardStyle = readerActive ? { backgroundColor: scheme.bg, color: scheme.text, borderColor: "transparent" } : undefined;
  const qTextStyle = readerActive ? { color: scheme.text } : undefined;

  const loadHistory = () => {
    const historyJson = localStorage.getItem("ielts_test_history");
    if (historyJson) {
      try {
        const history: TestRecord[] = JSON.parse(historyJson);
        const map: Record<string, TestRecord> = {};
        history.forEach((record) => {
          if (record.type === "reading" && record.passageId) {
            if (!map[record.passageId] || new Date(record.date) > new Date(map[record.passageId].date)) {
              map[record.passageId] = record;
            }
          }
        });
        setTestHistory(map);
      } catch (e) {
        console.warn("Failed to load test history:", e);
      }
    }
  };

  useEffect(() => {
    loadHistory();
    const savedTheme = localStorage.getItem("ielts_theme");
    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
    }
  }, [isSubmitted]);

  // Load reading content from Supabase (falls back to inline constants on any error)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [{ data: ps }, { data: qs }, { data: vs }] = await Promise.all([
          supabase.from("reading_passages").select("*").order("order_index"),
          supabase.from("reading_questions").select("*").order("order_index"),
          supabase.from("reading_vocab").select("*").order("order_index"),
        ]);
        if (cancelled || !ps || ps.length === 0) return;

        const nextPassages: typeof PASSAGES = {};
        const nextVocab: typeof VOCABULARY_LISTS = {};
        for (const p of ps) {
          const pQs = (qs || []).filter((q: any) => q.passage_id === p.id);
          nextPassages[p.id] = {
            id: p.id,
            title: p.title,
            paragraphs: p.paragraphs,
            matchingQuestions: pQs.filter((q: any) => q.kind === "matching").map((q: any) => ({ id: q.qid, number: q.number, text: q.prompt })),
            tfQuestions: pQs.filter((q: any) => q.kind === "tf").map((q: any) => ({ id: q.qid, number: q.number, text: q.prompt })),
            keys: Object.fromEntries(pQs.map((q: any) => [q.qid, q.answer_key])),
            qQuestions: Object.fromEntries(pQs.map((q: any) => [q.qid, q.short_label || q.prompt])),
          };
          nextVocab[p.id] = (vs || []).filter((v: any) => v.passage_id === p.id).map((v: any) => ({ word: v.word, definition: v.definition, translation: v.translation }));
        }
        setPassages(nextPassages);
        setVocabLists(nextVocab);
      } catch (e) {
        console.warn("Supabase reading content unavailable, using built-in passages.", e);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Reset test state on passage change
  useEffect(() => {
    setAnswers({});
    setIsSubmitted(false);
    setScore(null);
    setHighlightResetKey(prev => prev + 1);
    loadHistory();
  }, [passageId]);

  useEffect(() => {
    if (timeLeft > 0 && !isSubmitted) {
      const timerId = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timerId);
    }
  }, [timeLeft, isSubmitted]);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    localStorage.setItem("ielts_theme", next);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleInputChange = (id: string, value: string) => {
    setAnswers(prev => ({ ...prev, [id]: value }));
  };

  const submitTest = async () => {
    setIsSubmitted(true);
    setScore(null);
    try {
      const response = await fetch('/api/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'reading',
          answers: answers,
          passageId: passageId
        })
      });
      
      if (!response.ok) {
        throw new Error('Baholash jarayonida xatolik yuz berdi');
      }
      
      const result = await response.json();
      setScore(result);

      // Save to localStorage test history
      try {
        const historyItem = {
          id: `reading_${Date.now()}`,
          type: "reading",
          date: new Date().toISOString(),
          band: parseFloat(result.band) || 4.0,
          correct: result.correct || 0,
          total: result.total || 7,
          passageId: passageId
        };
        const historyJson = localStorage.getItem("ielts_test_history");
        const history = historyJson ? JSON.parse(historyJson) : [];
        history.unshift(historyItem);
        localStorage.setItem("ielts_test_history", JSON.stringify(history));
      } catch (e) {
        console.warn("Error saving history to localStorage:", e);
      }
    } catch (error: any) {
      alert("Xatolik: " + error.message);
      setIsSubmitted(false);
    }
  };

  // Highlighting functions
  const highlightSelection = () => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    const range = selection.getRangeAt(0);

    const container = document.getElementById("passage-content");
    if (!container || !container.contains(range.commonAncestorContainer)) {
      alert("Iltimos, faqat matn ichidagi so'zlarni belgilang.");
      return;
    }

    const span = document.createElement("span");
    span.className = "bg-amber-300 dark:bg-amber-800 text-black dark:text-zinc-100 px-0.5 rounded shadow-sm";
    try {
      range.surroundContents(span);
    } catch (e) {
      console.warn("Could not highlight selection across nodes:", e);
      alert("Belgilashda xatolik: Iltimos, faqat bitta paragraf doirasida belgilang.");
    }
    selection.removeAllRanges();
  };

  const clearHighlights = () => {
    setHighlightResetKey(prev => prev + 1);
  };

  const handleCopy = (word: string) => {
    navigator.clipboard.writeText(word);
    alert(`"${word}" nusxalandi!`);
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-500 relative overflow-hidden transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#09090b] text-[#f4f4f5]' : 'bg-[#f8f9fa] text-[#18181b]'
    }`}>
      {/* Background Radial Glow */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[120px] pointer-events-none -z-10"></div>

      <header className={`sticky top-0 z-30 border-b backdrop-blur-md transition-colors duration-300 ${
        theme === 'dark' ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'
      }`}>
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="text-zinc-500 hover:text-[#f4f4f5] transition-colors font-semibold text-sm">
              ← Exit Test
            </Link>
            <div className="h-6 w-px bg-zinc-900"></div>
            
            {/* Passage Selector showing dynamic history completion status */}
            <select 
              value={passageId}
              onChange={(e) => setPassageId(e.target.value)}
              disabled={isSubmitted}
              className={`border text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer ${
                theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-200 text-zinc-900'
              }`}
            >
              <option value="universe">
                Passage 1: Origins of Universe {testHistory["universe"] ? `(Band ${testHistory["universe"].band})` : ""}
              </option>
              <option value="ai">
                Passage 2: Evolution of AI {testHistory["ai"] ? `(Band ${testHistory["ai"].band})` : ""}
              </option>
              <option value="tea">
                Passage 3: History of Tea {testHistory["tea"] ? `(Band ${testHistory["tea"].band})` : ""}
              </option>
            </select>
          </div>

          <div className="flex items-center gap-4">
            <DisplaySettings theme={theme} settings={display} />

            <button
              onClick={toggleTheme}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                theme === 'dark'
                  ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                  : 'bg-zinc-100 border-zinc-200 text-zinc-700 hover:text-black'
              }`}
            >
              {theme === 'dark' ? "☀️ Light" : "🌙 Dark"}
            </button>
            <button 
              onClick={() => setShowVocab(true)}
              className={`text-xs font-semibold px-3 py-2 rounded-xl transition-all border ${
                theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white' : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50'
              }`}
            >
              📖 Lug'atlar (Vocab)
            </button>
            <div className="text-xl font-mono font-bold text-amber-500 tracking-tight">
              {formatTime(timeLeft)}
            </div>
             {/* Zoom Controls */}
             <div className="flex items-center gap-2 ml-4">
               <button
                 onClick={() => display.changeFontScale(-0.1)}
                 disabled={display.fontScale <= MIN_SCALE}
                 className={`px-2 py-1 rounded ${theme === 'dark' ? 'bg-zinc-900 text-zinc-300' : 'bg-zinc-100 text-zinc-700'} disabled:opacity-40`}
               >A−</button>
               <span className="w-12 text-center font-mono text-sm">{Math.round(display.fontScale * 100)}%</span>
               <button
                 onClick={() => display.changeFontScale(0.1)}
                 disabled={display.fontScale >= MAX_SCALE}
                 className={`px-2 py-1 rounded ${theme === 'dark' ? 'bg-zinc-900 text-zinc-300' : 'bg-zinc-100 text-zinc-700'} disabled:opacity-40`}
               >A+</button>
               <button
                 onClick={display.resetFontScale}
                 className={`px-2 py-1 rounded ${theme === 'dark' ? 'bg-zinc-900 text-zinc-300' : 'bg-zinc-100 text-zinc-700'}`}
               >Reset</button>
             </div>
            {!isSubmitted && (
              <button 
                onClick={submitTest}
                className="bg-[#f4f4f5] text-[#09090b] px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider hover:opacity-90 transition-opacity"
              >
                Submit
              </button>
            )}
          </div>
        </div>
      </header>

      <main className={`flex-1 max-w-[1400px] w-full mx-auto grid grid-cols-1 lg:grid-cols-2 gap-0 lg:divide-x transition-colors duration-300 ${
        theme === 'dark' ? 'divide-zinc-900' : 'divide-zinc-200'
      }`}>
        
        {/* Left Column: Passage */}
        <div style={panelStyle} className={`flex flex-col h-[calc(100vh-64px)] overflow-y-auto p-6 md:p-8 transition-colors duration-300 ${
          readerActive ? '' : theme === 'dark' ? 'bg-[#09090b]' : 'bg-white'
        }`}>
          <div className={`flex items-center justify-between border-b pb-4 mb-6 ${
            theme === 'dark' ? 'border-zinc-900' : 'border-zinc-200'
          }`}>
            <h2 className="text-lg font-bold font-sans text-zinc-400">Reading Passage</h2>
            <div className="flex gap-2">
              <button 
                onClick={highlightSelection}
                className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 text-xs font-bold px-3 py-1.5 rounded-lg border border-amber-500/20 transition-colors"
                title="Highlight selected text"
              >
                🎨 Highlight Text
              </button>
              <button 
                onClick={clearHighlights}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg border transition-colors ${
                  theme === 'dark' ? 'bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border-zinc-800' : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-650 border-zinc-250'
                }`}
                title="Clear all highlights"
              >
                🗑️ Clear
              </button>
            </div>
          </div>
          
          <div id="passage-content" key={highlightResetKey} style={contentStyle} className={`prose max-w-none font-serif leading-loose text-lg ${
            readerActive ? '' : theme === 'dark' ? 'prose-invert text-zinc-300' : 'text-zinc-800'
          }`}>
            <h3 className={`text-2xl font-bold mb-6 font-serif ${readerActive ? '' : theme === 'dark' ? 'text-white' : 'text-zinc-900'}`} style={readerActive ? { color: scheme.text } : undefined}>{currentPassage.title}</h3>
            {currentPassage.paragraphs.map((p, i) => (
              <p key={i} className="mb-6">
                <strong>{p.label}.</strong> {p.text}
              </p>
            ))}
          </div>
        </div>

        {/* Right Column: Questions / Scorecard */}
        <div style={panelStyle} className={`flex flex-col h-[calc(100vh-64px)] overflow-y-auto transition-colors duration-300 ${
          readerActive ? '' : theme === 'dark' ? 'bg-zinc-950/20' : 'bg-[#f4f4f5]/40'
        }`}>
          
          {!isSubmitted ? (
            <div style={{ zoom: fontScale }} className="p-6 md:p-8 flex flex-col gap-6 animate-in fade-in duration-300">
              <div style={cardStyle} className={`border p-6 rounded-xl shadow-md ${
                readerActive ? 'border-black/10' : theme === 'dark' ? 'bg-zinc-950 border-zinc-900' : 'bg-white border-zinc-200 text-zinc-900 shadow-sm'
              }`}>
                <h3 className="font-bold text-base mb-2">Questions 1-4</h3>
                <p className="text-xs text-zinc-500 mb-6 italic">
                  Reading Passage has five paragraphs, A-E. Which paragraph contains the following information?<br/>
                  Write the correct letter, A-E, in boxes 1-4.
                </p>
                
                <div className="space-y-4">
                  {currentPassage.matchingQuestions.map((q) => (
                    <div key={q.id} className="flex items-center gap-4">
                      <span className="font-semibold text-sm w-6 text-zinc-500">{q.number}</span>
                      <input 
                        type="text" 
                        maxLength={1} 
                        value={answers[q.id] || ""} 
                        onChange={(e) => handleInputChange(q.id, e.target.value.toUpperCase())} 
                        className={`w-12 h-10 border rounded-lg text-center font-bold uppercase focus:ring-1 focus:ring-amber-500 outline-none ${
                          theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-zinc-50 border-zinc-200 text-zinc-900 font-bold'
                        }`} 
                      />
                      <span style={qTextStyle} className={`text-sm leading-relaxed ${readerActive ? '' : theme === 'dark' ? 'text-zinc-300' : 'text-zinc-700'}`}>{q.text}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div style={cardStyle} className={`border p-6 rounded-xl shadow-md ${
                readerActive ? 'border-black/10' : theme === 'dark' ? 'bg-zinc-950 border-zinc-900' : 'bg-white border-zinc-200 text-zinc-900 shadow-sm'
              }`}>
                <h3 className="font-bold text-base mb-2">Questions 5-7</h3>
                <p className="text-xs text-zinc-500 mb-6 italic">
                  Do the following statements agree with the information given in the Reading Passage?<br/>
                  In boxes 5-7, select TRUE, FALSE, or NOT GIVEN.
                </p>
                
                <div className="space-y-4">
                  {currentPassage.tfQuestions.map((q) => (
                    <div key={q.id} className="flex items-start gap-4">
                      <span className="font-semibold text-sm w-6 mt-2 text-zinc-500">{q.number}</span>
                      <select 
                        value={answers[q.id] || ""} 
                        onChange={(e) => handleInputChange(q.id, e.target.value)} 
                        className={`h-10 border rounded-lg px-2 focus:ring-1 focus:ring-amber-500 outline-none text-sm cursor-pointer ${
                          theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-zinc-50 border-zinc-200 text-zinc-900'
                        }`}
                      >
                        <option value=""></option>
                        <option value="TRUE">TRUE</option>
                        <option value="FALSE">FALSE</option>
                        <option value="NOT GIVEN">NOT GIVEN</option>
                      </select>
                      <span style={qTextStyle} className={`text-sm leading-relaxed mt-2 ${readerActive ? '' : theme === 'dark' ? 'text-zinc-300' : 'text-zinc-700'}`}>{q.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 md:p-8 flex flex-col items-center justify-start h-full">
              {!score ? (
                <div className="flex flex-col items-center text-center animate-pulse mt-20">
                  <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-6"></div>
                  <h3 className="font-bold text-lg mb-2 text-white">Analyzing Answers...</h3>
                  <p className="text-sm text-zinc-500">Checking against answer keys and generating detailed AI explanations in Uzbek.</p>
                </div>
              ) : (
                <div className={`border p-6 md:p-8 rounded-2xl shadow-xl w-full max-w-2xl animate-in slide-in-from-bottom-8 transition-colors duration-300 ${
                  theme === 'dark' ? 'bg-zinc-950 border-zinc-900 text-white' : 'bg-white border-zinc-200 text-zinc-900 shadow-lg'
                }`}>
                  <h3 className="text-center uppercase tracking-widest text-xs font-bold text-zinc-500 mb-6">Official IELTS Scorecard</h3>
                  
                  <div className={`flex justify-between items-center mb-8 pb-8 border-b ${theme === 'dark' ? 'border-zinc-900' : 'border-zinc-200'}`}>
                    <div className="text-center">
                      <div className="text-xs text-zinc-500 font-medium mb-1">To'g'ri javoblar</div>
                      <div className="text-4xl font-bold">{score.correct}<span className="text-xl text-zinc-500">/{score.total}</span></div>
                    </div>
                    <div className="h-12 w-px bg-zinc-900"></div>
                    <div className="text-center">
                      <div className="text-xs text-zinc-500 font-medium mb-1">IELTS Band</div>
                      <div className="text-4.5xl font-bold text-amber-500 font-mono">{score.band}</div>
                    </div>
                  </div>

                  {score.explanations && Object.keys(score.explanations).length > 0 && (
                    <div className="space-y-6 mb-8 text-left">
                      <h4 className="font-bold text-xs uppercase tracking-widest text-zinc-500 mb-4">Barcha savollar tahlili (AI Explanation)</h4>
                      {Object.entries(score.explanations).map(([qId, explanation]: any) => {
                        const userAns = (answers[qId] || '(Javob berilmagan)').trim().toUpperCase();
                        const correctAns = currentPassage.keys[qId];
                        const isCorrect = userAns === correctAns;
                        return (
                          <div key={qId} className={`border p-5 rounded-xl space-y-2 transition-all ${
                            isCorrect ? 'border-emerald-500/20 hover:border-emerald-500/40' : 'border-red-500/20 hover:border-red-500/40'
                          } ${theme === 'dark' ? 'bg-[#09090b]' : 'bg-zinc-50'}`}>
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-xs text-amber-500 uppercase font-mono">Savol {qId.replace('q', '')}</span>
                              <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${
                                isCorrect ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                              }`}>
                                {isCorrect ? 'Correct' : 'Incorrect'}
                              </span>
                            </div>
                            <div className="text-[11px] text-zinc-500 mb-1">{currentPassage.qQuestions[qId]}</div>
                            <div className="grid grid-cols-2 gap-4 text-xs py-2 border-y border-zinc-900/50 font-mono">
                              <div>
                                <span className="text-zinc-500 block">Sizning javobingiz:</span>
                                <span className={`font-bold ${isCorrect ? 'text-emerald-500' : 'text-red-500'}`}>{userAns}</span>
                              </div>
                              <div>
                                <span className="text-zinc-500 block">To'g'ri javob:</span>
                                <span className="font-bold text-emerald-500">{correctAns}</span>
                              </div>
                            </div>
                            <p className="text-sm text-zinc-300 leading-relaxed mt-2">{explanation}</p>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="w-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-white py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-colors"
                  >
                    Restart test / Qayta urinib ko'rish
                  </button>
                </div>
              )}
            </div>
          )}

        </div>
      </main>

      {/* Vocabulary Modal */}
      {showVocab && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-zinc-950 border border-zinc-900 max-w-2xl w-full rounded-2xl p-6 md:p-8 max-h-[85vh] overflow-y-auto shadow-2xl relative">
            <button 
              onClick={() => setShowVocab(false)}
              className="absolute top-6 right-6 text-zinc-500 hover:text-white font-mono text-xs uppercase tracking-widest font-bold"
            >
              [ Close ]
            </button>
            <h3 className="text-xl font-black mb-2 text-zinc-100 flex items-center gap-2">
              <span>📖</span> Vocabulary List / Lug'at boyligi
            </h3>
            <p className="text-xs text-zinc-500 mb-6 font-mono">Passage: "{currentPassage.title}" mavzusiga oid asosiy akademik so'zlar.</p>

            <div className="space-y-4">
              {vocabLists[passageId]?.map((item, i) => (
                <div key={i} className="bg-zinc-900/40 border border-zinc-900 p-4 rounded-xl flex justify-between items-start gap-4">
                  <div className="space-y-1 text-left">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-amber-500">{item.word}</span>
                      <span className="text-xs text-zinc-500 font-medium">({item.translation})</span>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed">{item.definition}</p>
                  </div>
                  <button 
                    onClick={() => handleCopy(item.word)}
                    className="text-[10px] font-bold text-zinc-500 hover:text-white uppercase tracking-wider font-mono bg-zinc-950 px-2 py-1 rounded border border-zinc-900/60"
                  >
                    Copy
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
