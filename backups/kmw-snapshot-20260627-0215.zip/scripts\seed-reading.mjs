// Seeds the 3 reading passages (+ questions + vocab) into Supabase.
// Run: node scripts/seed-reading.mjs   (with SB_URL and SB_SECRET in env)
const URL = process.env.SB_URL;
const KEY = process.env.SB_SECRET;
if (!URL || !KEY) { console.error("Set SB_URL and SB_SECRET env vars"); process.exit(1); }

const H = { apikey: KEY, Authorization: `Bearer ${KEY}`, "Content-Type": "application/json", "User-Agent": "kmw-bb-seed/1.0" };

async function del(table) {
  const r = await fetch(`${URL}/rest/v1/${table}?id=neq.__none__`, { method: "DELETE", headers: { ...H, Prefer: "return=minimal" } });
  if (!r.ok && r.status !== 404) console.warn("delete", table, r.status, await r.text());
}
async function insert(table, rows) {
  if (!rows.length) return;
  const r = await fetch(`${URL}/rest/v1/${table}`, { method: "POST", headers: { ...H, Prefer: "return=minimal" }, body: JSON.stringify(rows) });
  if (!r.ok) { console.error("INSERT FAIL", table, r.status, await r.text()); process.exit(1); }
  console.log(`  ✓ ${table}: ${rows.length}`);
}

const passages = [
  {
    id: "universe", title: "The Origins of the Universe", order_index: 0,
    paragraphs: [
      { label: "A", text: `The question of how the universe began has puzzled philosophers and scientists for millennia. In the early 20th century, the prevailing scientific view was that the universe was static and eternal. However, this view was fundamentally challenged by Edwin Hubble's observation in 1929 that galaxies were moving away from each other, suggesting that the universe was expanding.` },
      { label: "B", text: `This observation led to the formulation of the Big Bang theory. According to this model, the universe began as a hot, dense singularity approximately 13.8 billion years ago. Since then, it has been expanding and cooling, allowing for the formation of subatomic particles, and eventually simple atoms. Giant clouds of these primordial elements later coalesced through gravity to form stars and galaxies.` },
      { label: "C", text: `Not all scientists immediately accepted the Big Bang theory. Fred Hoyle, Thomas Gold, and Hermann Bondi proposed an alternative known as the Steady State theory in 1948. This model suggested that the universe is continually expanding but maintaining a constant average density, with matter being continuously created to form new stars and galaxies at the same rate that old ones become unobservable as a consequence of their increasing distance and velocity of recession.` },
      { label: "D", text: `The debate between these two theories was largely settled by the discovery of the Cosmic Microwave Background (CMB) radiation in 1964 by Arno Penzias and Robert Wilson. The CMB is the residual heat from the Big Bang, spread uniformly across the universe, and its existence provided overwhelming evidence in favor of the Big Bang model, rendering the Steady State theory obsolete.` },
      { label: "E", text: `Today, cosmologists continue to refine our understanding of the universe's origins and its ultimate fate. Concepts such as dark matter and dark energy have been introduced to explain anomalies in the observed rotation of galaxies and the accelerating rate of cosmic expansion. Despite these advancements, the very instant of the Big Bang remains shrouded in mystery, lying beyond the current limits of our physical theories.` },
    ],
    questions: [
      { qid: "q1", kind: "matching", number: "1.", prompt: "The discovery that definitively disproved a competing theory.", short_label: "Definitively disproved a competing theory", answer_key: "D" },
      { qid: "q2", kind: "matching", number: "2.", prompt: "Modern phenomena that scientists are currently trying to understand.", short_label: "Modern phenomena currently trying to understand", answer_key: "E" },
      { qid: "q3", kind: "matching", number: "3.", prompt: "The initial observation that changed the scientific consensus about the universe.", short_label: "Initial observation changing the consensus", answer_key: "A" },
      { qid: "q4", kind: "matching", number: "4.", prompt: "A theory suggesting that the universe has always looked roughly the same.", short_label: "Theory suggesting universe looks the same", answer_key: "C" },
      { qid: "q5", kind: "tf", number: "5.", prompt: "Before 1929, most scientists believed the universe was expanding.", short_label: "Before 1929, most scientists believed universe expanding", answer_key: "FALSE" },
      { qid: "q6", kind: "tf", number: "6.", prompt: "The Steady State theory was proposed by the same scientists who discovered the CMB.", short_label: "Steady State theory proposed by CMB discoverers", answer_key: "FALSE" },
      { qid: "q7", kind: "tf", number: "7.", prompt: "Dark matter makes up the majority of the universe's mass.", short_label: "Dark matter makes up majority of mass", answer_key: "NOT GIVEN" },
    ],
    vocab: [
      { word: "Millennia", definition: "A period of a thousand years.", translation: "Ming yilliklar" },
      { word: "Prevailing", definition: "Existing at a particular time; current.", translation: "Keng tarqalgan/ustun" },
      { word: "Singularity", definition: "A point at which a function takes an infinite value (physics singularity).", translation: "Singulyarlik" },
      { word: "Coalesced", definition: "Combined elements in a mass or whole.", translation: "Birlashgan/qo'shilgan" },
      { word: "Obsolete", definition: "No longer produced or used; out of date.", translation: "Eskirgan/iste'moldan chiqqan" },
    ],
  },
  {
    id: "ai", title: "The Evolution of Artificial Intelligence", order_index: 1,
    paragraphs: [
      { label: "A", text: `The quest to build machines capable of human-like intelligence has its roots in early computing history. In 1950, Alan Turing famously proposed the Turing Test as a benchmark for artificial intelligence. During this early era, optimism was high, and scientists believed that creating an intelligent machine was only a few decades away.` },
      { label: "B", text: `By the 1970s and 1980s, the field entered the first "AI winter" as early rule-based systems failed to scale to complex real-world problems. These expert systems, which relied on hardcoded "if-then" rules created by human experts, were brittle and could not handle uncertainty or learn from new data, leading to a loss of funding.` },
      { label: "C", text: `A major paradigm shift occurred in the late 1990s and 2000s with the rise of machine learning. Instead of programming explicit rules, researchers began developing algorithms that allowed computers to learn patterns directly from massive datasets. The availability of high-performance GPUs and big data accelerated this transition.` },
      { label: "D", text: `In the 2010s, deep learning—a subset of machine learning based on artificial neural networks with multiple layers—revolutionized fields like image recognition and natural language processing. Systems like AlphaGo demonstrated superhuman performance in complex tasks, capturing global attention and reviving massive commercial interest.` },
      { label: "E", text: `Today, generative AI models and Large Language Models (LLMs) have achieved remarkable fluency and capability. However, critical challenges remain, including machine alignment, ethical concerns regarding bias, and the theoretical risk of artificial general intelligence (AGI) escaping human control, which keeps researchers divided.` },
    ],
    questions: [
      { qid: "q1", kind: "matching", number: "1.", prompt: "The shift from rule-based programming to data-driven learning.", short_label: "The shift from rule-based programming to data-driven learning", answer_key: "C" },
      { qid: "q2", kind: "matching", number: "2.", prompt: "Future risks associated with superintelligent systems.", short_label: "Future risks associated with superintelligent systems", answer_key: "E" },
      { qid: "q3", kind: "matching", number: "3.", prompt: "The initial standard proposed to define machine intelligence.", short_label: "The initial standard proposed to define machine intelligence", answer_key: "A" },
      { qid: "q4", kind: "matching", number: "4.", prompt: "A period characterized by a decline in interest and investment.", short_label: "A period characterized by a decline in interest and investment", answer_key: "B" },
      { qid: "q5", kind: "tf", number: "5.", prompt: "Before 1950, most scientists believed expert systems were successful.", short_label: "Before 1950, most scientists believed expert systems were successful", answer_key: "FALSE" },
      { qid: "q6", kind: "tf", number: "6.", prompt: "Turing believed machine intelligence could be achieved in the 20th century.", short_label: "Turing believed machine intelligence could be achieved in the 20th century", answer_key: "TRUE" },
      { qid: "q7", kind: "tf", number: "7.", prompt: "AlphaGo was developed using a hybrid of expert systems and deep learning.", short_label: "AlphaGo was developed using a hybrid of expert systems and deep learning", answer_key: "NOT GIVEN" },
    ],
    vocab: [
      { word: "Benchmark", definition: "A standard or point of reference against which things may be compared.", translation: "Mezon/o'lchov" },
      { word: "Expert systems", definition: "Software designed to solve complex problems in a specific domain.", translation: "Ekspert tizimlari" },
      { word: "Paradigm shift", definition: "A fundamental change in approach or underlying assumptions.", translation: "Fikrlash o'zgarishi/burilish" },
      { word: "Neural networks", definition: "Computer systems modeled on the human brain's structure.", translation: "Neyron tarmoqlari" },
      { word: "Machine alignment", definition: "Ensuring that artificial intelligence systems align with human goals.", translation: "Mashina muvofiqligi/moslashuvi" },
    ],
  },
  {
    id: "tea", title: "The History and Impact of Tea", order_index: 2,
    paragraphs: [
      { label: "A", text: `The discovery of tea is steeped in Chinese mythology, dating back to 2737 BC when Emperor Shen Nong allegedly tasted water into which tea leaves had accidentally drifted. For centuries, tea was consumed primarily for its medicinal properties and as a tonic to promote mental alertness among Buddhist monks.` },
      { label: "B", text: `It was not until the 17th century that tea made its way to Europe via Dutch and Portuguese merchants. In England, the marriage of King Charles II to Catherine of Braganza, a Portuguese princess who loved tea, established it as a fashionable beverage among the British nobility and aristocracy.` },
      { label: "C", text: `By the 18th and 19th centuries, the demand for tea in Britain had exploded, creating a massive trade imbalance with China. Because China only accepted silver in exchange for tea, the British began illicitly exporting opium to China to balance the trade, culminating in the Opium Wars.` },
      { label: "D", text: `In the modern era, tea has become the second most consumed beverage in the world, surpassed only by water. Scientific research continues to highlight its numerous health benefits, including high concentrations of antioxidants, cardiovascular support, and its role in boosting cognitive function.` },
      { label: "E", text: `Tea culture manifests uniquely across the globe. From the highly ritualized Japanese tea ceremony (Chado) to the social, casual nature of British afternoon tea, the beverage serves as a cornerstone of social interaction and cultural expression in diverse societies.` },
    ],
    questions: [
      { qid: "q1", kind: "matching", number: "1.", prompt: "The introduction of tea to British high society.", short_label: "The introduction of tea to British high society", answer_key: "B" },
      { qid: "q2", kind: "matching", number: "2.", prompt: "Traditional tea rituals in different world regions.", short_label: "Traditional tea rituals in different world regions", answer_key: "E" },
      { qid: "q3", kind: "matching", number: "3.", prompt: "The mythical origins of tea consumption.", short_label: "The mythical origins of tea consumption", answer_key: "A" },
      { qid: "q4", kind: "matching", number: "4.", prompt: "A geopolitical conflict driven by the tea trade.", short_label: "A geopolitical conflict driven by the tea trade", answer_key: "C" },
      { qid: "q5", kind: "tf", number: "5.", prompt: "King Charles II married a princess who popularized tea in England.", short_label: "King Charles II married a princess who popularized tea in England", answer_key: "TRUE" },
      { qid: "q6", kind: "tf", number: "6.", prompt: "Tea was originally developed as a recreational beverage in Europe.", short_label: "Tea was originally developed as a recreational beverage in Europe", answer_key: "FALSE" },
      { qid: "q7", kind: "tf", number: "7.", prompt: "Opium wars led to the establishment of tea plantations in India.", short_label: "Opium wars led to the establishment of tea plantations in India", answer_key: "NOT GIVEN" },
    ],
    vocab: [
      { word: "Steeped in", definition: "Surrounded or filled with a quality or influence.", translation: "Shimib olingan/boy" },
      { word: "Medicinal properties", definition: "Properties used to cure or prevent diseases.", translation: "Shifobaxsh xususiyatlar" },
      { word: "Trade imbalance", definition: "A situation in which a country's imports exceed its exports.", translation: "Savdo nomutanosibligi" },
      { word: "Cardiovascular", definition: "Relating to the heart and blood vessels.", translation: "Yurak-qon tomir" },
      { word: "Cornerstone", definition: "An important quality or feature on which a thing is based.", translation: "Poydevor/asosiy tosh" },
    ],
  },
];

async function main() {
  console.log("Seeding reading content → Supabase");
  await del("reading_passages"); // cascades to questions + vocab
  await insert("reading_passages", passages.map(p => ({ id: p.id, title: p.title, paragraphs: p.paragraphs, order_index: p.order_index })));
  await insert("reading_questions", passages.flatMap(p => p.questions.map((q, i) => ({ passage_id: p.id, qid: q.qid, kind: q.kind, number: q.number, prompt: q.prompt, short_label: q.short_label, answer_key: q.answer_key, order_index: i }))));
  await insert("reading_vocab", passages.flatMap(p => p.vocab.map((v, i) => ({ passage_id: p.id, word: v.word, definition: v.definition, translation: v.translation, order_index: i }))));
  console.log("Done.");
}
main().catch(e => { console.error(e); process.exit(1); });
