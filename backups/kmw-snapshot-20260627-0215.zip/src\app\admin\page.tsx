"use client";

import { useState } from "react";
import Link from "next/link";

type Para = { label: string; text: string };
type Q = { qid: string; kind: string; number: string; prompt: string; short_label: string; answer_key: string };
type V = { word: string; definition: string; translation: string };
type PassageForm = { id: string; title: string; order_index: number; paragraphs: Para[]; questions: Q[]; vocab: V[] };

type LQ = { qid: string; kind: string; prompt: string; answer_key: string; prefix: string; suffix: string; optionsText: string };
type ListeningForm = { id: string; title: string; order_index: number; sentencesText: string; transcript_html: string; vocab: V[]; questions: LQ[] };

const EMPTY_R: PassageForm = {
  id: "", title: "", order_index: 0,
  paragraphs: [{ label: "A", text: "" }],
  questions: [{ qid: "q1", kind: "matching", number: "1.", prompt: "", short_label: "", answer_key: "" }],
  vocab: [{ word: "", definition: "", translation: "" }],
};
const EMPTY_L: ListeningForm = {
  id: "", title: "", order_index: 0, sentencesText: "", transcript_html: "",
  vocab: [{ word: "", definition: "", translation: "" }],
  questions: [{ qid: "q1", kind: "fill", prompt: "", answer_key: "", prefix: "", suffix: "", optionsText: "" }],
};

const parseOpts = (text: string) =>
  text.split("|").map((s) => s.trim()).filter(Boolean).map((pair) => {
    const idx = pair.indexOf("=");
    return idx === -1 ? { value: pair, label: pair } : { value: pair.slice(0, idx).trim(), label: pair.slice(idx + 1).trim() };
  });

export default function AdminPage() {
  const [adminEmail, setAdminEmail] = useState("");
  const [adminKey, setAdminKey] = useState("");
  const [authed, setAuthed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [tab, setTab] = useState<"reading" | "listening">("reading");

  // Reading
  const [passages, setPassages] = useState<any[]>([]);
  const [questions, setQuestions] = useState<any[]>([]);
  const [vocab, setVocab] = useState<any[]>([]);
  const [form, setForm] = useState<PassageForm | null>(null);

  // Listening
  const [ltests, setLtests] = useState<any[]>([]);
  const [lquestions, setLquestions] = useState<any[]>([]);
  const [lvocab, setLvocab] = useState<any[]>([]);
  const [lform, setLform] = useState<ListeningForm | null>(null);

  const headers = () => ({ "Content-Type": "application/json", "x-admin-email": adminEmail, "x-admin-key": adminKey });
  const authHeaders = (email = adminEmail, key = adminKey) => ({ "x-admin-email": email, "x-admin-key": key });

  const load = async (email = adminEmail, key = adminKey) => {
    setLoading(true); setError(null);
    try {
      const [r, l] = await Promise.all([
        fetch("/api/admin/reading", { headers: authHeaders(email, key) }),
        fetch("/api/admin/listening", { headers: authHeaders(email, key) }),
      ]);
      if (r.status === 401) { setError("Email yoki parol noto'g'ri"); setAuthed(false); return; }
      if (!r.ok || !l.ok) throw new Error("Yuklashda xatolik");
      const rd = await r.json(); const ld = await l.json();
      setPassages(rd.passages); setQuestions(rd.questions); setVocab(rd.vocab);
      setLtests(ld.tests); setLquestions(ld.questions); setLvocab(ld.vocab);
      setAuthed(true);
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  };

  const flash = (msg: string) => { setNotice(msg); setTimeout(() => setNotice(null), 2500); };

  // ── Reading actions ──
  const startNewR = () => setForm(structuredClone(EMPTY_R));
  const startEditR = (pid: string) => {
    const p = passages.find((x) => x.id === pid); if (!p) return;
    const qs = questions.filter((q) => q.passage_id === pid).map((q) => ({ qid: q.qid, kind: q.kind, number: q.number, prompt: q.prompt, short_label: q.short_label || "", answer_key: q.answer_key }));
    const vs = vocab.filter((v) => v.passage_id === pid).map((v) => ({ word: v.word, definition: v.definition, translation: v.translation }));
    setForm({ id: p.id, title: p.title, order_index: p.order_index ?? 0, paragraphs: p.paragraphs || [], questions: qs, vocab: vs });
  };
  const saveR = async () => {
    if (!form) return;
    if (!form.id || !form.title) { flash("ID va Title majburiy"); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/admin/reading", { method: "POST", headers: headers(), body: JSON.stringify(form) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Saqlashda xatolik");
      flash("Saqlandi ✓"); setForm(null); await load();
    } catch (e: any) { flash("Xatolik: " + e.message); } finally { setLoading(false); }
  };
  const removeR = async (id: string) => {
    if (!confirm(`"${id}" passage'ni o'chirasizmi?`)) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/reading?id=${encodeURIComponent(id)}`, { method: "DELETE", headers: headers() });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || "O'chirishda xatolik"); }
      flash("O'chirildi"); await load();
    } catch (e: any) { flash("Xatolik: " + e.message); } finally { setLoading(false); }
  };

  // ── Listening actions ──
  const startNewL = () => setLform(structuredClone(EMPTY_L));
  const startEditL = (tid: string) => {
    const t = ltests.find((x) => x.id === tid); if (!t) return;
    const qs: LQ[] = lquestions.filter((q) => q.test_id === tid).map((q) => {
      const opt = q.options || {};
      return {
        qid: q.qid, kind: opt.kind === "mcq" ? "mcq" : "fill", prompt: q.prompt, answer_key: q.answer_key,
        prefix: opt.prefix || "", suffix: opt.suffix || "",
        optionsText: Array.isArray(opt.choices) ? opt.choices.map((c: any) => `${c.value}=${c.label}`).join(" | ") : "",
      };
    });
    const vs = lvocab.filter((v) => v.test_id === tid).map((v) => ({ word: v.word, definition: v.definition, translation: v.translation }));
    setLform({ id: t.id, title: t.title, order_index: t.order_index ?? 0, sentencesText: (t.sentences || []).join("\n"), transcript_html: t.transcript_html || "", vocab: vs, questions: qs });
  };
  const saveL = async () => {
    if (!lform) return;
    if (!lform.id || !lform.title) { flash("ID va Title majburiy"); return; }
    setLoading(true);
    try {
      const payload = {
        id: lform.id, title: lform.title, order_index: lform.order_index,
        sentences: lform.sentencesText.split("\n").map((s) => s.trim()).filter(Boolean),
        transcript_html: lform.transcript_html, vocab: lform.vocab,
        questions: lform.questions.map((q) => q.kind === "mcq"
          ? { qid: q.qid, kind: "mcq", prompt: q.prompt, answer_key: q.answer_key, options: parseOpts(q.optionsText) }
          : { qid: q.qid, kind: "fill", prompt: q.prompt, answer_key: q.answer_key, prefix: q.prefix, suffix: q.suffix }),
      };
      const res = await fetch("/api/admin/listening", { method: "POST", headers: headers(), body: JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Saqlashda xatolik");
      flash("Saqlandi ✓"); setLform(null); await load();
    } catch (e: any) { flash("Xatolik: " + e.message); } finally { setLoading(false); }
  };
  const removeL = async (id: string) => {
    if (!confirm(`"${id}" testni o'chirasizmi?`)) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/listening?id=${encodeURIComponent(id)}`, { method: "DELETE", headers: headers() });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || "O'chirishda xatolik"); }
      flash("O'chirildi"); await load();
    } catch (e: any) { flash("Xatolik: " + e.message); } finally { setLoading(false); }
  };

  const inputCls = "w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-amber-500";

  // ── Login ──
  if (!authed) {
    return (
      <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex items-center justify-center p-6">
        <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-2xl p-8 shadow-2xl">
          <h1 className="text-xl font-extrabold mb-2">kmw.bb — Admin</h1>
          <p className="text-sm text-zinc-500 mb-6">Kontentni boshqarish uchun email va parolni kiriting.</p>
          <input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} placeholder="Email" className="w-full h-11 bg-zinc-900 border border-zinc-800 rounded-xl px-4 outline-none focus:ring-1 focus:ring-amber-500 mb-3" />
          <input type="password" value={adminKey} onChange={(e) => setAdminKey(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} placeholder="Admin parol" className="w-full h-11 bg-zinc-900 border border-zinc-800 rounded-xl px-4 outline-none focus:ring-1 focus:ring-amber-500 mb-3" />
          {error && <p className="text-red-400 text-xs mb-3">{error}</p>}
          <button onClick={() => load()} disabled={loading || !adminKey || !adminEmail} className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl transition-colors disabled:opacity-40">
            {loading ? "Tekshirilmoqda…" : "Kirish"}
          </button>
          <Link href="/dashboard" className="block text-center text-xs text-zinc-500 hover:text-zinc-300 mt-4">← Dashboard</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5]">
      <header className="sticky top-0 z-30 bg-zinc-950/80 backdrop-blur border-b border-zinc-900">
        <div className="mx-auto max-w-5xl flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <span className="bg-amber-500 text-black w-8 h-8 flex items-center justify-center rounded-lg font-black text-xs">9.0</span>
            <span className="font-bold">Admin</span>
            <div className="flex gap-1 ml-3">
              {(["reading", "listening"] as const).map((t) => (
                <button key={t} onClick={() => setTab(t)} className={`text-xs font-bold px-3 py-1.5 rounded-lg capitalize ${tab === t ? "bg-amber-500 text-black" : "bg-zinc-900 border border-zinc-800 text-zinc-300"}`}>{t}</button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => load()} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:text-white">↻ Yangilash</button>
            <button onClick={() => (tab === "reading" ? startNewR() : startNewL())} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-amber-500 text-black hover:bg-amber-400">+ Yangi {tab === "reading" ? "passage" : "test"}</button>
            <Link href="/dashboard" className="text-xs text-zinc-500 hover:text-zinc-300">← Dashboard</Link>
          </div>
        </div>
      </header>

      {notice && <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-zinc-950 border border-amber-500/30 text-amber-400 px-4 py-2 rounded-xl text-sm font-semibold shadow-2xl">{notice}</div>}

      <main className="mx-auto max-w-5xl px-6 py-8">
        {tab === "reading" ? (
          <>
            <div className="space-y-3 mb-10">
              <h2 className="text-sm font-bold uppercase tracking-widest text-zinc-500">Reading passage'lar ({passages.length})</h2>
              {passages.map((p) => {
                const qc = questions.filter((q) => q.passage_id === p.id).length;
                const vc = vocab.filter((v) => v.passage_id === p.id).length;
                return (
                  <div key={p.id} className="flex items-center justify-between bg-zinc-950 border border-zinc-900 rounded-xl px-5 py-4">
                    <div><div className="font-bold">{p.title}</div><div className="text-xs text-zinc-500 font-mono">{p.id} · {qc} savol · {vc} vocab</div></div>
                    <div className="flex gap-2">
                      <button onClick={() => startEditR(p.id)} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:text-white">Tahrir</button>
                      <button onClick={() => removeR(p.id)} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20">O'chirish</button>
                    </div>
                  </div>
                );
              })}
              {passages.length === 0 && <p className="text-zinc-600 text-sm">Hali passage yo'q.</p>}
            </div>

            {form && (
              <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold">{passages.some((p) => p.id === form.id) ? "Passage tahriri" : "Yangi passage"}</h2>
                  <button onClick={() => setForm(null)} className="text-xs text-zinc-500 hover:text-white">✕ Yopish</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div><label className="text-[10px] uppercase tracking-wider text-zinc-500">ID</label><input className={inputCls} value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value.toLowerCase().replace(/\s+/g, "_") })} /></div>
                  <div className="sm:col-span-2"><label className="text-[10px] uppercase tracking-wider text-zinc-500">Title</label><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                </div>
                <ArraySection title="Paragraflar" items={form.paragraphs}
                  onAdd={() => setForm({ ...form, paragraphs: [...form.paragraphs, { label: String.fromCharCode(65 + form.paragraphs.length), text: "" }] })}
                  onRemove={(i) => setForm({ ...form, paragraphs: form.paragraphs.filter((_, x) => x !== i) })}
                  render={(p, i) => (
                    <div className="flex gap-2">
                      <input className={`${inputCls} w-14`} value={p.label} onChange={(e) => { const a = [...form.paragraphs]; a[i] = { ...a[i], label: e.target.value }; setForm({ ...form, paragraphs: a }); }} />
                      <textarea className={`${inputCls} flex-1 min-h-[70px]`} value={p.text} onChange={(e) => { const a = [...form.paragraphs]; a[i] = { ...a[i], text: e.target.value }; setForm({ ...form, paragraphs: a }); }} />
                    </div>
                  )} />
                <ArraySection title="Savollar (kind: matching/tf · javob: A-E yoki TRUE/FALSE/NOT GIVEN)" items={form.questions}
                  onAdd={() => setForm({ ...form, questions: [...form.questions, { qid: `q${form.questions.length + 1}`, kind: "matching", number: `${form.questions.length + 1}.`, prompt: "", short_label: "", answer_key: "" }] })}
                  onRemove={(i) => setForm({ ...form, questions: form.questions.filter((_, x) => x !== i) })}
                  render={(q, i) => (
                    <div className="grid grid-cols-2 sm:grid-cols-12 gap-2">
                      <input className={`${inputCls} sm:col-span-1`} placeholder="qid" value={q.qid} onChange={(e) => upd(form, setForm, "questions", i, "qid", e.target.value)} />
                      <select className={`${inputCls} sm:col-span-2`} value={q.kind} onChange={(e) => upd(form, setForm, "questions", i, "kind", e.target.value)}><option value="matching">matching</option><option value="tf">tf</option></select>
                      <input className={`${inputCls} sm:col-span-1`} placeholder="№" value={q.number} onChange={(e) => upd(form, setForm, "questions", i, "number", e.target.value)} />
                      <input className={`${inputCls} sm:col-span-6`} placeholder="Savol matni" value={q.prompt} onChange={(e) => upd(form, setForm, "questions", i, "prompt", e.target.value)} />
                      <input className={`${inputCls} sm:col-span-2`} placeholder="javob" value={q.answer_key} onChange={(e) => upd(form, setForm, "questions", i, "answer_key", e.target.value.toUpperCase())} />
                    </div>
                  )} />
                <ArraySection title="Lug'at (Vocab)" items={form.vocab}
                  onAdd={() => setForm({ ...form, vocab: [...form.vocab, { word: "", definition: "", translation: "" }] })}
                  onRemove={(i) => setForm({ ...form, vocab: form.vocab.filter((_, x) => x !== i) })}
                  render={(v, i) => (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input className={inputCls} placeholder="word" value={v.word} onChange={(e) => upd(form, setForm, "vocab", i, "word", e.target.value)} />
                      <input className={inputCls} placeholder="definition" value={v.definition} onChange={(e) => upd(form, setForm, "vocab", i, "definition", e.target.value)} />
                      <input className={inputCls} placeholder="tarjima" value={v.translation} onChange={(e) => upd(form, setForm, "vocab", i, "translation", e.target.value)} />
                    </div>
                  )} />
                <div className="flex gap-3 pt-2">
                  <button onClick={saveR} disabled={loading} className="bg-amber-500 hover:bg-amber-400 text-black font-bold px-6 py-2.5 rounded-xl disabled:opacity-40">{loading ? "Saqlanmoqda…" : "Saqlash"}</button>
                  <button onClick={() => setForm(null)} className="bg-zinc-900 border border-zinc-800 px-6 py-2.5 rounded-xl font-bold">Bekor</button>
                </div>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="space-y-3 mb-10">
              <h2 className="text-sm font-bold uppercase tracking-widest text-zinc-500">Listening testlar ({ltests.length})</h2>
              {ltests.map((t) => {
                const qc = lquestions.filter((q) => q.test_id === t.id).length;
                const vc = lvocab.filter((v) => v.test_id === t.id).length;
                return (
                  <div key={t.id} className="flex items-center justify-between bg-zinc-950 border border-zinc-900 rounded-xl px-5 py-4">
                    <div><div className="font-bold">{t.title}</div><div className="text-xs text-zinc-500 font-mono">{t.id} · {qc} savol · {vc} vocab</div></div>
                    <div className="flex gap-2">
                      <button onClick={() => startEditL(t.id)} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:text-white">Tahrir</button>
                      <button onClick={() => removeL(t.id)} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20">O'chirish</button>
                    </div>
                  </div>
                );
              })}
              {ltests.length === 0 && <p className="text-zinc-600 text-sm">Hali test yo'q.</p>}
            </div>

            {lform && (
              <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold">{ltests.some((t) => t.id === lform.id) ? "Test tahriri" : "Yangi test"}</h2>
                  <button onClick={() => setLform(null)} className="text-xs text-zinc-500 hover:text-white">✕ Yopish</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div><label className="text-[10px] uppercase tracking-wider text-zinc-500">ID</label><input className={inputCls} value={lform.id} onChange={(e) => setLform({ ...lform, id: e.target.value.toLowerCase().replace(/\s+/g, "_") })} /></div>
                  <div className="sm:col-span-2"><label className="text-[10px] uppercase tracking-wider text-zinc-500">Title</label><input className={inputCls} value={lform.title} onChange={(e) => setLform({ ...lform, title: e.target.value })} /></div>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold">Audio jumlalar (har qatorga bitta gap)</label>
                  <textarea className={`${inputCls} min-h-[120px] font-mono text-xs`} value={lform.sentencesText} onChange={(e) => setLform({ ...lform, sentencesText: e.target.value })} />
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold">Transcript HTML (natija sahifasida ko'rinadi)</label>
                  <textarea className={`${inputCls} min-h-[100px] font-mono text-xs`} value={lform.transcript_html} onChange={(e) => setLform({ ...lform, transcript_html: e.target.value })} />
                </div>
                <ArraySection title="Savollar (kind: fill — prefix/suffix · mcq — variantlar: A=Matn | B=Matn | C=Matn)" items={lform.questions}
                  onAdd={() => setLform({ ...lform, questions: [...lform.questions, { qid: `q${lform.questions.length + 1}`, kind: "fill", prompt: "", answer_key: "", prefix: "", suffix: "", optionsText: "" }] })}
                  onRemove={(i) => setLform({ ...lform, questions: lform.questions.filter((_, x) => x !== i) })}
                  render={(q, i) => (
                    <div className="space-y-1.5">
                      <div className="grid grid-cols-2 sm:grid-cols-12 gap-2">
                        <input className={`${inputCls} sm:col-span-1`} placeholder="qid" value={q.qid} onChange={(e) => upd(lform, setLform, "questions", i, "qid", e.target.value)} />
                        <select className={`${inputCls} sm:col-span-2`} value={q.kind} onChange={(e) => upd(lform, setLform, "questions", i, "kind", e.target.value)}><option value="fill">fill</option><option value="mcq">mcq</option></select>
                        <input className={`${inputCls} sm:col-span-7`} placeholder="Savol/label matni" value={q.prompt} onChange={(e) => upd(lform, setLform, "questions", i, "prompt", e.target.value)} />
                        <input className={`${inputCls} sm:col-span-2`} placeholder="javob" value={q.answer_key} onChange={(e) => upd(lform, setLform, "questions", i, "answer_key", e.target.value.toUpperCase())} />
                      </div>
                      {q.kind === "mcq" ? (
                        <input className={inputCls} placeholder="Variantlar: A=North building | B=South building | C=Central block" value={q.optionsText} onChange={(e) => upd(lform, setLform, "questions", i, "optionsText", e.target.value)} />
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          <input className={inputCls} placeholder="prefix (oldidagi so'z, masalan John)" value={q.prefix} onChange={(e) => upd(lform, setLform, "questions", i, "prefix", e.target.value)} />
                          <input className={inputCls} placeholder="suffix (keyingi so'z, masalan bedroom)" value={q.suffix} onChange={(e) => upd(lform, setLform, "questions", i, "suffix", e.target.value)} />
                        </div>
                      )}
                    </div>
                  )} />
                <ArraySection title="Lug'at (Vocab)" items={lform.vocab}
                  onAdd={() => setLform({ ...lform, vocab: [...lform.vocab, { word: "", definition: "", translation: "" }] })}
                  onRemove={(i) => setLform({ ...lform, vocab: lform.vocab.filter((_, x) => x !== i) })}
                  render={(v, i) => (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input className={inputCls} placeholder="word" value={v.word} onChange={(e) => upd(lform, setLform, "vocab", i, "word", e.target.value)} />
                      <input className={inputCls} placeholder="definition" value={v.definition} onChange={(e) => upd(lform, setLform, "vocab", i, "definition", e.target.value)} />
                      <input className={inputCls} placeholder="tarjima" value={v.translation} onChange={(e) => upd(lform, setLform, "vocab", i, "translation", e.target.value)} />
                    </div>
                  )} />
                <div className="flex gap-3 pt-2">
                  <button onClick={saveL} disabled={loading} className="bg-amber-500 hover:bg-amber-400 text-black font-bold px-6 py-2.5 rounded-xl disabled:opacity-40">{loading ? "Saqlanmoqda…" : "Saqlash"}</button>
                  <button onClick={() => setLform(null)} className="bg-zinc-900 border border-zinc-800 px-6 py-2.5 rounded-xl font-bold">Bekor</button>
                </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

function upd(form: any, setForm: any, field: string, i: number, key: string, value: string) {
  const arr = [...form[field]];
  arr[i] = { ...arr[i], [key]: value };
  setForm({ ...form, [field]: arr });
}

function ArraySection<T>({ title, items, onAdd, onRemove, render }: {
  title: string; items: T[]; onAdd: () => void; onRemove: (i: number) => void; render: (item: T, i: number) => React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold">{title}</label>
        <button onClick={onAdd} className="text-[11px] font-bold text-amber-500 hover:text-amber-400">+ qo'shish</button>
      </div>
      {items.map((item, i) => (
        <div key={i} className="flex items-start gap-2">
          <div className="flex-1">{render(item, i)}</div>
          <button onClick={() => onRemove(i)} className="text-zinc-600 hover:text-red-400 text-sm mt-2 px-1">✕</button>
        </div>
      ))}
    </div>
  );
}
