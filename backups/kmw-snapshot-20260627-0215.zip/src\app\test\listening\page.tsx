"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { useDisplaySettings, DisplaySettings } from "@/components/DisplaySettings";
import { supabase } from "@/lib/supabase";
import { LISTENING_TESTS, type ListeningTest, type ListeningQuestion } from "@/lib/listeningData";

interface TestRecord {
  id: string;
  type: string;
  date: string;
  band: number;
  correct: number;
  total: number;
  passageId: string;
}

const qNum = (qid: string) => qid.replace(/[^0-9]/g, "");

export default function ListeningTest() {
  const [tests, setTests] = useState<Record<string, ListeningTest>>(LISTENING_TESTS);
  const [testId, setTestId] = useState<string>("campus");
  const [timeLeft, setTimeLeft] = useState(40 * 60); // 40 minutes
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState<any>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [currentSentenceIndex, setCurrentSentenceIndex] = useState(0);
  const [showVocab, setShowVocab] = useState(false);
  const [testHistory, setTestHistory] = useState<Record<string, TestRecord>>({});
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const display = useDisplaySettings();

  const activeUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const currentTest = tests[testId] || tests.campus;
  const fillQs = currentTest.questions.filter((q): q is Extract<ListeningQuestion, { kind: "fill" }> => q.kind === "fill");
  const mcqQs = currentTest.questions.filter((q): q is Extract<ListeningQuestion, { kind: "mcq" }> => q.kind === "mcq");
  const keysMap: Record<string, string> = Object.fromEntries(currentTest.questions.map((q) => [q.qid, q.answer_key]));
  const promptMap: Record<string, string> = Object.fromEntries(currentTest.questions.map((q) => [q.qid, q.prompt]));

  // Load history from localStorage
  const loadHistory = () => {
    const historyJson = localStorage.getItem("ielts_test_history");
    if (historyJson) {
      try {
        const history: TestRecord[] = JSON.parse(historyJson);
        const map: Record<string, TestRecord> = {};
        history.forEach((record) => {
          if (record.type === "listening" && record.passageId) {
            if (!map[record.passageId] || new Date(record.date) > new Date(map[record.passageId].date)) {
              map[record.passageId] = record;
            }
          }
        });
        setTestHistory(map);
      } catch (e) {
        console.warn("Failed to load test history:", e);
      }
    }
  };

  useEffect(() => {
    loadHistory();
    const savedTheme = localStorage.getItem("ielts_theme");
    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
    }
  }, [isSubmitted]);

  // Load listening content from Supabase (falls back to inline constants on any error)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [{ data: ts }, { data: qs }, { data: vs }] = await Promise.all([
          supabase.from("listening_tests").select("*").order("order_index"),
          supabase.from("listening_questions").select("*").order("order_index"),
          supabase.from("listening_vocab").select("*").order("order_index"),
        ]);
        if (cancelled || !ts || ts.length === 0) return;

        const next: Record<string, ListeningTest> = {};
        for (const t of ts) {
          const tQs: ListeningQuestion[] = (qs || []).filter((q: any) => q.test_id === t.id).map((q: any) => {
            const opt = q.options || {};
            if (opt.kind === "mcq") return { qid: q.qid, kind: "mcq", prompt: q.prompt, options: opt.choices || [], answer_key: q.answer_key };
            return { qid: q.qid, kind: "fill", prompt: q.prompt, prefix: opt.prefix || "", suffix: opt.suffix || "", answer_key: q.answer_key };
          });
          next[t.id] = {
            id: t.id, title: t.title, sentences: t.sentences || [], transcriptHtml: t.transcript_html || "",
            vocab: (vs || []).filter((v: any) => v.test_id === t.id).map((v: any) => ({ word: v.word, definition: v.definition, translation: v.translation })),
            questions: tQs,
          };
        }
        setTests(next);
      } catch (e) {
        console.warn("Supabase listening content unavailable, using built-in tests.", e);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Reset state on test change
  useEffect(() => {
    stopAudio();
    setAnswers({});
    setIsSubmitted(false);
    setScore(null);
    setProgress(0);
    setCurrentSentenceIndex(0);
    loadHistory();
  }, [testId]);

  // Timer logic
  useEffect(() => {
    if (timeLeft > 0 && !isSubmitted) {
      const timerId = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timerId);
    }
  }, [timeLeft, isSubmitted]);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    localStorage.setItem("ielts_theme", next);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleInputChange = (id: string, value: string) => {
    setAnswers(prev => ({ ...prev, [id]: value }));
  };

  // Sentences Audio Player Engine
  const playSentences = (sentences: string[], startIndex: number) => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();

    if (startIndex >= sentences.length) {
      setIsPlaying(false);
      setProgress(100);
      setCurrentSentenceIndex(0);
      return;
    }

    setIsPlaying(true);
    setCurrentSentenceIndex(startIndex);
    setProgress((startIndex / sentences.length) * 100);

    const utterance = new SpeechSynthesisUtterance(sentences[startIndex]);
    activeUtteranceRef.current = utterance;
    utterance.rate = playbackSpeed;
    utterance.lang = "en-US";

    utterance.onend = () => {
      setTimeout(() => {
        if (isPlaying) {
          playSentences(sentences, startIndex + 1);
        }
      }, 800);
    };

    utterance.onerror = (e) => {
      console.warn("Speech Synthesis error:", e);
      setIsPlaying(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  const stopAudio = () => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
  };

  const toggleAudio = () => {
    if (isPlaying) {
      stopAudio();
    } else {
      playSentences(currentTest.sentences, currentSentenceIndex);
    }
  };

  // Adjust rate on live change
  useEffect(() => {
    if (isPlaying) {
      playSentences(currentTest.sentences, currentSentenceIndex);
    }
  }, [playbackSpeed]);

  const submitTest = async () => {
    stopAudio();
    setIsSubmitted(true);
    setScore(null);
    try {
      const response = await fetch('/api/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'listening',
          answers: answers,
          passageId: testId
        })
      });

      if (!response.ok) {
        throw new Error('Baholash jarayonida xatolik yuz berdi');
      }

      const result = await response.json();
      setScore(result);

      // Save to localStorage test history
      try {
        const historyItem = {
          id: `listening_${Date.now()}`,
          type: "listening",
          date: new Date().toISOString(),
          band: parseFloat(result.band) || 4.0,
          correct: result.correct || 0,
          total: result.total || 7,
          passageId: testId
        };
        const historyJson = localStorage.getItem("ielts_test_history");
        const history = historyJson ? JSON.parse(historyJson) : [];
        history.unshift(historyItem);
        localStorage.setItem("ielts_test_history", JSON.stringify(history));
      } catch (e) {
        console.warn("Error saving history to localStorage:", e);
      }
    } catch (error: any) {
      alert("Xatolik: " + error.message);
      setIsSubmitted(false);
    }
  };

  const handleCopy = (word: string) => {
    navigator.clipboard.writeText(word);
    alert(`"${word}" nusxalandi!`);
  };

  const selectCls = `h-10 border rounded-xl px-3 focus:ring-1 focus:ring-amber-500 outline-none text-sm cursor-pointer ${
    theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-zinc-50 border-zinc-200 text-zinc-900'
  }`;

  return (
    <div className={`min-h-screen flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-500 relative overflow-hidden transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#09090b] text-[#f4f4f5]' : 'bg-[#f8f9fa] text-[#18181b]'
    }`}>
      {/* Background Radial Glow */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[120px] pointer-events-none -z-10"></div>

      <header className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors duration-300 ${
        theme === 'dark' ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'
      }`}>
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="text-zinc-500 hover:text-[#f4f4f5] transition-colors font-semibold text-sm">
              ← Exit Test
            </Link>
          </div>

          {/* Test Selector */}
          <div className="flex items-center gap-2">
            <select
              value={testId}
              onChange={(e: any) => setTestId(e.target.value)}
              disabled={isSubmitted}
              className={`border text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer ${
                theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-200 text-zinc-900'
              }`}
            >
              {Object.values(tests).map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} {testHistory[t.id] ? `(Band ${testHistory[t.id].band})` : ""}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-4">
            <DisplaySettings theme={theme} settings={display} />
            <button
              onClick={toggleTheme}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                theme === 'dark'
                  ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                  : 'bg-zinc-100 border-zinc-200 text-zinc-700 hover:text-black'
              }`}
            >
              {theme === 'dark' ? "☀️ Light" : "🌙 Dark"}
            </button>
            <button
              onClick={() => setShowVocab(true)}
              className={`text-xs font-semibold px-3 py-2 rounded-xl transition-all border ${
                theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white' : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50'
              }`}
            >
              📖 Lug'atlar (Vocab)
            </button>
            <div className="text-lg font-mono font-bold text-amber-500 tracking-tight">
              {formatTime(timeLeft)}
            </div>
            {!isSubmitted && (
              <button
                onClick={submitTest}
                className="bg-[#f4f4f5] text-[#09090b] px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider hover:opacity-90 transition-opacity"
              >
                Submit
              </button>
            )}
          </div>
        </div>

        {/* Dynamic CBT Audio Player with Playback Speed Control */}
        <div className={`w-full border-b px-6 py-4 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 shadow-inner backdrop-blur-md transition-colors duration-300 ${
          theme === 'dark' ? 'bg-zinc-950/60 border-zinc-900' : 'bg-white border-zinc-200 shadow-sm'
        }`}>
          <div className="flex items-center gap-4">
            <button
              onClick={toggleAudio}
              disabled={isSubmitted}
              className="w-12 h-12 bg-amber-500 hover:bg-amber-600 text-black font-extrabold rounded-full flex items-center justify-center transition-colors disabled:opacity-50 shadow-md"
            >
              {isPlaying ? "⏸" : "▶"}
            </button>

            {/* Playback speed selector */}
            <select
              value={playbackSpeed}
              onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
              disabled={isSubmitted}
              className={`border text-xs font-bold rounded-xl px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer ${
                theme === 'dark' ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-200 text-zinc-900'
              }`}
            >
              <option value="0.8">0.8x Speed</option>
              <option value="1.0">1.0x Speed</option>
              <option value="1.25">1.25x Speed</option>
              <option value="1.5">1.5x Speed</option>
            </select>
          </div>

          <div className={`w-full max-w-xl h-2 rounded-full overflow-hidden border ${
            theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-zinc-150 border-zinc-200'
          }`}>
            <div
              className="h-full bg-amber-500 transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <div className="text-[10px] font-mono text-zinc-500 w-24 text-right">
            Sentences: {currentSentenceIndex + 1}/{currentTest.sentences.length}
          </div>
        </div>
      </header>

      <main style={{ zoom: display.fontScale }} className="flex-1 max-w-3xl w-full mx-auto p-6 md:p-10 z-10">

        {!isSubmitted ? (
          <div className="space-y-10 animate-in fade-in duration-300">
            {/* Section 1 — Notes / Form completion (fill-in questions) */}
            {fillQs.length > 0 && (
              <div className={`border p-8 rounded-2xl shadow-xl transition-colors duration-300 ${
                theme === 'dark' ? 'bg-zinc-950 border-zinc-900' : 'bg-white border-zinc-200 text-zinc-900 shadow-sm'
              }`}>
                <h2 className="text-xl font-bold mb-2">Section 1</h2>
                <p className="text-xs text-zinc-500 mb-6 italic">
                  Questions 1-{fillQs.length}. Complete the notes below. Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.
                </p>

                <div className={`p-6 rounded-xl border space-y-4 ${theme === 'dark' ? 'bg-zinc-900/40 border-zinc-900' : 'bg-zinc-50 border-zinc-200 text-zinc-900'}`}>
                  <h3 className="font-bold text-center underline mb-6 text-zinc-400">{currentTest.title}</h3>
                  {fillQs.map((q) => (
                    <div key={q.qid} className="grid grid-cols-1 sm:grid-cols-[160px_1fr] items-center gap-2 sm:gap-4">
                      <span className="font-medium text-sm sm:text-right text-zinc-400">{q.prompt}:</span>
                      <span className="text-sm">
                        {q.prefix ? `${q.prefix} ` : ""}
                        <input
                          type="text"
                          value={answers[q.qid] || ""}
                          onChange={(e) => handleInputChange(q.qid, e.target.value)}
                          className={`w-48 border-b bg-transparent px-2 outline-none focus:border-amber-500 font-semibold ${theme === 'dark' ? 'border-zinc-700 text-white' : 'border-zinc-300 text-zinc-900'}`}
                          placeholder={`${qNum(q.qid)} ________`}
                        />
                        {q.suffix ? ` ${q.suffix}` : ""}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Section 2 — Multiple choice */}
            {mcqQs.length > 0 && (
              <div className={`border p-8 rounded-2xl shadow-xl transition-colors duration-300 ${
                theme === 'dark' ? 'bg-zinc-950 border-zinc-900' : 'bg-white border-zinc-200 text-zinc-900 shadow-sm'
              }`}>
                <h2 className="text-xl font-bold mb-2">Section 2</h2>
                <p className="text-xs text-zinc-500 mb-6 italic">
                  Questions {qNum(mcqQs[0].qid)}-{qNum(mcqQs[mcqQs.length - 1].qid)}. Choose the correct letter, A, B, or C.
                </p>

                <div className="space-y-6">
                  {mcqQs.map((q) => (
                    <div key={q.qid} className="flex flex-col gap-2">
                      <div className="flex gap-2">
                        <span className="font-semibold text-sm">{qNum(q.qid)}.</span>
                        <span className={`text-sm font-medium ${theme === 'dark' ? 'text-zinc-300' : 'text-zinc-700'}`}>{q.prompt}</span>
                      </div>
                      <select
                        value={answers[q.qid] || ""}
                        onChange={(e) => handleInputChange(q.qid, e.target.value)}
                        className={`w-full sm:w-80 ${selectCls}`}
                      >
                        <option value=""></option>
                        {q.options.map((o) => (
                          <option key={o.value} value={o.value}>{o.value}. {o.label}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        ) : (
          <div className="flex flex-col items-center justify-start py-6 h-full">
            {!score ? (
              <div className="flex flex-col items-center text-center animate-pulse mt-20">
                <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-6"></div>
                <h3 className="font-bold text-lg mb-2 text-[#f4f4f5]">Analyzing Answers...</h3>
                <p className="text-sm text-zinc-500">Checking against audio transcript and generating AI explanations in Uzbek.</p>
              </div>
            ) : (
              <div className={`border p-6 md:p-8 rounded-2xl shadow-xl w-full max-w-2xl animate-in slide-in-from-bottom-8 transition-colors duration-300 ${
                theme === 'dark' ? 'bg-zinc-950 border-zinc-900 text-white' : 'bg-white border-zinc-200 text-zinc-900 shadow-lg'
              }`}>
                <h3 className="text-center uppercase tracking-widest text-xs font-bold text-zinc-500 mb-6">Official IELTS Scorecard</h3>

                <div className={`flex justify-between items-center mb-8 pb-8 border-b ${theme === 'dark' ? 'border-zinc-900' : 'border-zinc-200'}`}>
                  <div className="text-center">
                    <div className="text-xs text-zinc-500 font-medium mb-1">To'g'ri javoblar</div>
                    <div className="text-4xl font-bold">{score.correct}<span className="text-xl text-zinc-500">/{score.total}</span></div>
                  </div>
                  <div className="h-12 w-px bg-zinc-900"></div>
                  <div className="text-center">
                    <div className="text-xs text-zinc-500 font-medium mb-1">IELTS Band</div>
                    <div className="text-4.5xl font-bold text-amber-500 font-mono">{score.band}</div>
                  </div>
                </div>

                {score.explanations && Object.keys(score.explanations).length > 0 && (
                  <div className="space-y-6 mb-8 text-left">
                    <h4 className="font-bold text-xs uppercase tracking-widest text-zinc-500 mb-4">Barcha savollar tahlili (AI Explanation)</h4>
                    {Object.entries(score.explanations).map(([qId, explanation]: any) => {
                      const userAns = (answers[qId] || '(Javob berilmagan)').trim().toUpperCase();
                      const correctAns = keysMap[qId];
                      const isCorrect = userAns === correctAns;
                      return (
                        <div key={qId} className={`border p-5 rounded-xl space-y-2 transition-all ${
                          isCorrect ? 'border-emerald-500/20 hover:border-emerald-500/40' : 'border-red-500/20 hover:border-red-500/40'
                        } ${theme === 'dark' ? 'bg-[#09090b]' : 'bg-zinc-50'}`}>
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-xs text-amber-500 uppercase font-mono">Savol {qId.replace('q', '')}</span>
                            <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${
                              isCorrect ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                            }`}>
                              {isCorrect ? 'Correct' : 'Incorrect'}
                            </span>
                          </div>
                          <div className="text-[11px] text-zinc-500 mb-1">{promptMap[qId]}</div>
                          <div className="grid grid-cols-2 gap-4 text-xs py-2 border-y border-zinc-900/50 font-mono">
                            <div>
                              <span className="text-zinc-500 block">Sizning javobingiz:</span>
                              <span className={`font-bold ${isCorrect ? 'text-emerald-500' : 'text-red-500'}`}>{userAns}</span>
                            </div>
                            <div>
                              <span className="text-zinc-500 block">To'g'ri javob:</span>
                              <span className="font-bold text-emerald-500">{correctAns}</span>
                            </div>
                          </div>
                          <p className="text-sm text-zinc-300 leading-relaxed mt-2">{explanation}</p>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Synced Audio Transcript with highlights */}
                <div className="border-t border-zinc-900 pt-6 mb-8 text-left">
                  <h4 className="font-bold text-xs uppercase tracking-widest text-zinc-500 mb-4">Listening Audio Transcript (Ovozli Matn Tahlili)</h4>
                  <div
                    className={`border p-5 rounded-xl text-sm leading-loose space-y-4 font-serif ${
                      theme === 'dark' ? 'bg-[#09090b] border-zinc-900 text-zinc-400' : 'bg-zinc-50 border-zinc-200 text-zinc-700'
                    }`}
                    dangerouslySetInnerHTML={{ __html: currentTest.transcriptHtml }}
                  />
                </div>

                <button
                  onClick={() => setIsSubmitted(false)}
                  className="w-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-white py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-colors"
                >
                  Qayta topshirish / Retake Test
                </button>
              </div>
            )}
          </div>
        )}

      </main>

      {/* Vocabulary Modal */}
      {showVocab && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-zinc-950 border border-zinc-900 max-w-2xl w-full rounded-2xl p-6 md:p-8 max-h-[85vh] overflow-y-auto shadow-2xl relative">
            <button
              onClick={() => setShowVocab(false)}
              className="absolute top-6 right-6 text-zinc-500 hover:text-white font-mono text-xs uppercase tracking-widest font-bold"
            >
              [ Close ]
            </button>
            <h3 className="text-xl font-black mb-2 text-zinc-100 flex items-center gap-2">
              <span>📖</span> Vocabulary List / Lug'at boyligi
            </h3>
            <p className="text-xs text-zinc-500 mb-6">Ushbu listening testda ishlatilgan eng muhim akademik va foydali so'zlar ro'yxati.</p>

            <div className="space-y-4">
              {currentTest.vocab.map((item, i) => (
                <div key={i} className="bg-zinc-900/40 border border-zinc-900 p-4 rounded-xl flex justify-between items-start gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-amber-500">{item.word}</span>
                      <span className="text-xs text-zinc-500 font-medium">({item.translation})</span>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed">{item.definition}</p>
                  </div>
                  <button
                    onClick={() => handleCopy(item.word)}
                    className="text-[10px] font-bold text-zinc-500 hover:text-white uppercase tracking-wider font-mono bg-zinc-950 px-2 py-1 rounded border border-zinc-900/60"
                  >
                    Copy
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
