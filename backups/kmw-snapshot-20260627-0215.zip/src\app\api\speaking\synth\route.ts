import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const { 
      text, 
      gender, 
      model_id, 
      stability, 
      similarity_boost, 
      style, 
      voiceId: customVoiceId 
    } = await request.json();

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: 'ElevenLabs API key is missing' }, { status: 500 });
    }

    const targetModel = model_id || 'eleven_turbo_v2_5';
    
    let voiceId = '';
    if (customVoiceId) {
      voiceId = customVoiceId;
    } else if (targetModel === 'eleven_multilingual_v2') {
      // Antoni (male) or Domi (female) for multilingual warm accents
      voiceId = gender === 'female' ? 'AZnzlk1XvdvUeBnXmlld' : 'ErXwobaYiN019PkySvjV';
    } else {
      // Sarah (female) or George (male) for British examiner standard
      voiceId = gender === 'female' ? 'EXAVITQu4vr4xnSDxMaL' : 'JBFqnCBsd6RMkjVDRZzb';
    }

    const url = `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`;

    const defaultStability = targetModel === 'eleven_multilingual_v2' ? 0.38 : 0.71;
    const defaultSimilarity = 0.85;
    const defaultStyle = targetModel === 'eleven_multilingual_v2' ? 0.15 : 0.05;

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: text,
        model_id: targetModel,
        voice_settings: {
          stability: typeof stability === 'number' ? stability : defaultStability,
          similarity_boost: typeof similarity_boost === 'number' ? similarity_boost : defaultSimilarity,
          style: typeof style === 'number' ? style : defaultStyle,
          use_speaker_boost: true
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('ElevenLabs API Error:', errorText);
      return NextResponse.json({ error: 'ElevenLabs API failed: ' + errorText }, { status: response.status });
    }

    const audioBuffer = await response.arrayBuffer();

    return new NextResponse(audioBuffer, {
      headers: {
        'Content-Type': 'audio/mpeg',
      }
    });

  } catch (error: any) {
    console.error('Synth API Error:', error);
    return NextResponse.json({ error: error.message || 'An error occurred during synthesis' }, { status: 500 });
  }
}
