import { NextResponse } from 'next/server';

async function callClaude(systemPrompt: string, userPrompt: string): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('Anthropic API key is missing.');

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1200,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }]
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Claude API failed: ${response.statusText} - ${errorText}`);
  }

  const data = await response.json();
  if (!data.content || data.content.length === 0 || data.content[0].type !== 'text') {
    throw new Error('Invalid response from Claude API');
  }
  return data.content[0].text;
}

function parseJSONResponse(text: string): any {
  let cleanText = text.trim();
  if (cleanText.startsWith('```')) {
    const firstNewLine = cleanText.indexOf('\n');
    if (firstNewLine !== -1) {
      cleanText = cleanText.slice(firstNewLine + 1);
    }
    if (cleanText.endsWith('```')) {
      cleanText = cleanText.slice(0, -3);
    }
    cleanText = cleanText.trim();
  }
  const startIdx = cleanText.indexOf('{');
  const endIdx = cleanText.lastIndexOf('}');
  if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
    cleanText = cleanText.slice(startIdx, endIdx + 1);
  }
  return JSON.parse(cleanText);
}

export async function POST(request: Request) {
  try {
    const { conversation, part, cueTopicName, cueTopic, personality, language, discussion, conversationMode, examinerMode, verbosity } = await request.json();

    const v = verbosity || 'normal';
    let wordLimitText = '40 to 60 words';
    if (v === 'concise') {
      wordLimitText = '20 to 30 words';
    } else if (v === 'detailed') {
      wordLimitText = '70 to 100 words';
    }

    // ── Part 3: Generate 4 discussion questions ──
    if (part === 3) {
      const systemPrompt = `You are a professional IELTS examiner conducting Part 3 of the IELTS Speaking test.
The candidate just spoke about a cue card on the topic: "${cueTopic}".
The broad discussion theme is: "${cueTopicName}".

Generate exactly 4 IELTS Part 3 discussion questions about this theme.
Part 3 questions should be:
- Abstract and societal (not personal like Part 1)
- Require extended responses with opinions and reasoning
- Progressive in difficulty
- Cover different angles of the topic

Return ONLY a JSON array of 4 question strings, nothing else. Example:
["Question 1?", "Question 2?", "Question 3?", "Question 4?"]`;

      const raw = await callClaude(systemPrompt, 'Generate the 4 Part 3 questions now.');
      const jsonMatch = raw.match(/\[[\s\S]*\]/);
      const questions = jsonMatch ? JSON.parse(jsonMatch[0]) : [
        `Do you think ${cueTopicName.toLowerCase()} plays an important role in modern society?`,
        `How has ${cueTopicName.toLowerCase()} changed in recent decades?`,
        `What should governments do to address issues related to ${cueTopicName.toLowerCase()}?`,
        `Do you think younger generations have different attitudes towards ${cueTopicName.toLowerCase()} compared to older generations?`,
      ];
      return NextResponse.json({ questions });
    }

    // ── Part 1: natural conversational examiner (reacts to the answer, asks a follow-up) ──
    if (part === 1) {
      if (!conversation || !Array.isArray(conversation) || conversation.length === 0) {
        return NextResponse.json({ error: 'Conversation history is required' }, { status: 400 });
      }
      const convText = conversation
        .map((m: any) => `${m.role === 'user' ? 'Candidate' : 'Examiner'}: ${m.text}`)
        .join('\n');
      const topic = cueTopicName || 'everyday life';
      const sys = discussion
        ? `You are Alex, a sharp but warm IELTS Speaking examiner in Part 3 (the discussion stage).
Listen to the candidate's most recent answer and respond like a real examiner probing deeper:
- React briefly to a specific point they made (show you genuinely listened).
- Then ask ONE deeper, more abstract or societal follow-up question that challenges them to give opinions, reasons, comparisons or predictions about "${topic}".
Rules: English only. Intellectually engaged, natural, never robotic. No corrections, no scores. Between ${wordLimitText} (including the follow-up question). End with a question. Do not prefix with "Examiner:".
Note: Candidate's response is transcribed via Speech-to-Text, so ignore minor transcription mistakes or spelling typos. Interpret their main point and respond based on their intent.
 
Conversation so far:
${convText}`
        : `You are Alex, a warm, natural IELTS Speaking examiner in Part 1.
Listen to the candidate's most recent answer and respond like a real human examiner having a genuine conversation:
- React briefly and specifically to what they actually said (a short, natural acknowledgement or comment that shows you listened).
- Then ask ONE relevant follow-up question that builds on their answer, or smoothly moves to a related everyday sub-topic around "${topic}".
Rules: English only. Sound human and curious, never robotic or generic. No corrections, no scores, no meta-comments. Between ${wordLimitText} (including the follow-up question). End with a question. Do not prefix with "Examiner:".
Note: Candidate's response is transcribed via Speech-to-Text, so ignore minor transcription mistakes or spelling typos. Interpret their main point and respond based on their intent.
 
Conversation so far:
${convText}`;
      const reply = await callClaude(sys, "Give the examiner's next natural line.");
      return NextResponse.json({ nextResponse: reply.trim() });
    }

    // ── Casual Chat Mode (100% English native friend conversation) ──
    if (conversationMode === 'casual') {
      if (!conversation || !Array.isArray(conversation)) {
        return NextResponse.json({ error: 'Conversation history is required' }, { status: 400 });
      }

      const conversationText = conversation
        .map((msg: any) => `${msg.role === 'user' ? 'Candidate' : 'Alex'}: ${msg.text}`)
        .join('\n');

      const targetLanguage = language || 'english';
      let langInstruction = '';
      if (targetLanguage === 'korean') {
        langInstruction = `You are a warm, friendly Korean conversational partner. Speak only in natural Korean. React to what they said, share thoughts, and ask friendly questions to keep the conversation going. Do NOT teach, lecture, or correct their grammar.`;
      } else if (targetLanguage === 'chinese') {
        langInstruction = `You are a warm, friendly Chinese conversational partner. Speak only in natural Chinese. React to what they said, share thoughts, and ask friendly questions to keep the conversation going. Do NOT teach, lecture, or correct their grammar.`;
      } else if (targetLanguage === 'uzbek') {
        langInstruction = `Siz "Alex" ismli do'stona va samimiy o'zbek suhbatdoshisiz. Faqat o'zbek tilida gapiring — tabiiy, jonli, mahalliy o'zbek tilida. Suhbatdoshingiz nima desangiz shanga munosabat bildiring, o'z fikringizni baham ko'ring va suhbatni davom ettirish uchun qulay savollar bering. O'qitish, grammatika tuzatish yoki IELTS maslahati bermang.`;
      } else {
        langInstruction = `You are a warm, friendly, native English-speaking companion named Alex. Speak only in natural, casual, conversational English. Speak like a close friend would. Do NOT teach, correct grammar, or give IELTS tips. Keep the tone organic, supportive, and engaging. Ask follow-up questions to keep the conversation flowing smoothly.`;
      }

      const personaCasualMap: Record<string, string> = {
        kind: 'Your personality: extremely warm, kind and encouraging — like a supportive best friend.',
        sarcastic: 'Your personality: witty and playfully sarcastic — tease them lightly and joke around, but stay friendly and warm.',
        formal: 'Your personality: polite, composed and articulate — like a thoughtful, well-spoken friend.',
        toxic: 'Your personality: cheeky, blunt and comically impatient — roast them playfully like a close friend who loves teasing (never genuinely mean or offensive).',
        romantic: 'Your personality: affectionate and sweet — use warm terms of endearment and a caring, loving tone.',
      };
      const personaCasual = personaCasualMap[personality] || personaCasualMap.sarcastic;

      const systemPrompt = `${langInstruction}

${personaCasual} Express this personality naturally in whatever language you are speaking, but you can talk about ANY topic the user wants — this is a free, universal conversation.

Rules:
- You must output your response in JSON format. The JSON must contain exactly two fields:
  1. "nextResponse": The conversational reply to display on screen.
  2. "speechText": The exact same conversational reply to be spoken by Text-to-Speech (ElevenLabs).
- Do not prefix with "Alex:" or "Friend:" or "Examiner:".
- Ignore minor Speech-to-Text transcription mistakes or typos (e.g. if candidate said "good", it might be transcribed as "gud"). Respond naturally based on their intent.
- Keep responses comfortable and natural. Your response (excluding JSON keys) must be between ${wordLimitText} in total.

Conversation so far:
${conversationText}

Return a raw JSON object matching this structure (no markdown codeblock wrapper, no comments, just raw JSON):
{
  "nextResponse": "conversational reply",
  "speechText": "conversational reply"
}`;

      const rawResponse = await callClaude(systemPrompt, "Generate the JSON response.");

      let nextResponseText = '';
      let speechText = '';
      try {
        const parsed = parseJSONResponse(rawResponse);
        nextResponseText = parsed.nextResponse || rawResponse;
        speechText = parsed.speechText || nextResponseText;
      } catch (e) {
        console.warn("Failed to parse JSON reply from Claude, falling back:", e);
        nextResponseText = rawResponse.trim();
        speechText = nextResponseText;
      }

      return NextResponse.json({ 
        nextResponse: nextResponseText,
        speechText: speechText
      });
    }

    // ── Part 1 / Original chat flow ──
    if (!conversation || !Array.isArray(conversation)) {
      return NextResponse.json({ error: 'Conversation history is required' }, { status: 400 });
    }

    const conversationText = conversation
      .map((msg: any) => `${msg.role === 'user' ? 'Candidate' : 'Examiner'}: ${msg.text}`)
      .join('\n');

    let personalityPrompt = '';
    if (personality === 'kind') {
      personalityPrompt = `You are an extremely kind, supportive and encouraging IELTS tutor named Alex. When correcting the candidate's grammatical or lexical mistakes:
- Speak in Uzbek with warm encouragement and positive reinforcement.
- Use natural, native Uzbek (e.g., "Ajoyib javob! Faqat kichik bir tuzatish: 'I am agree' emas, 'I agree' desangiz chiroyli chiqadi. Qani, davom etamiz...").
- Keep corrections brief, encouraging, and supportive.`;
    } else if (personality === 'formal') {
      personalityPrompt = `You are a formal, professional IELTS tutor named Alex. When correcting the candidate's grammatical or lexical mistakes:
- Speak in a jiddiy, rasmiy, and objective academic Uzbek tone.
- Use standard, clear Uzbek (e.g., "Rahmat. E'tibor bering: ingliz tilida 'people is' emas, 'people are' qo'llaniladi. Keyingi savol...").
- Keep it direct and academic.`;
    } else if (personality === 'toxic') {
      personalityPrompt = `You are an angry, impatient, and toxic IELTS tutor named Alex. When correcting the candidate's grammatical or lexical mistakes:
- Express slight irritation and make funny, strict remarks in colloquial Uzbek.
- Use impatient, colloquial Uzbek phrases (e.g., "Yana o'sha xatomi? Necha marta aytish kerak, 'she walk' emas, 'she walks' bo'ladi! Sal e'tiborliroq bo'ling! Savolga javob bering...").
- Be strict, but still educational and correct them.`;
    } else if (personality === 'romantic') {
      personalityPrompt = `You are a very sweet, affectionate, and emotional IELTS tutor named Alex. When correcting the candidate's grammatical or lexical mistakes:
- Speak in a caring, loving tone.
- Use sweet Uzbek terms of endearment like "asalim", "jonim", "azizim".
- Use affectionate, native Uzbek phrasing (e.g., "Jonim, shoshilmang, 'he don't' emas, 'he doesn't' bo'ladi, siz buni uddalaysiz, azizim. Keyingi savolga o'tamiz...").`;
    } else {
      // Default: 'sarcastic'
      personalityPrompt = `You are a strict, sarcastic, and witty IELTS tutor named Alex. When correcting the candidate's grammatical or lexical mistakes:
- Use light humor, teasing, and gentle sarcasm in colloquial Uzbek, urging them to get a Band 9.0.
- Use funny, colloquial Uzbek phrasing (e.g., "Vuybo', 'he don't' desangiz imtihonchi yig'lab yuboradi-ku! 'He doesn't' bo'ladi, axir. Band 9 olish uchun harakatni boshlang! Davom etamiz...").`;
    }

    const targetLanguage = language || 'english';
    let langInstruction = '';
    if (targetLanguage === 'korean') {
      langInstruction = `The candidate is practising Korean. Listen to their Korean, correct errors in Uzbek, then ask next question in Korean.`;
    } else if (targetLanguage === 'chinese') {
      langInstruction = `The candidate is practising Chinese. Listen to their Chinese, correct errors in Uzbek, then ask next question in Chinese.`;
    } else if (targetLanguage === 'uzbek') {
      langInstruction = `Nomzod o'zbek tilini mashq qilmoqda. Ularning o'zbek nutqini eshiting. Agar muhim grammatik yoki leksik xatolar bo'lsa, ularni qisqacha tuzating va o'zbek tilida tushuntiring. Keyin keyingi suhbat savolini ham o'zbek tilida bering.`;
    } else {
      langInstruction = `The candidate is practising English. Listen to their English, briefly correct any major grammar or vocabulary errors in Uzbek, then ask the next conversational question in English.`;
    }

    const systemPrompt = `${personalityPrompt}

${langInstruction}

Rules:
- You must output your response in JSON format. The JSON must contain exactly three fields:
  1. "nextResponse": The full text to display on screen. If the candidate made grammar/lexical errors, briefly explain and correct them in Uzbek. Then ask the next question in English (or the target language if selected).
  2. "speechText": The text to be spoken by ElevenLabs TTS (English/Korean/Chinese parts only, the follow-up question).
  3. "uzbekText": The Uzbek portion of the response (corrections/explanations in Uzbek). If there is no Uzbek content (all in English), return an empty string "".
- Both nextResponse and speechText must end with the follow-up question.
- Do not prefix with "Examiner:".
- Candidate's speech is transcribed via Speech-to-Text. You must silently detect and correct common Speech-to-Text transcription errors in your mind (e.g. if the transcript says "Salon" or "Saloon", they actually said "Salom"; if it says "gud" or "goot", they meant "good"). If the language is 'uzbek', also handle common Uzbek STT mistakes.
- CRITICAL: DO NOT ever point out, mention, or explain these Speech-to-Text or transcription errors to the user in your response. Do not write "siz Y degansiz lekin men X tushundim", "Bu Speech-to-Text ning aybi", or any explanation of transcription typos. Just accept their intended word (e.g. "Salom") and proceed with the conversation naturally as if they had spoken perfectly. Never say "xavotir olmang, siz Y degansiz..." or mention STT!
- CRITICAL word limit: The entire response (Uzbek explanation + follow-up question combined) must be between ${wordLimitText} in total. Do not exceed this limit.

Conversation so far:
${conversationText}

Return a raw JSON object matching this structure (no markdown codeblock wrapper, no comments, just raw JSON):
{
  "nextResponse": "full response (Uzbek correction/explanation + English question)",
  "speechText": "the English follow-up question only (or full response if language is uzbek)",
  "uzbekText": "Uzbek correction/explanation only (empty string if no Uzbek content)"
}`;

    const rawResponse = await callClaude(systemPrompt, "Generate the JSON response.");
    
    let nextResponseText = '';
    let speechText = '';
    let uzbekText = '';
    try {
      const parsed = parseJSONResponse(rawResponse);
      nextResponseText = parsed.nextResponse || rawResponse;
      speechText = parsed.speechText || nextResponseText;
      uzbekText = parsed.uzbekText || '';
    } catch (e) {
      console.warn("Failed to parse JSON reply from Claude, falling back:", e);
      nextResponseText = rawResponse.trim();
      speechText = nextResponseText;
      uzbekText = '';
    }

    return NextResponse.json({ 
      nextResponse: nextResponseText,
      speechText: speechText,
      uzbekText: uzbekText
    });

  } catch (error: any) {
    console.error('Speaking chat API error:', error);
    return NextResponse.json({ error: error.message || 'An error occurred' }, { status: 500 });
  }
}
