"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";

const SENTENCES = [
  "The development of renewable energy is crucial for a sustainable future.",
  "I would rather live in a vibrant city than a quiet village.",
  "Technology has significantly transformed the way we communicate.",
  "Education plays a fundamental role in reducing poverty worldwide.",
  "Although it was raining, we thoroughly enjoyed our journey.",
  "Many people prefer working from home because it is more comfortable.",
  "The government should invest more in public transportation.",
  "Climate change is one of the most challenging issues of our generation.",
  "Reading regularly can greatly improve your vocabulary and fluency.",
  "She has always been passionate about learning foreign languages.",
];

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9'\s]/g, "").split(/\s+/).filter(Boolean);

// Levenshtein-based similarity (0..1) — tolerant of accent-driven mis-recognition.
function similar(a: string, b: string): number {
  if (a === b) return 1;
  const m = a.length, n = b.length;
  if (m === 0 || n === 0) return 0;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return 1 - dp[m][n] / Math.max(m, n);
}

// Fuzzy word alignment: a target word counts if a heard word is close enough (forgiving on accent).
function scoreWords(target: string, heard: string) {
  const tWords = norm(target);
  const hWords = norm(heard);
  const used = new Array(hWords.length).fill(false);
  const THRESHOLD = 0.7; // accept near-matches (short words need to be closer)
  const result = tWords.map((w) => {
    let bestIdx = -1, bestSim = 0;
    for (let i = 0; i < hWords.length; i++) {
      if (used[i]) continue;
      const sim = similar(w, hWords[i]);
      if (sim > bestSim) { bestSim = sim; bestIdx = i; }
    }
    const need = w.length <= 3 ? 0.85 : THRESHOLD;
    const ok = bestSim >= need;
    if (ok && bestIdx >= 0) used[bestIdx] = true;
    return { word: w, ok };
  });
  const correct = result.filter((r) => r.ok).length;
  return { result, correct, total: tWords.length };
}

export default function PronunciationPractice() {
  const [idx, setIdx] = useState(0);
  const [status, setStatus] = useState<"idle" | "listening" | "done">("idle");
  const [heard, setHeard] = useState("");
  const [scored, setScored] = useState<{ result: { word: string; ok: boolean }[]; correct: number; total: number } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);

  const recognitionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const sentence = SENTENCES[idx];

  const flash = (m: string) => { setNotice(m); setTimeout(() => setNotice(null), 3500); };

  useEffect(() => {
    if (typeof window === "undefined") return;
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return;
    const r = new SR();
    r.continuous = false;
    r.interimResults = true;
    r.lang = "en-US";
    r.onresult = (e: any) => {
      let txt = "";
      for (let i = 0; i < e.results.length; i++) txt += e.results[i][0].transcript + " ";
      setHeard(txt.trim());
    };
    r.onend = () => {
      setStatus((s) => {
        if (s === "listening") {
          setHeard((h) => {
            if (h.trim()) setScored(scoreWords(sentence, h));
            else flash("Hech narsa eshitilmadi — qaytadan urinib ko'ring.");
            return h;
          });
          return "done";
        }
        return s;
      });
    };
    r.onerror = (e: any) => { if (e.error === "not-allowed") flash("Mikrofonga ruxsat bering."); };
    recognitionRef.current = r;
    return () => { try { r.abort(); } catch {} };
  }, [sentence]);

  const start = () => {
    setHeard(""); setScored(null); setStatus("listening");
    try { recognitionRef.current?.start(); } catch {}
  };
  const stop = () => { try { recognitionRef.current?.stop(); } catch {} };

  const listenModel = async () => {
    if (playing) { audioRef.current?.pause(); setPlaying(false); return; }
    try {
      setPlaying(true);
      const res = await fetch("/api/speaking/synth", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: sentence, gender: "female" }),
      });
      if (!res.ok) throw new Error("audio");
      const blob = await res.blob();
      const audio = new Audio(URL.createObjectURL(blob));
      audioRef.current = audio;
      audio.onended = () => setPlaying(false);
      await audio.play();
    } catch { setPlaying(false); flash("Ovozni yuklab bo'lmadi."); }
  };

  const next = () => { stop(); setIdx((i) => (i + 1) % SENTENCES.length); setStatus("idle"); setHeard(""); setScored(null); };

  const pct = scored ? Math.round((scored.correct / scored.total) * 100) : 0;
  const scoreColor = pct >= 85 ? "text-emerald-400" : pct >= 60 ? "text-amber-400" : "text-red-400";

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex flex-col font-sans">
      <header className="sticky top-0 z-30 bg-zinc-950/80 backdrop-blur border-b border-zinc-900">
        <div className="mx-auto max-w-3xl flex h-16 items-center justify-between px-6">
          <Link href="/dashboard" className="text-zinc-500 hover:text-white text-sm font-semibold">← Dashboard</Link>
          <span className="text-xs font-bold uppercase tracking-widest text-amber-500">Talaffuz Mashqi</span>
          <span className="text-xs text-zinc-500 font-mono">{idx + 1}/{SENTENCES.length}</span>
        </div>
      </header>

      {notice && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-zinc-950 border border-amber-500/30 text-amber-400 px-4 py-2 rounded-xl text-sm font-semibold shadow-2xl">{notice}</div>
      )}

      <main className="flex-1 max-w-3xl w-full mx-auto px-6 py-10 flex flex-col">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-500 text-xs font-bold uppercase tracking-widest mb-6 border border-amber-500/20 self-start">
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" /> Pronunciation Trainer
        </div>

        {/* Target sentence */}
        <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-8 mb-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">Bu jumlani o'qing</span>
            <button onClick={listenModel} className="text-xs font-bold px-3 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20">
              {playing ? "⏸ To'xtatish" : "🔊 To'g'ri talaffuzni eshitish"}
            </button>
          </div>

          {/* Sentence — coloured after scoring */}
          <p className="text-2xl md:text-3xl font-serif leading-relaxed">
            {scored ? scored.result.map((r, i) => (
              <span key={i} className={r.ok ? "text-emerald-400" : "text-red-400 underline decoration-wavy decoration-red-500/60"}>{r.word}{" "}</span>
            )) : sentence}
          </p>
        </div>

        {/* Action */}
        {status !== "done" ? (
          <button
            onClick={status === "listening" ? stop : start}
            className={`mx-auto w-44 h-44 rounded-full flex flex-col items-center justify-center font-black text-lg transition-all shadow-2xl ${
              status === "listening" ? "bg-red-500/20 border-2 border-red-500 text-red-400 animate-pulse" : "bg-amber-500 text-black hover:bg-amber-400 hover:-translate-y-1"
            }`}
          >
            <span className="text-4xl mb-2">{status === "listening" ? "⏹" : "🎙️"}</span>
            {status === "listening" ? "To'xtatish" : "Gapirish"}
          </button>
        ) : (
          <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-8 animate-in slide-in-from-bottom-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1">Talaffuz ballingiz</div>
                <div className={`text-5xl font-black ${scoreColor}`}>{pct}%</div>
                <div className="text-xs text-zinc-500 mt-1">{scored!.correct}/{scored!.total} so'z aniq talaffuz qilindi</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1">Eshitilgan</div>
                <p className="text-sm text-zinc-400 italic max-w-[200px]">"{heard}"</p>
              </div>
            </div>

            {scored!.result.some((r) => !r.ok) && (
              <div className="border-t border-zinc-900 pt-4 mb-4">
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-2">Mashq qiling (qizil so'zlar)</div>
                <div className="flex flex-wrap gap-2">
                  {scored!.result.filter((r) => !r.ok).map((r, i) => (
                    <span key={i} className="text-sm font-bold bg-red-500/10 text-red-400 border border-red-500/20 px-3 py-1 rounded-lg">{r.word}</span>
                  ))}
                </div>
                <p className="text-xs text-zinc-500 mt-3">💡 "To'g'ri talaffuzni eshitish" tugmasini bosib, qizil so'zlarni qayta mashq qiling.</p>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={start} className="flex-1 bg-zinc-900 border border-zinc-800 py-3 rounded-xl font-bold text-sm hover:bg-zinc-800">🔁 Qayta urinish</button>
              <button onClick={next} className="flex-1 bg-amber-500 text-black py-3 rounded-xl font-bold text-sm hover:bg-amber-400">Keyingi jumla →</button>
            </div>
          </div>
        )}

        <p className="text-center text-xs text-zinc-600 mt-8 leading-relaxed">
          Tizim sizning ovozingizni tanib, qaysi so'zlar <span className="text-emerald-400">aniq</span> va qaysilari <span className="text-red-400">noaniq</span> talaffuz qilinganini ko'rsatadi.
          Chrome brauzerida eng yaxshi ishlaydi.
        </p>
      </main>
    </div>
  );
}
